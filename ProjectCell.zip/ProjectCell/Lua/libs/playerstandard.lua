
local unit_type_drill = 503
local _PlayerStandard_start_action_interact = PlayerStandard._start_action_interact
function PlayerStandard:_start_action_interact(t,...)
	_PlayerStandard_start_action_interact(self, t, ...)
	if self._interact_params and self._interact_params.object and alive(self._interact_params.object) then
		managers.cell_interaction:interaction_start(self._unit, self._interact_params.object, self._interact_params.tweak_data, t)
	end	
end

local _PlayerStandard_interupt_action_interact = PlayerStandard._interupt_action_interact
function PlayerStandard:_interupt_action_interact(...)	
	local params = {...}
	local t = params[1]
	local complete = params[3]
	if self._interact_params and self._interact_params.object and alive(self._interact_params.object) then
		if complete then
			managers.cell_interaction:interaction_complete(self._unit, self._interact_params.object, self._interact_params.tweak_data, t)
		else
			managers.cell_interaction:interaction_interrupted(self._unit, self._interact_params.object, self._interact_params.tweak_data, t)
		end
		
	end
	_PlayerStandard_interupt_action_interact(self, ...)
end


local _PlayerStandard_get_unit_intimidation_action = PlayerStandard._get_unit_intimidation_action
function PlayerStandard:_get_unit_intimidation_action(...)
	local voice_type, plural, prime_target = _PlayerStandard_get_unit_intimidation_action(self, ...)
	managers.cell_interaction:set_intimidation_action({
		voice_type = voice_type,
		plural = plural,
		prime_target = prime_target
	})
	return voice_type, plural, prime_target
end


local _PlayerStandard_do_action_intimidate = PlayerStandard._do_action_intimidate
function PlayerStandard:_do_action_intimidate(t, interact_type, sound_name, skip_alert, ...)
	sound_name = managers.cell_interaction:get_intimidate_sound_name_override(sound_name)
	_PlayerStandard_do_action_intimidate(self, t, interact_type, sound_name, skip_alert, ...)
end