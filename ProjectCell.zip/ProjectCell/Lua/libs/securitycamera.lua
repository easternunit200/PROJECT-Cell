SecurityCamera._ban_cam_narrate_clbk_id = "cameras_announcement_clbk"
local _SecurityCamera_generate_cooldown = SecurityCamera.generate_cooldown
function SecurityCamera:generate_cooldown(amount,...)
	_SecurityCamera_generate_cooldown(self, amount,...)
	local destroyed = 0
	local cameras = 0
	if managers.groupai:state():whisper_mode() then
		for _, unit in ipairs(SecurityCamera.cameras) do
			if unit and alive(unit) and unit:enabled() then
				cameras = cameras + 1
				if unit:base():destroyed() then
					destroyed = destroyed + 1
				end
			end
		end
		DeadLocke:announce_cameras_destroyed({total = cameras, destroyed = destroyed})
	end
end