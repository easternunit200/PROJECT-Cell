local _duplicate_to_ssuffix = {
	"Play_ban_h40",
	"Play_ban_h02",
	"Play_ban_h42",
	"Play_loc_h40",
	"Play_loc_h02",
	"Play_loc_h42"
}	

local _DialogManager_load_dialog_data = DialogManager._load_dialog_data
function DialogManager:_load_dialog_data(name)
	_DialogManager_load_dialog_data(self, name)		

	
	local block = managers.cell_data:wrapper("VanillaDialogDataBlock"):get_block_by_id(1)
	if block then
		for _, node in ipairs(block.list) do
			if node._meta == "dialog" then
				if node.id then
					if node.all_characters then
						for _, character in ipairs(tweak_data.criminals.characters) do
							local ssuffix = character and character.static_data and character.static_data.ssuffix
							local dialog_id = node.id:gsub("{ssuffix}",ssuffix)
							if ssuffix and not self._dialog_list[dialog_id] then			
								self._dialog_list[dialog_id] = {
									id = dialog_id,
									character = node.character,
									sound = node.sound,
									string_id = node.string_id,
									priority = node.priority or tweak_data.dialog.DEFAULT_PRIORITY
								}	
							end
						end
					else
						self._dialog_list[node.id] = {
							id = node.id,
							character = node.character,
							sound = node.sound,
							string_id = node.string_id,
							priority = node.priority or tweak_data.dialog.DEFAULT_PRIORITY
						}				
					end					
				end
			end
		end
		
	end
	
	
	
end