local _LevelsTweakData_init = LevelsTweakData.init
function LevelsTweakData:init()
	_LevelsTweakData_init(self)
	self.arena.death_event = nil
	self.arena.death_track = nil
end


local _LevelsTweakData_LevelsTweakData = LevelsTweakData.get_music_event
function LevelsTweakData:get_music_event(stage)
	if managers.cell_music:on_event_skip(stage) then
		return nil
	end
	return _LevelsTweakData_LevelsTweakData(self, stage)
end