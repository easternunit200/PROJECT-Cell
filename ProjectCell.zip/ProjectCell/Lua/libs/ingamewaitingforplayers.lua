local _IngameWaitingForPlayersState_at_exit = IngameWaitingForPlayersState.at_exit
function IngameWaitingForPlayersState:at_exit(...)
	if self._started_from_beginning then
		managers.cell_user:set_beginner(true)
		managers.cell_music:check_override_intro_heist_event()
	end
	
	_IngameWaitingForPlayersState_at_exit(self, ...)
	
	managers.cell_music:normalize_heist_intro()
end

local _IngameWaitingForPlayersState_sync_start = IngameWaitingForPlayersState.sync_start
function IngameWaitingForPlayersState:sync_start(...)
	managers.cell_user:set_beginner(true)
	managers.cell_music:check_override_intro_heist_event()
	_IngameWaitingForPlayersState_sync_start(self, ...)	
	managers.cell_music:normalize_heist_intro()
end