local update_trigger_area = GameSetup.update
function GameSetup:update(t, dt, ...)	
	C_Global:update(t,dt, ...)	
	return update_trigger_area(self, t, dt, ...)
end

local _GameSetup_init_managers = GameSetup.init_managers
function GameSetup:init_managers(managers, ...)
	_GameSetup_init_managers(self, managers, ...)	
	C_Global = CellGlobal:new(false)	
end


local _GameSetup_destroy = GameSetup.destroy
function GameSetup:destroy(...)
	_GameSetup_destroy(self, ...)
	C_Global:destroy()	
end


-- local init_fin_orig = GameSetup.init_finalize
-- function GameSetup:init_finalize(...)
	-- init_fin_orig(self, ...)
	
	-- local levels_sounds = {
		-- "short1/stage1",
		-- "short1/stage2",
		-- "short2/stage1",
		-- "short2/stage2",
		-- "bain/rvd/stage1",
		-- "h_watchdogs/stage_2",
		-- "vlad/ukrainian_job",
	-- }
	-- for i, path_name in pairs(levels_sounds) do
		-- if not PackageManager:loaded( "levels/narratives/"..path_name.."/world_sounds" ) then
			-- PackageManager:load( "levels/narratives/"..path_name.."/world_sounds" )
			-- log("Loading World sound: levels/narratives/"..path_name.."/world_sounds")
		-- end
	-- end
-- end