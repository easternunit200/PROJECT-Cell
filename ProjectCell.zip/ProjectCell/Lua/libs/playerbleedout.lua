local _PlayerBleedOut_enter = PlayerBleedOut.enter
function PlayerBleedOut:enter(...)
	_PlayerBleedOut_enter(self, ...)
	
	
	local revives = self._unit:character_damage():get_revives()	
	if revives and revives >= 1 then	
		self:clbk_entry_speech()		
		self._entry_speech_clbk = "PlayerBleedOut_entryspeech"
		managers.cell_drama:on_downed(self._unit)
		managers.enemy:add_delayed_clbk(self._entry_speech_clbk, callback(self, self, "clbk_entry_speech"), TimerManager:game():time() + 20)
	end
	
end

function PlayerBleedOut:clbk_entry_speech()	
	if managers.cell_options:has_toggled("project_cell_downed_help_tog") then
		PlayerStandard.say_line(self, "f11e_plu")
	end	
end

local _PlayerBleedOut_exit = PlayerBleedOut.exit
function PlayerBleedOut:exit(state_data, new_state_name)
	local exit_data = _PlayerBleedOut_exit(self, state_data, new_state_name)
	if new_state_name ~= "fatal" then 
		if self._entry_speech_clbk then
			managers.enemy:remove_delayed_clbk(self._entry_speech_clbk)
			self._entry_speech_clbk = nil
		end
	else
		exit_data.entry_speech_clbk = self._entry_speech_clbk
	end
	return exit_data
end

local _PlayerBleedOutpredestroy = PlayerBleedOut.pre_destroy
function PlayerBleedOut:pre_destroy(unit)
	_PlayerBleedOutpredestroy(self, unit)
	if self._entry_speech_clbk then
		managers.enemy:remove_delayed_clbk(self._entry_speech_clbk)
		self._entry_speech_clbk = nil
	end
end


local _PlayerBleedOut_destroy = PlayerBleedOut.destroy
function PlayerBleedOut:destroy()
	_PlayerBleedOut_destroy(self)
	if self._entry_speech_clbk then
		managers.enemy:remove_delayed_clbk(self._entry_speech_clbk)
		self._entry_speech_clbk = nil
	end
end
