local _ExperienceManager_load = ExperienceManager.load 
function ExperienceManager:load(...)
	_ExperienceManager_load(self, ...)
	DeadLocke:verify_music_tracks_ownership_dlcs()
end