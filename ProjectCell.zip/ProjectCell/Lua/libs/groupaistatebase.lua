
function GroupAIStateBase:_coach_last_man_clbk()
	local civilians_present = next(managers.enemy:all_civilians())
	managers.cell_narrator:set_switch("civilians_present", civilians_present and "yes" or "no")
	if table.size(self:all_char_criminals()) == 1 and self:bain_state() then
		local _, u_data = next(self:all_char_criminals())
		local ssuffix = managers.criminals:character_static_data_by_unit(u_data.unit).ssuffix
		if self:hostage_count() <= 0 then
			managers.dialog:queue_narrator_dialog("h40"..ssuffix, {})
		else
			managers.dialog:queue_narrator_dialog("h42"..ssuffix, {})
		end
	end
end


local _GroupAIStateBase_teammate_comment = GroupAIStateBase.teammate_comment
function GroupAIStateBase:teammate_comment(trigger_unit, message, pos, pos_based, radius, sync)
	if radius and radius <= 0 then
		radius = nil
	end
	if pos and pos == Vector3(0,0,0) then
		pos_based = nil
	end
	_GroupAIStateBase_teammate_comment(self, trigger_unit, message, pos, pos_based, radius, sync)
end


local _GroupAIStateBase_criminal_hurt_drama = GroupAIStateBase.criminal_hurt_drama
function GroupAIStateBase:criminal_hurt_drama(unit, attacker, dmg_percent)
	_GroupAIStateBase_criminal_hurt_drama(self, unit, attacker, dmg_percent)
	managers.cell_drama:on_criminal_hurt(unit, attacker, dmg_percent)
end

local _GroupAIStateBase_on_criminal_disabled = GroupAIStateBase.on_criminal_disabled
function GroupAIStateBase:on_criminal_disabled(unit, ...)
	_GroupAIStateBase_on_criminal_disabled(self, unit, ...)	
	managers.cell_drama:on_criminal_disabled(unit)
end

local _GroupAIStateBase_on_criminal_neutralized = GroupAIStateBase.on_criminal_neutralized
function GroupAIStateBase:on_criminal_neutralized(unit)
	_GroupAIStateBase_on_criminal_neutralized(self, unit)
	managers.cell_drama:on_criminal_neutralized(unit)
end


local _GroupAIStateBase_notify_bain_weapons_hot = GroupAIStateBase.notify_bain_weapons_hot
function GroupAIStateBase:notify_bain_weapons_hot(called_reason)
	_GroupAIStateBase_notify_bain_weapons_hot(self, called_reason)
	if called_reason ~= "empty" then
		managers.cell_stealth:on_called_reason(called_reason)
	end
end


--[[local _GroupAIStateBase_sync_event = GroupAIStateBase.sync_event
function GroupAIStateBase:sync_event(event_id, ...) 	
	local event_name = self.EVENT_SYNC[event_id]
	if event_name == "enemy_weapons_hot" then
		managers.cell_music:add_skip_event("control")
	end	
	_GroupAIStateBase_sync_event(self, event_id)
end]]


local _GroupAIStateBase_set_point_of_no_return_timer = GroupAIStateBase.set_point_of_no_return_timer
function GroupAIStateBase:set_point_of_no_return_timer(time, ...)
	_GroupAIStateBase_set_point_of_no_return_timer(self, time, ...)
	if time ~= nil and not setup:has_queued_exec() then
		managers.cell_music:change_state(MusicMachine.MUS_States.Escape)
	end
	
end

local _GroupAIStateBase_load = GroupAIStateBase.load
function GroupAIStateBase:load(load_data)
	_GroupAIStateBase_load(self, load_data)
	if self._nr_successful_alarm_pager_bluffs then
		managers.cell_pager:on_loaded_pagers(self._nr_successful_alarm_pager_bluffs) 
	end	
end




