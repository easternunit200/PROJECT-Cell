function ChallengeManager:on_celebrate_challenge_completed()
	local match_this_string = "ingame_"
	if game_state_machine:current_state_name():sub(1, #match_this_string) ~= match_this_string then
		return
	end
	
	local player = managers.player:player_unit()
	if not player or not alive(player) then
		return
	end
	
	if managers.groupai and managers.groupai:state():whisper_mode() then
		return
	end
	
	if not player:movement():downed() then
		player:sound():say("v46")
	end
end


local _ChallengeManager_any_challenge_completed = ChallengeManager._check_challenge_completed
function ChallengeManager:_check_challenge_completed(...)
	local challenge_completed = _ChallengeManager_any_challenge_completed(self, ...)
	if challenge_completed then
		managers.cell_callback:add_delayed_callback("challenge_completed_celebration", 2, callback(self, self, "on_celebrate_challenge_completed"))
	end
	return challenge_completed
end
