
-- local _ChatManager_receive_message_by_peer = ChatManager.receive_message_by_peer
-- function ChatManager:receive_message_by_peer(channel_id, peer, message)
	-- _ChatManager_receive_message_by_peer(self, channel_id, peer, message)
	
	-- if game_state_machine and game_state_machine.current_state and game_state_machine:current_state():name():find("ingame_") then
		-- local key_word = "!cell_mute"
		-- if message == key_word and peer ~= managers.network:session():local_peer() then		
			-- local peer_id = peer:id()
			-- local peer_name = tostring(peer:name())
			-- local message = peer_name .. ", will no longer hear the cell lines."
			
			-- local is_cell_user = managers.cell_user:is_peer_registered(peer_id) 			
			-- if is_cell_user then
				-- peer:send("send_chat_message", ChatManager.GAME, "You have Project : Cell installed, this command only works for non - cell users (players who do not have Project: Cell).")
			-- elseif not managers.cell_peer_exclusion:is_peer_id_excluded(peer_id) then
				-- peer:send("send_chat_message", ChatManager.GAME, message)
				-- managers.cell_peer_exclusion:exclude_peer(peer_id)
			-- end			
			
		-- end
	-- end
	
	
-- end