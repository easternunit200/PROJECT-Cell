local _MusicManager_post_event = MusicManager.post_event
function MusicManager:post_event(name)
	if managers.deadlocke_menu and managers.deadlocke_menu.music_post_event_disabled then
		return
	end
	_MusicManager_post_event(self, name)
end


function MusicManager:clbk_game_has_music_control(...)
	if not managers.cell_music:has_intro_playing() then
		MusicManager.super.clbk_game_has_music_control(self, ...)
	end	
end