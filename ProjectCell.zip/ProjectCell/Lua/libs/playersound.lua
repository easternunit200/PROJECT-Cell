PlayerSound.THIRD_PERSON_STRINGS = {
	"g90",
	"g50",
	"g70",
	"s09a",
	"s09b",
	"s09c",
	"s05a_sin",
	"s05b_sin"
}

PlayerSound.THIRD_PERSON_IDS = {}
for i,v in pairs(PlayerSound.THIRD_PERSON_STRINGS) do
	PlayerSound.THIRD_PERSON_IDS[v] = SoundDevice:string_to_id(v)
end

function PlayerSound.is_third_person_sound(sound_name)
	if sound_name and type(sound_name) == "number" then
		return table.contains(PlayerSound.THIRD_PERSON_IDS, sound_name) and true or false
	end	
	return table.contains(PlayerSound.THIRD_PERSON_STRINGS, sound_name) and true or false
end


local _PlayerSound_say = PlayerSound.say
function PlayerSound:say(sound_name, ...)
	if self._unit:base().is_local_player then 
		self._unit:sound_source():set_switch("int_ext", PlayerSound.is_third_person_sound(sound_name) and "third" or "first")
	end	
	
	self._last_speech = _PlayerSound_say(self, sound_name, ...)
	
	if self._unit.base and self._unit:base() and self._unit:base().is_local_player then
		self._unit:sound_source():set_switch("int_ext", "first")
	end

	return self._last_speech
end

function PlayerSound:say_block(sound_block_id, ...)
	local block = managers.cell_data:wrapper("VanillaSoundEventDataBlock"):get_block(sound_block_id)
	if block then
		self:say(block.SoundEvent, ...)
	else
		C_Global:log("ERROR : unrecognized sound_block_id : " .. tostring(sound_block_id))
	end
	
	
	return self._last_speech
end

function PlayerSound:filter_say_block(sound_block_id, sync, important_say)
	local block = managers.cell_data:wrapper("VanillaSoundEventDataBlock"):get_block(sound_block_id)
	if block then
		self:filter_say(block.SoundEvent, sync, important_say)	
	else
		C_Global:log("ERROR : unrecognized sound_block_id : " .. tostring(sound_block_id))
	end
	
	
	return self._last_speech
end

function PlayerSound:want_to_say(event_id, start_dialog_id)	
	local character = managers.criminals:character_name_by_unit(self._unit)	
	if character then
		managers.cell_voice:want_to_say(character, event_id, start_dialog_id or 0)
	end
end

function PlayerSound:filter_say(sound_name, sync, important_say)	
	self._last_speech = self:say(sound_name, false, important_say, true, nil)	
	
	local event_id = type(sound_name) == "number" and sound_name or SoundDevice:string_to_id(sound_name)
	
	if sync then
		for pid, peer in pairs(managers.network:session():all_peers()) do
			if peer ~= managers.network:session():local_peer() then
				local peer_name = peer:name()
				if not managers.cell_peer_exclusion:is_peer_id_excluded(pid) or managers.cell_user:is_peer_registered(pid) then
					managers.cell_peer_exclusion:debug_print("sending sound_name " .. tostring(sound_name) .. " to peer " .. tostring(peer_name))
					peer:send_queued_sync("say", self._unit, event_id)	
				else
					managers.cell_peer_exclusion:debug_print("Peer " .. tostring(peer_name) .. " is excluded from hearing cell lines, will not send.")
				end	
			end				
		end
	end
	
	
	return self._last_speech
end