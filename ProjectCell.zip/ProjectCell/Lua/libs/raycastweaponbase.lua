function RaycastWeaponBase:_check_ammo_total(unit)
	if self:get_ammo_total() <= 0 and unit:base().is_local_player and unit:inventory():all_out_of_ammo() then
		PlayerStandard.say_line(unit:sound(), "g81x_plu")
		DeadLocke:_add_remind_ammo_need_clbk()
	end
end

local _RaycastWeaponBase_set_ammo_total = RaycastWeaponBase.set_ammo_total
function RaycastWeaponBase:set_ammo_total(ammo_total)
	_RaycastWeaponBase_set_ammo_total(self, ammo_total)
	if self._setup.user_unit == managers.player:player_unit() then
		if ammo_total and ammo_total > 0 then
			DeadLocke:_remove_remind_ammo_need_clbk()
		end
	end
end