local _DoctorBagBase_take = DoctorBagBase.take
function DoctorBagBase:take(unit, ...)
	managers.cell_condition:on_reset(self._unit)
	return _DoctorBagBase_take(self, unit,...)
end