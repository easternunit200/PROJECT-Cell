local _PlayerFatal_enter = PlayerFatal.enter
function PlayerFatal:enter(state_data, enter_data)
	_PlayerFatal_enter(self, state_data, enter_data)
	if enter_data and enter_data.entry_speech_clbk then
		self._entry_speech_clbk = enter_data.entry_speech_clbk
	end
end

local _PlayerFatal_exit = PlayerFatal.exit
function PlayerFatal:exit(state_data, new_state_name)
	local exit_data = _PlayerFatal_exit(self, state_data, new_state_name)
	if self._entry_speech_clbk then
		managers.enemy:remove_delayed_clbk(self._entry_speech_clbk)
		self._entry_speech_clbk = nil
	end
	return exit_data
end

local _PlayerFatal_pre_destroy = PlayerFatal.pre_destroy
function PlayerFatal:pre_destroy(unit)
	_PlayerFatal_pre_destroy(self, unit)
	if self._entry_speech_clbk then
		managers.enemy:remove_delayed_clbk(self._entry_speech_clbk)
		self._entry_speech_clbk = nil
	end
end

local _PlayerFatal_destroy = PlayerFatal.destroy
function PlayerFatal:destroy()
	_PlayerFatal_destroy(self)
	if self._entry_speech_clbk then
		managers.enemy:remove_delayed_clbk(self._entry_speech_clbk)
		self._entry_speech_clbk = nil
	end
end