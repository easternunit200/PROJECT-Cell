local _PlayerTased_comment = PlayerTased.enter
function PlayerTased:enter(state_data, enter_data)
	_PlayerTased_comment(self, state_data, enter_data)
	if math.random() < 0.25 then
		self._unit:sound():say( "s07x_sin", true, false )
	end
end