local _IngameWaitingForRespawnState_at_exit = IngameWaitingForRespawnState.at_exit
function IngameWaitingForRespawnState:at_exit()
	local level_id = Global.level_data and Global.level_data.level_id
	if level_id == "arena" then
		managers.music:post_event("alesso_music_cut")
	end	
	
	_IngameWaitingForRespawnState_at_exit(self)
end