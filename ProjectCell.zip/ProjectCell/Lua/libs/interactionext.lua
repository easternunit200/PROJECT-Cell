
local _BaseInteractionExt_set_outline_flash_state = BaseInteractionExt.set_outline_flash_state
function BaseInteractionExt:set_outline_flash_state(state, sync)
	_BaseInteractionExt_set_outline_flash_state(self, state, sync)
	if state and self._contour_id and self.tweak_data == "corpse_alarm_pager" then
		managers.cell_pager:inform_pager_contact(true)	
	end
end


local _BaseInteractionExt_set_active = BaseInteractionExt.set_active
function BaseInteractionExt:set_active(active, sync)
	_BaseInteractionExt_set_active(self, active, sync)
	if active and self.tweak_data == "corpse_alarm_pager" then
		managers.cell_pager:set_pager_counter(self._unit:key())			
		managers.cell_pager:inform_pager_contact(false)		
	end
end



local _IntimitateInteractionExt_interact = IntimitateInteractionExt.interact
function IntimitateInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	if self.tweak_data == 'corpse_alarm_pager' then
		managers.cell_pager:on_pager_interaction_complete(self._unit:key())		
	end	
	_IntimitateInteractionExt_interact(self, player)
end

local _IntimitateInteractionExt_sync_interacted = IntimitateInteractionExt.sync_interacted
function IntimitateInteractionExt:sync_interacted(peer, player, status, ...)
	_IntimitateInteractionExt_sync_interacted(self, peer, player, status, ...)
	if self.tweak_data == 'corpse_alarm_pager' then
		if status == 'complete' then
			managers.cell_pager:on_pager_interaction_complete(self._unit:key())	
		end
	end
end
