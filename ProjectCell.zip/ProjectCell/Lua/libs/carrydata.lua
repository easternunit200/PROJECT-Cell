CarryData._stealing_cooldown_id = "CopsStealingBags"

local _CarryData_link_to = CarryData.link_to
function CarryData:link_to(...)
	_CarryData_link_to(self, ...)	
	if self._linked_to then
		local linked_key = self._linked_to:key()
		if managers.enemy:all_enemies()[linked_key] then
			if not self._stealing_loot_clbk and not managers.cell_cooldown:has_cooldown(CarryData._stealing_cooldown_id) then
				managers.cell_cooldown:apply_cooldown(CarryData._stealing_cooldown_id, 30)
				self._stealing_loot_clbk = callback(self,self,"on_stealing_loot_clbk")			
				managers.cell_callback:add_delayed_callback("cop_stealing_loot_".. tostring(linked_key), 2, self._stealing_loot_clbk)
			end
		end		
	end
end

function CarryData:on_stealing_loot_clbk()
	if managers.cell_user:is_cell_host() then
		local best_canditate = managers.cell_user:get_best_canditate("project_cell_theif_stealing_tog", false, nil)		 
		if best_canditate then
			best_canditate:sound():say("p31",true,true)
		end
	end	
	self._stealing_loot_clbk = nil
end