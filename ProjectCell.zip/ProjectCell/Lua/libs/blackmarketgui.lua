function BlackMarketGui:on_set_preffered_character_vo(name)
	for i, char_data in pairs(tweak_data.criminals.characters) do
		if char_data.name == name then
			local voice = char_data.static_data and char_data.static_data.voice
			if voice then		
				managers.menu_component._sound_source:set_switch("robber", voice)
				managers.menu_component._sound_source:set_switch("int_ext", "first")
				local sound = "a01x_any"
				if char_data.name == "russian" and math.random() < 0.1 then
					sound = "g80x_plu"
				end
				 managers.menu_component._sound_source:post_event(sound)
			end
			break
		end
	end
end


local _BlackMarketGui_set_preferred_character_to_slot_callback = BlackMarketGui.set_preferred_character_to_slot_callback
function BlackMarketGui:set_preferred_character_to_slot_callback(data)
	_BlackMarketGui_set_preferred_character_to_slot_callback(self, data)
	self:on_set_preffered_character_vo(data.name)
end

local _BlackMarketGui_swap_preferred_character_to_slot_callback = BlackMarketGui.swap_preferred_character_to_slot_callback
function BlackMarketGui:swap_preferred_character_to_slot_callback(data)
	local index = nil
	local preferred_characters = managers.blackmarket:get_preferred_characters_list()

	for _, preferred_character in ipairs(preferred_characters) do
		if preferred_character == data.name then
			index = _

			break
		end
	end

	local selected = self._extra_options_data.selected or 1

	if index and self._extra_options_data and index ~= selected and (#preferred_characters == CriminalsManager.MAX_NR_CRIMINALS or selected ~= self._extra_options_data.num_panels) then
		self:on_set_preffered_character_vo(data.name)
	end
	_BlackMarketGui_swap_preferred_character_to_slot_callback(self, data)
end
