TradeManager._on_hostage_trade_comment_clbk_id = "CellTradeComment"

local _TradeManager_sync_hostage_trade_dialog = TradeManager.sync_hostage_trade_dialog
function TradeManager:sync_hostage_trade_dialog(i)
	_TradeManager_sync_hostage_trade_dialog(self, i)
	if game_state_machine:current_state_name() == "ingame_waiting_for_respawn" then
		return
	end
	if table.size(managers.groupai:state():all_char_criminals()) > 1 then
		if i > 1 and i < 8 then
			managers.cell_callback:add_delayed_callback(TradeManager._on_hostage_trade_comment_clbk_id, 3, callback(self, self, "cell_hostage_trade_comment"))	
		end
	end
end

function TradeManager:cell_hostage_trade_comment()
	local users = {}
	for id, cell_user in pairs(managers.cell_user:all_cell_users()) do
		local cell_unit = cell_user:unit()
		if cell_unit and alive(cell_unit) and not cell_unit:movement():downed() then
			local character = cell_user:character_name()
			if character == "russian" or character == "german" then
				table.insert(users, cell_unit)
			end
		end		
	end
	
	if next(users) then
		local volunteer = users[math.random(#users)]
		volunteer:sound():say("p07",true,true)
	end
end

function TradeManager:on_death_custody(data)
	if criminal_name ~= managers.criminals:local_character_name() then		
		managers.cell_callback:add_delayed_callback('DelayedMod_trade_death_comment_' .. tostring(criminal_name), 3, function()
			local player = managers.player:player_unit()
			if player and alive(player) then
				player:sound():say("g60", false, false)  --- Hoxton has a bug with this voice line where he sometimes says "I got the drill"
			end
		end)
		
		local crim_data = managers.criminals:character_data_by_name(data.criminal_name)
		if crim_data and not crim_data.ai then				
			
			local dialogIDs = {}
			if data.hostages_killed then
				if data.hostages_killed == 0 then
					table.insert(dialogIDs, CD.NarratorDialogue.Play_On_Custody_no_civies)
				elseif data.hostages_killed < 3 then
					table.insert(dialogIDs, CD.NarratorDialogue.Play_On_Custody_they_killed_civies)
				else
					table.insert(dialogIDs, CD.NarratorDialogue.Play_On_Custody_they_killed_civies)
				end
			end
			
			if managers.groupai:state():get_assault_mode() or data.respawn_penalty and data.respawn_penalty > 5 then
				table.insert(dialogIDs, CD.NarratorDialogue.TradeManager_wait_for_respawn)
			end

			local cable_tie_data = managers.player:has_special_equipment("cable_tie")
			if cable_tie_data and Application:digest_value(cable_tie_data.amount, false) > 0 then
				table.insert(dialogIDs, CD.NarratorDialogue.TradeManager_no_hostages_has_cable_ties)
			elseif self:get_criminal_to_trade(true) then
				table.insert(dialogIDs, CD.NarratorDialogue.TradeManager_no_hostages_no_cable_ties)
			end
			
			managers.cell_narrator:play_dialogs_in_segments(dialogIDs)
			
		end
	end
end



local _Tr_sync_set_trade_death = TradeManager.sync_set_trade_death
function TradeManager:sync_set_trade_death(criminal_name, respawn_penalty, hostages_killed, from_local, ...)
	_Tr_sync_set_trade_death(self, criminal_name, respawn_penalty, hostages_killed, from_local, ...)	
	self:on_death_custody({
		criminal_name = criminal_name,
		respawn_penalty = respawn_penalty,
		hostages_killed = hostages_killed,
		from_local = from_local,		
	})	
end

