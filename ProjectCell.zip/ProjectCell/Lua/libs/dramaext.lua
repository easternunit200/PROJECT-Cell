local _DramaExt_stop_cue = DramaExt.stop_cue
function DramaExt:stop_cue()
	_DramaExt_stop_cue(self)
	managers.cell_narrator:stop()
end


local _DramaExt_play_sound = DramaExt.play_sound
function DramaExt:play_sound(sound, sound_source)
	if not managers.cell_narrator:post_event_for_dialog(sound) then	
		_DramaExt_play_sound(self, sound, sound_source)
	end
end






