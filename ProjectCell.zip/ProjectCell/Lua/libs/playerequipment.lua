local old_use_trip_mine = PlayerEquipment.use_trip_mine
function PlayerEquipment:use_trip_mine()
	local used_trip_mine = old_use_trip_mine(self)
	local peer_id = managers.criminals:character_peer_id_by_unit(self._unit)
	if peer_id then
		if used_trip_mine and managers.player._global.synced_deployables[peer_id].deployable == "trip_mine" and managers.player._global.synced_deployables[peer_id].amount == 1 then
			managers.cell_callback:add_delayed_callback("PlayerEquipment_deployed_last_mine", 4, callback(self,self,"_no_more_trip_mines_clbk"))			
		end
	end
	
	return used_trip_mine
end

function PlayerEquipment:_no_more_trip_mines_clbk()
	local unit = self._unit
	if unit and alive(unit) then
		unit:sound():say( "s40x_sin", false, false )
	end
end