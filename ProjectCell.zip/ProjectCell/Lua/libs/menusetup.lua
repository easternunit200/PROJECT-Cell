local _MenuSetup_init_finalize = MenuSetup.init_finalize
function MenuSetup:init_finalize()
	_MenuSetup_init_finalize(self)
	if not PackageManager:loaded( "levels/narratives/pbr/jerry/world_sounds" ) then
		PackageManager:load( "levels/narratives/pbr/jerry/world_sounds" )
	end	
	
	C_Global = CellGlobal:new(true)
end



local update_trigger_area = MenuSetup.update
function MenuSetup:update(t, dt)	
	C_Global:update(t,dt)	
	return update_trigger_area(self, t, dt)
end