local _CopLogicAttack_update = CopLogicAttack.update
function CopLogicAttack.update(data)
	_CopLogicAttack_update(data)
	DeadLocke:inform_law_enforcements(data)	
end