
function Drill:_change_num_jammed_drills(d)
end


function Drill:_drill_complain_clbk()
	local player = managers.player:player_unit()
	if player and alive(player) and not player:movement():downed() then
		if managers.criminals:character_name_by_unit(player) == "russian" then
			if managers.dialog then
				if managers.dialog._narrator == "bain" then
					managers.dialog:queue_dialog("Play_rb4_sh21_03", {})
				end
			end
		end
	end
end


local _Drill_start = Drill.start
function Drill:start()
	_Drill_start(self)
	managers.cell_drill:register_drill(self._unit)
end


local _Drill_done = Drill.done
function Drill:done()
	_Drill_done(self)
	managers.cell_drill:unregister_drill(self._unit)
end


local _Drill_set_jammed = Drill.set_jammed
function Drill:set_jammed(jammed)
	_Drill_set_jammed(self, jammed)
	if self._jammed then
		managers.cell_drill:register_jammed_drill(self._unit)
	else
		if self.is_hacking_device and not managers.groupai:state():whisper_mode() and managers.cell_user:is_cell_host() then
			if math.random() < 0.5 then			
				local best_canditate = managers.cell_drama:get_best_canditate(nil, false, nil)	
				if best_canditate then
					local distance = mvector3.distance_sq(best_canditate:position(), self._unit)					
					if distance and distance < 500 * 500 then
						best_canditate:sound():say("p10", true, true)
					end					
				end	
			end		
		end
		managers.cell_drill:unregister_jammed_drill(self._unit)
	end
end


--[[local _Drill_done = Drill.done
function Drill:done()
	_Drill_done(self)
	if DeadLocke._data.inf_drill_done_toggle then
		local comment = self.is_drill and "v23" or self.is_hacking_device and "v24" or "v07"
		DeadLocke:criminal_comment(nil, true, comment, self._unit:position(), true, 2000, false ,false)
	end
end]]