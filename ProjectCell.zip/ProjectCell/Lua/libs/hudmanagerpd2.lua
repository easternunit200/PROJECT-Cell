local _HUDManager_add_teammate_panel = HUDManager.add_teammate_panel
function HUDManager:add_teammate_panel(character_name, player_name, ai, peer_id)
	managers.cell_condition:on_reset_by_character(character_name)
	return _HUDManager_add_teammate_panel(self, character_name, player_name, ai, peer_id)
end

--[[local _HUDManager_show_point_of_no_return_timer = HUDManager.show_point_of_no_return_timer
function HUDManager:show_point_of_no_return_timer()
	_HUDManager_show_point_of_no_return_timer(self)
	if managers.dialog and managers.groupai then
		managers.groupai:state():ban_info_dialog(8)
	end
end]]

