--[[local NetworkManager_on_peer_added = NetworkManager.on_peer_added
function NetworkManager:on_peer_added(peer, peer_id, ...)	
	NetworkManager_on_peer_added(self, peer, peer_id, ...)
	managers.cell_user:register_user(peer)
end]]