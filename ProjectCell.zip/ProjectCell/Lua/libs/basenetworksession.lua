local _BaseNetworkSession_on_peer_left = BaseNetworkSession.on_peer_left
function BaseNetworkSession:on_peer_left(peer, peer_id,...)
	local r1,r2,r3,r4,r5 = _BaseNetworkSession_on_peer_left(self, peer, peer_id,...)
	if managers.cell_user then
		managers.cell_user:unregister_user(peer_id)
	end	
	
	return r1,r2,r3,r4,r5
end

local _BaseNetworkSession_on_peer_lost = BaseNetworkSession.on_peer_lost
function BaseNetworkSession:on_peer_lost(peer, peer_id,...)
	local r1,r2,r3,r4,r5 = _BaseNetworkSession_on_peer_lost(self, peer, peer_id,...)
	if managers.cell_user then
		managers.cell_user:unregister_user(peer_id)
	end	
	
	return r1,r2,r3,r4,r5
end

local _BaseNetworkSession_on_peer_kicked = BaseNetworkSession.on_peer_kicked
function BaseNetworkSession:on_peer_kicked(peer, peer_id, ...)
	local r1,r2,r3,r4,r5 = _BaseNetworkSession_on_peer_kicked(self, peer, peer_id, ...)
	if managers.cell_user then
		managers.cell_user:unregister_user(peer_id)
	end	
	
	return r1,r2,r3,r4,r5
end


--[[local _BaseNetworkSession_add_peer = BaseNetworkSession.add_peer
function BaseNetworkSession:add_peer(...)
	local id, peer = _BaseNetworkSession_add_peer(self,...)
	if managers.cell_user then
		managers.cell_user:register_user(peer)
	end	
	
	return id, peer
end]]

local _BaseNetworkSession_create_local_peer = BaseNetworkSession.create_local_peer
function BaseNetworkSession:create_local_peer(...)
	_BaseNetworkSession_create_local_peer(self,...)
	if managers.cell_user then
		managers.cell_user:register_local_peer(self._local_peer)
	end	
end

--[[local _BaseNetworkSession_register_local_peer = BaseNetworkSession.register_local_peer
function BaseNetworkSession:register_local_peer(...)
	_BaseNetworkSession_register_local_peer(self,...)
	
	if managers.cell_user then
		managers.cell_user:register_user(self._local_peer, true)
	end	
end]]


local _BaseNetworkSession_on_load_complete = BaseNetworkSession.on_load_complete
function BaseNetworkSession:on_load_complete(...)
	_BaseNetworkSession_on_load_complete(self, ...)
	
	if managers.cell_user then
		managers.cell_user:attempt_to_send_request()
	end
	
end
	