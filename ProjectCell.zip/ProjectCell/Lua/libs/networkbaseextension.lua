function NetworkBaseExtension:send_json_data(func_name, ...)
	if managers.network:session() then
		local character = managers.criminals:character_name_by_unit(self._unit)
		if character then
			DeadLockeNetwork:send_json_data_to_peers(func_name, character, ...)
		end
	end
end