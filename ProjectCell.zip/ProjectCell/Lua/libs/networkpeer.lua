--[[local _NetworkPeer_load = NetworkPeer.load
function NetworkPeer:load(data)
	_NetworkPeer_load(self, data)
	local local_peer = managers.network:session():local_peer()
	if self ~= local_peer then 
		if data.deadlocke_values then
			DeadLocke:add_peer(self._id)
			for name, enabled in pairs(data.deadlocke_values) do
				DeadLocke:enable_peer_data_value(name, enabled, self._id)
			end
			log("[NetworkPeer:load] received DeadLocke data values! from peer name "..tostring(self._name))
		end
		if data.deadlocke_from_start then
			DeadLocke:tracking_pagers(self._id, true)
		end
	end
end


local _NetworkPeer_save = NetworkPeer.save 
function NetworkPeer:save(data)
	_NetworkPeer_save(self, data)
	local local_peer = managers.network:session():local_peer()
	if self == local_peer then
		if DeadLocke._data then
			data.deadlocke_values = {}
			for name, enabled in pairs(DeadLocke._data) do
				data.deadlocke_values[name] = enabled
			end
			if Global.statistics_manager.playing_from_start then
				data.deadlocke_from_start = true
			end
			log("[NetworkPeer:save] has saved deadlocke values!")
		end
	end
end]]
