local _FlashGrenade_give_flash_damage = FlashGrenade._give_flash_damage
function FlashGrenade:_give_flash_damage(col_ray, unit, ...)
	_FlashGrenade_give_flash_damage(self, col_ray, unit,...)
	if unit == managers.player:player_unit() then
		if unit and alive(unit) then
			unit:sound():say("g41x_any", true, true)
		end
	end
end
