local _BaseInteractionExt_interact_interupt = BaseInteractionExt.interact_interupt
function BaseInteractionExt:interact_interupt(player, complete)
	_BaseInteractionExt_interact_interupt(self, player, complete)
	if self._deadlocke_mission_element then
		self._deadlocke_mission_element:on_interact_interupt(player)
	end
	if DeadLocke._interaction_say_waiting then
		managers.enemy:remove_delayed_clbk(DeadLocke._interaction_say_waiting)
		DeadLocke._interaction_say_waiting = nil
	end
end



local _BaseInteractionExt_set_outline_flash_state = BaseInteractionExt.set_outline_flash_state
function BaseInteractionExt:set_outline_flash_state(state, sync)
	_BaseInteractionExt_set_outline_flash_state(self, state, sync)
	if state and self._contour_id and self.tweak_data == "corpse_alarm_pager" then
		local t = Application:time()
		if not DeadLocke._ban_hold_t or DeadLocke._ban_hold_t + 3 < t then
			managers.groupai:state():ban_info_dialog(7)
			DeadLocke._ban_hold_t = t 
		end
	end
end


function BaseInteractionExt:set_deadlocke_mission_element(deadlocke_mission_element)
	self._deadlocke_mission_element = deadlocke_mission_element
end


local _BaseInteractionExt_set_active = BaseInteractionExt.set_active
function BaseInteractionExt:set_active(active, sync)
	_BaseInteractionExt_set_active(self, active, sync)
	if active and self.tweak_data == "corpse_alarm_pager" then
		DeadLocke:set_pager_counter(self._unit:key())	
		
		local t = Application:time()
		if not DeadLocke._ban_hold_t or DeadLocke._ban_hold_t + 3 < t then
			managers.groupai:state():ban_info_dialog(6)
			DeadLocke._ban_hold_t = t 
		end
		
	end
end


local _BaseInteractionExt_interact = BaseInteractionExt.interact
function BaseInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	
	local result = _BaseInteractionExt_interact(self, player)
	if self._deadlocke_mission_element then
		self._deadlocke_mission_element:on_interacted(player)
	else
		DeadLocke:on_interacted(self._unit, player, self.tweak_data, self._tweak_data.timer or 0, self._global_event, "on_interacted")
	end	
	return result
end

local _BaseInteractionExt_interact_start = BaseInteractionExt.interact_start
function BaseInteractionExt:interact_start(player, ...)
	local result1, result2, result3, result4 = _BaseInteractionExt_interact_start(self, player, ...)
	if player and player.base and player:base().is_local_player then
		if result1 then		
			if self._deadlocke_mission_element then
				self._deadlocke_mission_element:on_interact_start(player)
			else
				if self.tweak_data:find("pick_lock_") then
					DeadLocke:say_on_interaction({player, "p29", true})
				else
					DeadLocke:on_interacted(self._unit, player, self.tweak_data, self._tweak_data.timer or 0, self._global_event, "start_say")
				end
			end
		end
	end
	return result1, result2, result3, result4
end	

local _IntimitateInteractionExt_interact = IntimitateInteractionExt.interact
function IntimitateInteractionExt:interact(player)
	if not self:can_interact(player) then
		return
	end
	if self.tweak_data == 'corpse_alarm_pager' then
		DeadLocke:on_pager_interaction_complete(self._unit:key())
	end	
	DeadLocke:on_interacted(self._unit, player, self.tweak_data, self._tweak_data.timer or 0, self._global_event, "on_interacted")
	_IntimitateInteractionExt_interact(self, player)
end

local _IntimitateInteractionExt_sync_interacted = IntimitateInteractionExt.sync_interacted
function IntimitateInteractionExt:sync_interacted(peer, player, status, ...)
	_IntimitateInteractionExt_sync_interacted(self, peer, player, status, ...)
	if self.tweak_data == 'corpse_alarm_pager' then
		if status == 'complete' then
			DeadLocke:on_pager_interaction_complete(self._unit:key())
		end
	end
end
