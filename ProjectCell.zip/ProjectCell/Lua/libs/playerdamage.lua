PlayerDamage._revive_callback_id = "PlayerReviveComment"

local _PlayerDamage_pause_downed_timer = PlayerDamage.pause_downed_timer
function PlayerDamage:pause_downed_timer(...)
	_PlayerDamage_pause_downed_timer(self,...)
	local t = TimerManager:game():time()	
	if not managers.cell_cooldown:has_cooldown(PlayerDamage._revive_callback_id) then
		managers.cell_cooldown:apply_cooldown(PlayerDamage._revive_callback_id, tweak_data.interaction.revive.timer)				
		managers.cell_callback:add_delayed_callback(PlayerDamage._revive_callback_id, math.rand(1,2), function()				
			if managers.cell_options:has_toggled("project_cell_revived_tog") then
				if self._unit and alive(self._unit) then				
					self._unit:sound():say( "s05a_sin", true, true)
				end		
			end								
		end)
	end	
end

local _PlayerDamage_revive = PlayerDamage.revive
function PlayerDamage:revive(silent)	
	if not silent and self._downed_timer and self._downed_timer <= 10 then
		if self._revives ~= 0 then
			local character = managers.criminals:local_character_name()
			if character ~= "russian" and character ~= "german" and character ~= "old_hoxton" then
				PlayerStandard.say_line(self, "s05b_sin")
				silent = true
			end		
		end
	end	
	_PlayerDamage_revive(self, silent)
end
