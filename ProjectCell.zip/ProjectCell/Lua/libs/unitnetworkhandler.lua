local _UnitNetworkHandler_long_dis_interaction = UnitNetworkHandler.long_dis_interaction
function UnitNetworkHandler:long_dis_interaction(target_unit, amount, aggressor_unit, secondary)
	_UnitNetworkHandler_long_dis_interaction(self, target_unit, amount, aggressor_unit, secondary)
	if not self._verify_gamestate(self._gamestate_filter.any_ingame) or not self._verify_character(target_unit) or not self._verify_character(aggressor_unit) then
		return
	end
		
	if target_unit and target_unit.base and target_unit:base() and target_unit:base().is_local_player then
		local respond_line, delay
		local t = TimerManager:game():time()
		if secondary then
			if managers.cell_options:has_toggled("project_cell_defend_call_tog") then
				respond_line = "r03x_sin"
				delay = 1.5
			end
		else
			if managers.cell_options:has_toggled("project_cell_call_tog") then
				respond_line = (aggressor_unit:movement():downed() and "r02a" or "r01x") .."_sin"
			end			
		end
		
		if respond_line then			
			managers.cell_callback:add_delayed_callback("Cell_Response", delay or 0, function()
				if target_unit and alive(target_unit) and not target_unit:movement():downed() then
					target_unit:sound():say(respond_line, true)
				end
			end)
		end
	end
end	

local _UnitNetworkHandler_sync_doctor_bag_taken = UnitNetworkHandler.sync_doctor_bag_taken
function UnitNetworkHandler:sync_doctor_bag_taken(unit, amount, sender, ...)
	if not alive(unit) or not self._verify_gamestate(self._gamestate_filter.any_ingame) or not self._verify_sender(sender) then
		return
	end
	_UnitNetworkHandler_sync_doctor_bag_taken(self, unit, amount, sender, ...)
	local peer = self._verify_sender(sender)
	managers.cell_condition:on_reset(peer:unit())
end
