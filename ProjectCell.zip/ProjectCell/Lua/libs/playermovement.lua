local _PlayerMovement_on_suspicion = PlayerMovement.on_suspicion
function PlayerMovement:on_suspicion(observer_unit, status)
	_PlayerMovement_on_suspicion(self, observer_unit, status)
	if status == true then
		managers.cell_drama:set_discovered(self._unit:base().is_local_player)
	end	
end