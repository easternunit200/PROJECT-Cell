local _HUDManager_sync_start_anticipation_music = HUDManager.sync_start_anticipation_music
function HUDManager:sync_start_anticipation_music()
	_HUDManager_sync_start_anticipation_music(self)		
	managers.cell_drama:change_state(DramaMachine.STATES.Anticipation, true)	
end