DramaStateAlert = DramaStateAlert or blt_class(DramaStateBase)

function DramaStateAlert:setup()
	self._time_before_going_down = 8
end


function DramaStateAlert:enter(exit_data)
	if not exit_data or not exit_data.skip_control_music then
		managers.cell_music:change_state(MusicMachine.MUS_States.Control)	
	end	
	self._coming_back_from_assault = self._machine:last_state_name() == DramaMachine.STATES.Assault
end

function DramaStateAlert:exit()
	if self._machine:current_state_name() == DramaMachine.STATES.Control then
		if self._coming_back_from_assault and self._machine:current_tension() < 50 then
			self:after_assault_comment()
		end			
	end
end

function DramaStateAlert:after_assault_comment()
	if not managers.cell_user:is_cell_host() then
		return
	end
	
	
	local best_canditate = self._drama_manager:get_best_canditate("project_cell_post_assault_sli", true, "project_cell_bot_post_assault_sli")	
	if best_canditate then
		best_canditate:sound():say("p24",true,true)
	end
end

function DramaStateAlert:common_update(t, dt)
	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end

	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end	
	
	if t - self._state_change_t > self._time_before_going_down then		
		if self._drama_manager:go_to_sneaking() then
			self._machine:change_drama_state(DramaMachine.STATES.Sneaking, true)
			return
		end	
		
		if self._drama_manager:go_to_control() then
			self._machine:change_drama_state(DramaMachine.STATES.Control, true)
			return
		end		
	end
	
	
end

function DramaStateAlert:update(t, dt)
	self:common_update(t,dt)
end

function DramaStateAlert:sync_update(t, dt)
	self:common_update(t,dt)
end

function DramaStateAlert:debug_prefix()
	return "DramaStateAlert"
end