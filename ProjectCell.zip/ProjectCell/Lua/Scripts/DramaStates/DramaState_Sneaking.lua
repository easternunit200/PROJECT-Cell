DramaStateSneaking = DramaStateSneaking or blt_class(DramaStateBase)

function DramaStateSneaking:setup()
	self._dialogCooldownTimer = {60, 300}
	self._nextDialogTriggerTime = nil
	self._first_encounter_warning = true
	self._discovered_transition = nil
	self._clbk_id = "DramaStateSneaking_enter_state"
end

function DramaStateSneaking:enter(exit_data)
	self:set_wave_flag(false)
	managers.cell_music:start_sneaking_music()
	self:start_transition_dialog()
	self:start_delayed_dialog()
end

function DramaStateSneaking:start_transition_dialog()
end


function DramaStateSneaking:idle_dialog()
	managers.player_dialog:queue_dialog(25, {})
end

function DramaStateSneaking:revive_lines_allowed()
	return false
end

function DramaStateSneaking:common_update(t,dt)
	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end
	
	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end
	
	
	if self._drama_manager:go_to_control() then
		self._machine:change_drama_state(DramaMachine.STATES.Control, true)
		return
	end
	
	if self._drama_manager:go_to_discovered() then
		self._machine:change_drama_state(DramaMachine.STATES.Discovered, true)
		return
	end
	
end
 

function DramaStateSneaking:update(t, dt)
	self:common_update(t,dt)	
end

function DramaStateSneaking:sync_update(t, dt)
	self:common_update(t,dt)	
end

function DramaStateSneaking:tension_on_hurt()
	return false
end

function DramaStateSneaking:start_delayed_dialog()	
end

function DramaStateSneaking:idle_dialog()
end


function DramaStateSneaking:start_dialog(dialog_id)
end


function DramaStateSneaking:debug_prefix()
	return "DramaStateSneaking"
end

