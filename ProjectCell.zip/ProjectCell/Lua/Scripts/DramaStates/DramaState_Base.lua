DramaStateBase = DramaStateBase or blt_class(MachineState)

function DramaStateBase:init()
	DramaStateBase.super.init(self)
	self._drama_manager = nil
	self._owner = nil
end


function DramaStateBase:get_state_tension()	
	return 0
end

function DramaStateBase:chk_say_player_combat_chatter(t)
end

function DramaStateBase:tension_on_hurt()
	return false
end

function DramaStateBase:check_empty()
	if not self:is_owner_alive() then
		self._machine:change_drama_state(DramaMachine.STATES.Empty, true)
		return true
	end	
	return false
end

function DramaStateBase:set_wave_flag(enable)
	SoundDevice:set_state("wave_flag", enable and "assault" or "control")
end

function DramaStateBase:owner()
	return self._machine:owner()
end

function DramaStateBase:is_owner_alive()
	return self._machine:is_owner_alive()
end

function DramaStateBase:character_name()
	return self._machine:character_name()
end

function DramaStateBase:ignore_tension()
	return false
end

function DramaStateBase:current_tension()
	return self._machine:current_tension()
end

function DramaStateBase:set_manager(manager)
	self._drama_manager = manager
end

function DramaStateBase:debug_prefix()
	return "DramaStateBase"
end

function DramaStateBase:log_state()
	if self.DEBUG_ENABLED then
		CellGlobal:log("You are now in " .. self._machine:current_state_name())
	end
end


function DramaStateBase:set_owner(owner)
	self._owner = owner
end


function DramaStateBase:on_local_damage(record, attacker, dmg_percentage)
end

function DramaStateBase:on_teammate_damage(record, attacker, dmg_percentage)
end


function DramaStateBase:on_local_disabled(record)
end

function DramaStateBase:on_teammate_disabled(record)
end


function DramaStateBase:on_local_neutralized(record)
end

function DramaStateBase:on_teammate_neutralized(record)
end