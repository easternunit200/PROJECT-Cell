DramaStateIdle = DramaStateIdle or blt_class(DramaStateBase)

function DramaStateIdle:common_update(t, dt)

	if managers.platform:presence() ~= "Idle" then
		
		
		if self._drama_manager:go_to_chill() then
			self._machine:change_drama_state(DramaMachine.STATES.Chill, true)
			return
		end
	
		if self._drama_manager:go_to_fake_assault() then
			self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
			return
		end		
		
	
		if self._drama_manager:go_to_assault() then
			self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
			return
		end		
		
		if self._drama_manager:go_to_control() then
			self._machine:change_drama_state(DramaMachine.STATES.Control, true)
			return
		end
		

		
		if self._drama_manager:go_to_sneaking() then
			self._machine:change_drama_state(DramaMachine.STATES.Sneaking, true)
			return
		end	
		
	end
		
	
end

function DramaStateIdle:update(t, dt)
	self:common_update(t, dt)
end

function DramaStateIdle:sync_update(t, dt)
	self:common_update(t, dt)
end

function DramaStateIdle:revive_lines_allowed()
	return false
end

function DramaStateIdle:ignore_tension()
	return true
end

function DramaStateIdle:debug_prefix()
	return "DramaStateIdle"
end