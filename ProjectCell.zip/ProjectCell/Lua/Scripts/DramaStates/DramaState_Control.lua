DramaStateControl = DramaStateControl or blt_class(DramaStateBase)
DramaStateControl.SpeechMaps = {
	"branchbank",
	"red2",
	"firestarter_3",
	"big",
	"bex",
	"roberts"		
}		

function DramaStateControl:_setup_weapons_hot()
	local level_id = Global.level_data and Global.level_data.level_id
	if level_id then
		if table.contains(DramaStateControl.SpeechMaps, level_id) then
			managers.groupai:state():add_listener("DramaStateControl_on_weapons_hot" .. tostring(self._machine:owner_key()), "enemy_weapons_hot", callback(self,self, "on_weapons_hot"))
		end					
	end	
end

function DramaStateControl:setup()	
	self._speech_enter_goalTimer = nil
	self._speech_enterTimer = 0
	self:_setup_weapons_hot()
end

function DramaStateControl:on_weapons_hot()	
	self._speech_enter_goalTimer = math.rand(10,20)
end


function DramaStateControl:exit()
	self._speech_enter_goalTimer = nil
end

function DramaStateControl:enter(exit_data)
	managers.cell_music:change_state(MusicMachine.MUS_States.Control)
	self:set_wave_flag(false)
end

function DramaStateControl:common_update(t,dt)
	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end
	
	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end
	
	if self._drama_manager:go_to_sneaking() then
		self._machine:change_drama_state(DramaMachine.STATES.Sneaking, true)
		return
	end
	
	if self._machine:is_locally_owned() then
		self:update_speech_check(dt)
	end
end





function DramaStateControl:update_speech_check(dt)
	if not self._speech_enter_goalTimer then
		self._speech_enterTimer = 0
		return
	end
	
	self._speech_enterTimer = self._speech_enterTimer + dt
	if self._speech_enterTimer > self._speech_enter_goalTimer then
		if managers.cell_user:is_cell_host() then
			local best_canditate = self._drama_manager:get_best_canditate("project_cell_tog_heat_speech", false, nil)	
			if best_canditate then
				best_canditate:sound():say("v34", true, true)
			end		
		end		
		self._speech_enter_goalTimer = nil
	end
end

function DramaStateControl:update(t, dt)
	self:common_update(t,dt)	
end

function DramaStateControl:sync_update(t, dt)
	self:common_update(t,dt)	
end


function DramaStateControl:idle_dialog()
	
end

function DramaStateControl:debug_prefix()
	return "DramaStateControl"
end

