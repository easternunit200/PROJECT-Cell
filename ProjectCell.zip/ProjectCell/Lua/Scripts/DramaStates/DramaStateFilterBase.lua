DramaStateFilterBase = DramaStateFilterBase or blt_class()

function DramaStateFilterBase:go_to_chill()
	return managers.cell_job:is_chill_heist()
end

function DramaStateFilterBase:go_to_sneaking()
	return managers.groupai:state():whisper_mode()
end

function DramaStateFilterBase:go_to_encounter()
	return managers.cell_drama:any_enemies_alarmed()
end

function DramaStateFilterBase:go_to_assault()	 
	return not self:go_to_sneaking() and managers.groupai:state():get_assault_mode()
end

function DramaStateFilterBase:go_to_alert()	
	return self:go_to_sneaking() or self:go_to_control()
end

function DramaStateFilterBase:go_to_control()
	return not self:go_to_sneaking() and not self:go_to_assault()
end

function DramaStateFilterBase:go_to_fake_assault()
	return false
end

function DramaStateFilterBase:go_to_anticipation()
	return false
end

function DramaStateFilterBase:go_to_discovered()
	return false
end