DramaStateAssault = DramaStateAssault or blt_class(DramaStateBase)
DramaStateAssault.Combat_CallOut_Tension_Filter = {
	Min = 60,
	Max = 100
}
DramaStateAssault.Combat_CallOut_Delay = {
	Min = 4,
	Max = 10
}
DramaStateAssault.Combat_Callout_Chance = {
	Min = 0.005,
	Max = 0.05
}
DramaStateAssault.Combat_Hurt_Data = {
	criminal_hurt = 0.5,
	max_dis = 6000,
	dis_mul = 0.5
}

DramaStateAssault.Combat_Tension_Data = {
	cooldown_start = 1,
	cooldown_tension_decr = 12
}

function DramaStateAssault:setup()
	self._shooting_t_check = 3
	self._enter_clbk_id = "DramaStateAssault_Enter"
	self._first_assault_wave = true	
	self:reset_damages()
end

function DramaStateAssault:reset_damages()
	self._total_local_damage = 0
	self._total_teammate_damage = 0
	
	self._criminal_hurt_tension = 0
	self._criminal_hurt_cooldown = 0
end




function DramaStateAssault:enter(exit_data)
	if self._first_assault_wave then
		self._first_assault_wave = false
	end
	
	
	self:reset_damages()
	
	self:set_wave_flag(true)
	managers.cell_music:change_state(MusicMachine.MUS_States.Assault)
	self._last_combat_chatter_t = nil
	if self._machine:last_state_name() == DramaMachine.STATES.Control or self._machine:last_state_name() == DramaMachine.STATES.Anticipation or self._machine:last_state_name() == DramaMachine.STATES.Alert then
		managers.cell_callback:add_delayed_callback(self._enter_clbk_id, math.rand(1,1.25), callback(self,self,"enter_chatter"))	
	end	
end


function DramaStateAssault:enter_chatter()
	if not managers.cell_user:is_cell_host() then
		return
	end
	
	
	local best_canditate = self._drama_manager:get_best_canditate("project_cell_assault_sli", true, "project_cell_bot_assault_sli")	
	if best_canditate then
		best_canditate:sound():say("a01x_any",true,true)
	end
end

function DramaStateAssault:check_player_combat_chatter(t)
	if self:is_owner_alive() then
		local current_movement_state = self:owner():movement():current_state()
		local shooting_t = current_movement_state._shooting_t
		if shooting_t then
			if t < shooting_t + self._shooting_t_check then
				self:chk_say_player_combat_chatter(t)
			end
		end
	end
end



function DramaStateAssault:get_state_tension()
	return self._criminal_hurt_tension
end


function DramaStateAssault:common_update(t,dt)
	if self._drama_manager:go_to_alert() then
		self._machine:change_drama_state(DramaMachine.STATES.Alert, true)
		return
	end	
	
	self:update_criminal_hurt_tension(t,dt)
	
	if self._machine:is_locally_owned() then
		self:check_player_combat_chatter(t)
	end
end

function DramaStateAssault:update(t, dt)	
	self:common_update(t,dt)	
end

function DramaStateAssault:sync_update(t, dt)	
	self:common_update(t,dt)		
end


function DramaStateAssault:chk_say_player_combat_chatter(t)	
	if self._machine:is_seperated_from_teammates() then
		return
	end
	
	
	local current_tension = self._machine:current_tension()
	if current_tension < DramaStateAssault.Combat_CallOut_Tension_Filter.Min then
		return
	end
	
	if self._machine:enemies_in_field_of_view() < 2 then
		return
	end
	

	
	
	local tension_val = (math.min(current_tension, DramaStateAssault.Combat_CallOut_Tension_Filter.Max) - DramaStateAssault.Combat_CallOut_Tension_Filter.Min) / (DramaStateAssault.Combat_CallOut_Tension_Filter.Max - DramaStateAssault.Combat_CallOut_Tension_Filter.Min)
	if self._last_combat_chatter_t then

		local delay = math.lerp(DramaStateAssault.Combat_CallOut_Delay.Max, DramaStateAssault.Combat_CallOut_Delay.Min, tension_val)
		local delay_t = self._last_combat_chatter_t + delay
		
		if t < delay_t then
			return
		end
		
	end
	
	local chance = math.lerp(DramaStateAssault.Combat_Callout_Chance.Min, DramaStateAssault.Combat_Callout_Chance.Max, tension_val)
	local rand = math.random()

	if chance < rand then
		return
	end
	
	self._last_combat_chatter_t = t	
	if managers.cell_options:has_toggled("project_cell_combat_idle_tog") then
		if not self:owner():movement():downed() then
			self:owner():sound():say("g90", true, true)
		end
	end	
end

function DramaStateAssault:debug_prefix()
	return "DramaStateAssault"
end

function DramaStateAssault:idle_dialog()
end


function DramaStateAssault:update_criminal_hurt_tension(t,dt)
	if self._criminal_hurt_cooldown <= 0 then
		return
	end
	
	
	self._criminal_hurt_cooldown = self._criminal_hurt_cooldown - dt
	
	if self._criminal_hurt_cooldown <= 0 then
	
		self._criminal_hurt_tension = math.max(0, self._criminal_hurt_tension - DramaStateAssault.Combat_Tension_Data.cooldown_tension_decr)
		
		if self._criminal_hurt_tension > 0 then
			self._criminal_hurt_cooldown = DramaStateAssault.Combat_Tension_Data.cooldown_start - math.abs(self._criminal_hurt_cooldown)
		end
		
	end
end


function DramaStateAssault:on_criminal_damage(hurt_unit, attacker, dmg_percent)
	local drama_amount = DramaStateAssault.Combat_Hurt_Data.criminal_hurt * dmg_percent
	if alive(attacker) then
		local distance = mvector3.distance(attacker:movement():m_pos(), hurt_unit:movement():m_pos())
		local dis_lerp = math.min(1, distance / DramaStateAssault.Combat_Hurt_Data.max_dis)
		dis_lerp = math.lerp(1, DramaStateAssault.Combat_Hurt_Data.dis_mul, dis_lerp)
		drama_amount = drama_amount * dis_lerp
	end
	
	
	self._criminal_hurt_tension = math.min(100, self._criminal_hurt_tension + (drama_amount * 100))
	
	self._criminal_hurt_cooldown = DramaStateAssault.Combat_Tension_Data.cooldown_start
end

function DramaStateAssault:on_local_damage(record, attacker, dmg_percent)
	self._total_local_damage = self._total_local_damage + dmg_percent
	
	self:on_criminal_damage(record.unit, attacker, dmg_percent)
end

function DramaStateAssault:on_teammate_damage(record, attacker, dmg_percent)
	self._total_teammate_damage = self._total_teammate_damage + dmg_percent
	
	self:on_criminal_damage(record.unit, attacker, dmg_percent)
end