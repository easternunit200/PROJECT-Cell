DramaStateCustody = DramaStateCustody or blt_class(DramaStateBase)


function DramaStateCustody:common_update(t, dt)
	if self._machine:is_in_custody() then
		return
	end
	
	
	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end	
	
	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end	
	
	if self._drama_manager:go_to_control() then
		self._machine:change_drama_state(DramaMachine.STATES.Control, true)
		return
	end
	
	if self._drama_manager:go_to_sneaking() then
		self._machine:change_drama_state(DramaMachine.STATES.Sneaking, true)
	end	
		
		
	
end


function DramaStateCustody:update(t, dt)
	self:common_update(t,dt)
end


function DramaStateCustody:sync_update(t, dt)
	self:common_update(t,dt)
end

function DramaStateCustody:ignore_tension()
	return true
end

function DramaStateCustody:debug_prefix()
	return "DramaStateCustody"
end