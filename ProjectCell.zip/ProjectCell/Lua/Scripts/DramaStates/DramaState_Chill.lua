DramaStateChill = DramaStateChill or blt_class(DramaStateBase)

function DramaStateChill:setup()
	self._clbk_id = "DramaStateChill_enter_state"
end

function DramaStateChill:enter(exit_data)
	self:set_wave_flag(false)
	managers.cell_music:start_sneaking_music()
end

function DramaStateChill:common_update(t,dt)

	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end
	
	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end
	
	
	if self._drama_manager:go_to_control() then
		self._machine:change_drama_state(DramaMachine.STATES.Control, true)
		return
	end
	
	if self._drama_manager:go_to_discovered() then
		self._machine:change_drama_state(DramaMachine.STATES.Discovered, true)
		return
	end
	
end
 

function DramaStateChill:update(t, dt)
	self:common_update(t,dt)	
end

function DramaStateChill:sync_update(t, dt)
	self:common_update(t,dt)	
end

function DramaStateChill:tension_on_hurt()
	return false
end


function DramaStateChill:debug_prefix()
	return "DramaStateChill"
end

