DramaStateDiscovered = DramaStateDiscovered or blt_class(DramaStateBase)

function DramaStateDiscovered:setup()
	self._go_back_to_sneaking_timer = 0
	self._go_back_to_sneaking_goaltimer = 3
	self._discovered_music_timer = nil
	self._discovered_music_cooldown = 30
	self._discovered_locally = false
end

function DramaStateDiscovered:queue_music_event()
	if not self._discovered_music_timer or self._discovered_music_timer + self._discovered_music_cooldown < self._t then
		self._discovered_music_timer = self._t
		managers.cell_music:change_to_an_upcoming_suspense_state(1)
	end
end	

function DramaStateDiscovered:enter(exit_data)
	self._go_back_to_sneaking_timer = 0
	self:queue_music_event()	
	if self._discovered_locally and self._machine:is_owner_alive_and_not_downed() then
		if managers.cell_options:has_toggled("project_cell_detection_comment_tog") then
			self._machine:owner():sound():say("g29")
		end		
	end
end

function DramaStateDiscovered:exit()
	local exit_data = {}
	if self._machine:current_state_name() == DramaMachine.STATES.Alert then
		exit_data.skip_control_music = true	
	end	
	return exit_data
end

function DramaStateDiscovered:set_discovered_locally(is_locally_discovered)
	self._discovered_locally = is_locally_discovered
end

function DramaStateDiscovered:update(t,dt)
	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end
	
	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end	
	
	if self._drama_manager:go_to_control() then
		self._machine:change_drama_state(DramaMachine.STATES.Control, true)
		return
	end
	
	self:update_discovered(t,dt)
end

function DramaStateDiscovered:update_discovered(t,dt)
	if self._drama_manager:any_enemies_alarmed() then
		self._go_back_to_sneaking_timer = 0
	else
		self._go_back_to_sneaking_timer = self._go_back_to_sneaking_timer + dt
	end	
	
	if self._go_back_to_sneaking_timer > self._go_back_to_sneaking_goaltimer then
		self._machine:change_drama_state(DramaMachine.STATES.Alert, true)
	end	
end


function DramaStateDiscovered:debug_prefix()
	return "DramaStateDiscovered"
end

function DramaStateDiscovered:tension_on_hurt()
	return false
end

