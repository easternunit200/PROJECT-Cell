DramaStateEmpty = DramaStateEmpty or blt_class(DramaStateBase)

function DramaStateEmpty:setup()
	self._victory_line_time = 0
	self._victory_line_goal_time = 20
	self._victory_line_said = false
	self._victory_line_check_enabled = false
end

function DramaStateEmpty:enable_victory_line_check(enabled)
	self._victory_line_check_enabled = enabled
end



function DramaStateEmpty:update(t,dt)	
	if self._victory_line_check_enabled then
		self:check_for_victory_line(dt)
	end	
end

function DramaStateEmpty:ignore_tension()
	return true
end

function DramaStateEmpty:debug_prefix()
	return "DramaStateEmpty"
end

function DramaStateEmpty:check_for_victory_line(dt)
	if self._victory_line_said then
		return
	end
	
	
	self._victory_line_time = self._victory_line_time + dt
	
	if self._victory_line_time > self._victory_line_goal_time then
		self._victory_line_said = true
		managers.dialog:queue_narrator_dialog("g02x", {})
	end
end