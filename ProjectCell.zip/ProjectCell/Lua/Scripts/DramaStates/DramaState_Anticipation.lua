DramaStateAnticipation = DramaStateAnticipation or blt_class(DramaStateBase)
DramaStateAnticipation._clbk_id = "DramaStateAnticipation_anticipation_comment"

function DramaStateAnticipation:setup()
	self._time_before_going_down = 50
	self._callback_close_to_assault = "DramaStateAnticipation_close_to_assault"
	self._callback_assault_closing_30s = "DramaStateAnticipation_assault_coming_30s"
	self._callback_assault_closing_25s = "DramaStateAnticipation_assault_coming_25s"
	self._anticipation_announcer = nil
end


function DramaStateAnticipation:enter(exit_data)
	managers.cell_music:change_state(MusicMachine.MUS_States.Anticipation)
	if self._machine:last_state_name() == DramaMachine.STATES.Control or self._machine:last_state_name() == DramaMachine.STATES.Alert then
		self:determine_announcer_user()
		self:start_anticiption_comments()
	end
end

function DramaStateAnticipation:exit()
	managers.cell_callback:remove_delayed_clbk(self._callback_assault_closing_25s)
	managers.cell_callback:remove_delayed_clbk(self._callback_assault_closing_30s)
	managers.cell_callback:remove_delayed_clbk(self._callback_close_to_assault)
end

function DramaStateAnticipation:determine_announcer_user()
	if not managers.cell_user:is_cell_host() then
		return
	end
		
	local best_canditate = self._drama_manager:get_best_canditate("project_cell_anticipation_sli", true, "project_cell_bot_anticipation_sli")	
	if best_canditate then
		self._anticipation_announcer = best_canditate
	end
end

function DramaStateAnticipation:start_anticiption_comments()
	local timer = 30		
	managers.cell_callback:add_delayed_callback(self._callback_close_to_assault, timer - 3, callback(self,self, "assault_super_closing"))
	timer = timer - 5
	managers.cell_callback:add_delayed_callback(self._callback_assault_closing_25s, timer, callback(self, self, "anticipation_comment", "g50"))
	timer = timer - 20
	managers.cell_callback:add_delayed_callback(self._callback_assault_closing_30s, timer, callback(self, self, "anticipation_comment", "g62"))
end

function DramaStateAnticipation:anticipation_comment(comment)
	if not managers.cell_user:is_cell_host() then
		return
	end
	
	if self._anticipation_announcer and alive(self._anticipation_announcer) then
		self._anticipation_announcer:sound():say(comment, true, true)
	end
end

function DramaStateAnticipation:assault_super_closing()
	if self:is_owner_alive() then
		local get_ready = "a01x_any"
		-- if self:character_name() == "russian" then
			-- if math.random() < 0.25 then
				-- get_ready = "Play_rb4_sh21_01"
			-- end
		-- end
		if not self:owner():movement():downed() then
			self:owner():sound():say(get_ready, false, false)
		end
	end	
end


function DramaStateAnticipation:debug_prefix()
	return "DramaStateAnticipation"
end

function DramaStateAnticipation:common_update(t, dt)

	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end
	
	if self._drama_manager:go_to_sneaking() then
		self._machine:change_drama_state(DramaMachine.STATES.Sneaking, true)
		return
	end
	
	
	if t - self._state_change_t > self._time_before_going_down then
		self:debug_print("Was in the anticipation state for too long, switching to Alert State")
		self._machine:change_drama_state(DramaMachine.STATES.Alert, true)
		return
	end	
	
end

function DramaStateAnticipation:update(t, dt)
	self:common_update(t,dt)
end

function DramaStateAnticipation:sync_update(t, dt)
	self:common_update(t,dt)
end

function DramaStateAnticipation:start_delayed_dialogue()
	--DeadLocke:add_delayed_clbk(self._start_dialog_clbk_data.id, math.rand(22, 27), self._start_dialog_clbk_data.clbk)
end

function DramaStateAnticipation:debug_prefix()
	return "DramaStateAnticipation"
end