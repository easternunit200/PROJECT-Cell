DramaStateEncounter = DramaStateEncounter or blt_class(DramaStateBase)

function DramaStateEncounter:setup()
	self._clbk_id = "DramaStateEncounter_enter_state"
end

function DramaStateEncounter:enter(exit_data)
	self:set_wave_flag(false)
end

function DramaStateEncounter:idle_dialog()
end

function DramaStateEncounter:revive_line_on_downed_teammate(...)
	return nil
end

function DramaStateEncounter:common_update(t,dt)

	if self._drama_manager:go_to_fake_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.FakeAssault, true)
		return
	end
	
	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end
	
	if self._drama_manager:go_to_sneaking() then
		self._machine:change_drama_state(DramaMachine.STATES.Sneaking, true)
		return
	end
	
	if self._drama_manager:go_to_control() then
		self._machine:change_drama_state(DramaMachine.STATES.Control, true)
	end
end

function DramaStateEncounter:update(t, dt)
	self:common_update(t,dt)
end

function DramaStateEncounter:sync_update(t, dt)
	self:common_update(t,dt)
end

function DramaStateEncounter:tension_on_hurt()
	return false
end

function DramaStateEncounter:start_delayed_dialog()
end

function DramaStateEncounter:debug_prefix()
	return "DramaStateEncounter"
end