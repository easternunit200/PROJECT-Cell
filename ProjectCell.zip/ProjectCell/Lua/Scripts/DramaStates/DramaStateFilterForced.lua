DramaStateFilterForced = DramaStateFilterForced or class(DramaStateFilterBase)

function DramaStateFilterForced:set_forced_state(forced_state)
	self._forced_state = forced_state
end

function DramaStateFilterForced:go_to_chill()
	return self._forced_state == DramaMachine.STATES.Chill
end

function DramaStateFilterForced:go_to_sneaking()
	return self._forced_state == DramaMachine.STATES.Sneaking
end

function DramaStateFilterForced:go_to_encounter()
	return self._forced_state == DramaMachine.STATES.Encounter
end

function DramaStateFilterForced:go_to_assault()	 
	return self._forced_state == DramaMachine.STATES.Assault
end

function DramaStateFilterForced:go_to_alert()
	return self._forced_state == DramaMachine.STATES.Alert
end

function DramaStateFilterForced:go_to_control()
	return self._forced_state == DramaMachine.STATES.Control
end

function DramaStateFilterForced:go_to_fake_assault()
	return self._forced_state == DramaMachine.STATES.FakeAssault
end

function DramaStateFilterForced:go_to_anticipation()
	return self._forced_state == DramaMachine.STATES.Anticipation
end

function DramaStateFilterForced:go_to_discovered()
	return self._forced_state == DramaMachine.STATES.Discovered
end