DramaStateFilterClient = DramaStateFilterClient or class(DramaStateFilterBase)

function DramaStateFilterClient:go_to_assault()	 
	return managers.cell_drama:check_synced_states(DramaMachine.STATES.Assault)
end

function DramaStateFilterClient:go_to_alert()
	return managers.cell_drama:check_synced_states(DramaMachine.STATES.Alert)
end

function DramaStateFilterClient:go_to_control()
	return managers.cell_drama:check_synced_states(DramaMachine.STATES.Control)
end

function DramaStateFilterClient:go_to_fake_assault()
	return managers.cell_drama:check_synced_states(DramaMachine.STATES.FakeAssault)
end

function DramaStateFilterClient:go_to_anticipation()
	return managers.cell_drama:check_synced_states(DramaMachine.STATES.Anticipation)
end

function DramaStateFilterClient:go_to_discovered()
	return managers.cell_drama:check_synced_states(DramaMachine.STATES.Discovered)
end