DramaStateFilterChill = DramaStateFilterChill or blt_class(DramaStateFilterBase)

function DramaStateFilterChill:go_to_chill()
	return true
end

function DramaStateFilterChill:go_to_sneaking()
	return false
end

function DramaStateFilterChill:go_to_encounter()
	return false
end

function DramaStateFilterChill:go_to_assault()	 
	return false
end

function DramaStateFilterChill:go_to_alert()	
	return false
end

function DramaStateFilterChill:go_to_control()
	return false
end

function DramaStateFilterChill:go_to_fake_assault()
	return false
end

function DramaStateFilterChill:go_to_anticipation()
	return false
end

function DramaStateFilterChill:go_to_discovered()
	return false
end