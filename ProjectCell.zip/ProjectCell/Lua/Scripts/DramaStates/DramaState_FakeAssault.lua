DramaStateFakeAssault = DramaStateFakeAssault or blt_class(DramaStateBase)

DramaStateFakeAssault.Announce_Loud_Id = "ItsTimeToGetRich"

function DramaStateFakeAssault:setup()
	self._time_before_going_down = 35
	self._said_loud = false
	self._control_event_skip = false
end


function DramaStateFakeAssault:_announce_loud()
	if self._said_loud then
		return
	end
	
	self._said_loud = true
	
	local best_user = managers.cell_user:get_best_canditate(nil, false, nil)	
	if best_user then
		best_user:sound():say("p47",true,true)
	end
	
end

function DramaStateFakeAssault:exit()	
	if self._control_event_skip then
		self._control_event_skip = false
		managers.cell_music:remove_skip_event("control")	
	end	
end


function DramaStateFakeAssault:enter(exit_data)	
	self:set_wave_flag(true)	
	
	if managers.cell_music:is_current_track_pdth() then
		managers.cell_music:change_state(MusicMachine.MUS_States.Assault)
		self._control_event_skip = true
		managers.cell_music:add_skip_event("control")	
	else
		managers.cell_music:change_state(MusicMachine.MUS_States.Control)
	end		
	
	managers.cell_callback:add_delayed_callback(DramaStateFakeAssault.Announce_Loud_Id, 1, callback(self,self,"_announce_loud"))
	self._player_last_combat_chatter_t = nil
end

function DramaStateFakeAssault:common_update(t, dt)

	if self._drama_manager:go_to_assault() then
		self._machine:change_drama_state(DramaMachine.STATES.Assault, true)
		return
	end	
	
	if t - self._machine:state_enter_t() > self._time_before_going_down then		
		if self._drama_manager:go_to_alert() then
			self._machine:change_drama_state(DramaMachine.STATES.Alert, true)
			return
		end		
	end
	
		
end

function DramaStateFakeAssault:update(t,dt)
	self:common_update(t,dt)
end

function DramaStateFakeAssault:sync_update(t,dt)
	self:common_update(t,dt)
end


function DramaStateFakeAssault:idle_dialog()
	managers.player_dialog:queue_dialog(27, {})
end

function DramaStateFakeAssault:debug_prefix()
	return "DramaStateFakeAssault"
end
