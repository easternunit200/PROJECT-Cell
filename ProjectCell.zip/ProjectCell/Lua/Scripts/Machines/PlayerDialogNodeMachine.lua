PlayerDialogNodeMachine = PlayerDialogNodeMachine or blt_class(StateMachine)

function PlayerDialogNodeMachine:init()
	self._current_dialog_id = 0
end