CallBackMachine = CallBackMachine or blt_class(StateMachine)

function CallBackMachine:init(manager)
	CallBackMachine.super.init(self)
	self._manager = manager
	self._delayed_callbacks = {}
end

function CallBackMachine:update_callbacks(t)
	for i, clbk_data in pairs(self._delayed_callbacks) do	
		if clbk_data and clbk_data.goaltimer < t then
			local remove_clbk_data = table.remove(self._delayed_callbacks, i)			
			remove_clbk_data.clbk()			
		end
	end
end

function CallBackMachine:remove_delayed_clbk(id)	
	for i, clbk_data in pairs(self._delayed_callbacks) do	
		if clbk_data and clbk_data.id == id then
			table.remove(self._delayed_callbacks, i)
			return
		end
	end
end

function CallBackMachine:add_delayed_callback(id, timer, clbk)
	self:remove_delayed_clbk(id)
	
	local clbk_data = {
		id = id,
		goaltimer = self._t + timer,
		clbk = clbk
	}
	
	
	table.insert(self._delayed_callbacks, clbk_data)
end



function CallBackMachine:update(t,dt)
	self:update_callbacks(t)
end