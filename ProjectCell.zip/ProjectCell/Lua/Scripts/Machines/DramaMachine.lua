dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Base.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Empty.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Idle.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Assault.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_FakeAssault.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Control.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Sneaking.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Encounter.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Alert.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Anticipation.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Custody.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Chill.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaState_Discovered.lua")

DramaMachine = DramaMachine or blt_class(StateMachine)
DramaMachine.STATES = {}
DramaMachine.STATES.Empty = "empty"
DramaMachine.STATES.Idle = "idle"
DramaMachine.STATES.Sneaking = "sneaking"
DramaMachine.STATES.Encounter = "encounter"
DramaMachine.STATES.Alert = "alert"
DramaMachine.STATES.Control = "control"
DramaMachine.STATES.Anticipation = "anticipation"
DramaMachine.STATES.Assault = "assault"
DramaMachine.STATES.FakeAssault = "fake_assault"
DramaMachine.STATES.Custody = "custody"
DramaMachine.STATES.Uno = "uno"
DramaMachine.STATES.Discovered = "discovered"
DramaMachine.STATES.Chill = "chill"

function DramaMachine:init(drama_manager)
	DramaMachine.super.init(self)	
	self._drama_manager = drama_manager
	
	self._has_owner = false
	self._game_over_state = false
	self:_setup_tension_upt()	
	self:_setup_tension_running()	
	self:_setup_tension_enemies()	
	self:_setup_tension_turrets()	
	self:_setup_tension_damage()
	self:_setup_civilians()
	self._sights = {}
	self:_setup_states()
end


function DramaMachine:owner()
	return self._owner
end

function DramaMachine:owner_key()
	return self._owner_key
end

function DramaMachine:set_owner(unit, name)
	self._owner = unit
	self._owner_key = unit:key()
	self._character = name
	self._has_owner = true
end

function DramaMachine:is_bot()
	return self._is_bot
end

function DramaMachine:_setup_tension_upt()
	self._updateTensionTimer = 0
	self._updateTensionFirst = false
	self._updateTensionDelay = 0.5	
end


function DramaMachine:_setup_tension_running()
	self._tenRunCurr = 0
	self._tenRunInc = 5
	self._tenRunDec = 4
	self._tenRunMax = 40
end

function DramaMachine:_setup_civilians()
	self._civialianRange = 20
end


function DramaMachine:_setup_tension_enemies()
	self._tenEnemiesCurr = 0	
	self._tenEnemiesInc = 20	
	self._tenEnemiesDec = 4
	
	self._tenEnemiesShootingCost = 20
	self._tenEnemiesSightCost = 8
	self._tenEnemiesInCombatCost = 8
	
	self._tenMaxEnemiesShootingRange = 20000
	self._tenMaxEnemiesRange = 1000
	self._tenMaxTeammateRelevance = 20000
end

function DramaMachine:_setup_tension_turrets()
	self._tenEnemyTurretsCurr = 0
	self._tenEnemyTurretsSightInc = 8
	self._tenEnemyTurretsInc = 10
	self._tenEnemyTurretsDec = 4
	self._tenEnemyTurretsRange = 35
end

function DramaMachine:_setup_tension_damage()
	self._tenHurtCurr = 0
	self._tenHurtInc = 8
	self._tenHurtDec = 4
	self._tenHurtMax = 40
end

function DramaMachine:_setup_state_instances()
	self._drama_state_empty = DramaStateEmpty:new()
	self._drama_state_idle = DramaStateIdle:new()
	self._drama_state_sneaking = DramaStateSneaking:new()
	self._drama_state_encounter = DramaStateEncounter:new()
	self._drama_state_alert = DramaStateAlert:new()
	self._drama_state_control = DramaStateControl:new()
	self._drama_state_anticipation = DramaStateAnticipation:new()
	self._drama_state_assault = DramaStateAssault:new()
	self._drama_state_fake_assault = DramaStateFakeAssault:new()
	self._drama_state_custody = DramaStateCustody:new()
	self._drama_state_uno = DramaStateEmpty:new()
	self._drama_state_discovered = DramaStateDiscovered:new()
	self._drama_state_chill = DramaStateChill:new()
end

function DramaMachine:_setup_states()
	self:enable_debug(true)
	
	self:_setup_state_instances()
	
	
	
	self:add_state(DramaMachine.STATES.Empty, self._drama_state_empty)
	self:add_state(DramaMachine.STATES.Idle, self._drama_state_idle)
	self:add_state(DramaMachine.STATES.Sneaking, self._drama_state_sneaking)
	self:add_state(DramaMachine.STATES.Encounter, self._drama_state_encounter)
	self:add_state(DramaMachine.STATES.Alert, self._drama_state_alert)
	self:add_state(DramaMachine.STATES.Control, self._drama_state_control)
    self:add_state(DramaMachine.STATES.Anticipation, self._drama_state_anticipation)	
	self:add_state(DramaMachine.STATES.Assault, self._drama_state_assault)
	self:add_state(DramaMachine.STATES.FakeAssault, self._drama_state_fake_assault)	
	self:add_state(DramaMachine.STATES.Custody, self._drama_state_custody)	
	self:add_state(DramaMachine.STATES.Uno, self._drama_state_uno)	
	self:add_state(DramaMachine.STATES.Chill, self._drama_state_chill)	
	self:add_state(DramaMachine.STATES.Discovered, self._drama_state_discovered)	
	
	for _, state in pairs(self._states) do
		if state then
			state:set_manager(self._drama_manager)
		end
	end	
	
	self:set_start_state(self._drama_state_idle)
end

function DramaMachine:character_name()
	return self._character
end

function DramaMachine:get_cell_user()
	return managers.cell_user:get_cell_user_by_character(self._character)
end

function DramaMachine:is_runnning()
	if self:is_locally_owned() then
		if self._owner and alive(self._owner) and self._owner.movement and self._owner:movement() then
			return self._owner:movement():running()
		end
	end	
	return false
end

function DramaMachine:enemy_in_field_of_view(enemy)
	local my_head_pos = self._owner:movement():m_head_pos()
	local cam_fwd	
	if self:is_locally_owned() then
		cam_fwd = self._owner:camera():forward()		
	else
		cam_fwd = self._owner:movement():m_rot():y()	
	end	
	local u_head_pos = enemy:movement():m_head_pos() + math.UP * 30 
	local vec = u_head_pos - my_head_pos
	local dis = mvector3.normalize(vec)
	local ray = World:raycast("ray", my_head_pos, u_head_pos, "slot_mask", managers.slot:get_mask("AI_visibility"), "ray_type", "ai_vision", "ignore_unit", {enemy})
	local max_angle = 90
	local angle = vec:angle(cam_fwd)

	if math.abs(angle) > max_angle then
		return false
	end
	
	if not ray or mvector3.distance_sq(ray.position, u_head_pos) < 900 then
		return true
	end
	
	return false
end

function DramaMachine:enemies_in_field_of_view()
	local amount = 0
	if self:is_owner_alive() then
		for u_key, u_data in pairs(managers.enemy:all_enemies()) do
			if u_data and u_data.unit and alive(u_data.unit) and not u_data.unit:character_damage():dead() then
				if self._owner:movement():team().foes[u_data.unit:movement():team().id] then
					if self:enemy_in_field_of_view(u_data.unit) then
						amount = amount + 1
					end
				end	
			end
		end
	end
	return amount
end


function DramaMachine:is_hurt()
	if not self._owner or not alive(self._owner) then
		return false
	end
	return self._owner:character_damage():get_armor_regenerate_timer() > 0
end

function DramaMachine:is_sight_with_owner_or_teammate(enemy_head_pos)
	local owner_head_pos = self._owner:movement():m_head_pos()
	if managers.cell_world:in_sight(owner_head_pos, enemy_head_pos) then
		return true
	end	
	for u_key, u_data in pairs(managers.groupai:state():all_char_criminals()) do
		if self._owner_key ~= u_key and u_data and u_data.unit and alive(u_data.unit) then
			local u_head_pos = u_data.unit:movement():m_head_pos()
			local has_sight_owner = managers.cell_world:in_sight(u_head_pos, owner_head_pos)		
			if has_sight_owner then
				local dis = Vector3Utils:distance(self._owner:position(),u_data.unit:position())
				if dis < self._tenMaxTeammateRelevance then
					local has_enemy_sight = managers.cell_world:in_sight(u_head_pos, enemy_head_pos)				
					if has_enemy_sight then
						return true
					end
				end
			end			
		end
	end	
	return false
end

function DramaMachine:is_sight_with_owner(enemy_head_pos)
	local owner_head_pos = self._owner:movement():m_head_pos()
	return managers.cell_world:in_sight(owner_head_pos, enemy_head_pos)
end

function DramaMachine:get_tension_enemy_max()
	local all_char_criminals = managers.groupai:state():all_char_criminals()
	local max_tension = 0
	if self:is_owner_alive() then
		local my_pos = self._owner:position() + math.UP * 30
		for u_key, u_data in pairs(managers.enemy:all_enemies()) do
			if u_data and u_data.unit and alive(u_data.unit) and not u_data.unit:character_damage():dead() then
				if self._owner:movement():team().foes[u_data.unit:movement():team().id] then
					local enemy_pos = u_data.m_pos + math.UP * 30
					--local dis = Vector3Utils:distance(self._owner:position(), enemy_pos)					
					local dis = mvector3.distance_sq(my_pos, enemy_pos)				
					local in_sight = self:is_sight_with_owner(enemy_pos)
					if in_sight or dis < self._tenMaxEnemiesRange then
						max_tension = max_tension + self._tenEnemiesSightCost
					end
			
					if u_data.unit:movement():attention() then	
						local attention = u_data.unit:movement():attention()
						if attention.reaction and attention.reaction >= AIAttentionObject.REACT_COMBAT then 
							if all_char_criminals[attention.unit:key()] then
								max_tension = max_tension + self._tenEnemiesInCombatCost
								if u_data.unit:movement()._allow_fire and dis < DramaStateAssault.Combat_Hurt_Data.max_dis then					
									local dis_lerp = math.min(1, dis / DramaStateAssault.Combat_Hurt_Data.max_dis)
									dis_lerp = math.lerp(1, DramaStateAssault.Combat_Hurt_Data.dis_mul, dis_lerp)						
									max_tension = max_tension + math.floor(self._tenEnemiesShootingCost * dis_lerp)
								end		
							end										
						end
					end
				end	
			end
		end		
	end		
	return max_tension
end

function DramaMachine:get_tension_turret_max()
	local turret_units = managers.groupai:state():turrets()
	local max_tension = 0
	if self._owner and alive(self._owner) then
		if turret_units then
			for _, unit in pairs(turret_units) do
				if alive(unit) and unit:movement():team().foes[self._owner:movement():team().id] then
					local enemy_head_pos = unit:movement():m_head_pos() + math.UP * 30
					local in_sight = managers.cell_world:in_sight(self._owner:movement():m_head_pos(), enemy_head_pos)
					local dis = Vector3Utils:distance(self._owner:position(), enemy_head_pos)
					if in_sight then
						max_tension = max_tension + self._tenEnemyTurretsSightInc
					elseif dis <= self._tenEnemyTurretsRange then
						max_tension = max_tension + self._tenEnemyTurretsInc
					end
				end
			end
		end	
	end
	return max_tension
end


	
		
		
function DramaMachine:is_seperated_from_teammates()
	local range_meters = 20
	for u_key, u_data in pairs(managers.groupai:state():all_char_criminals()) do
		if self._owner_key ~= u_key then
			if u_data and u_data.unit and alive(u_data.unit) then
				local dis = Vector3Utils:distance(self._owner:position(),u_data.m_pos)
				if dis <= range_meters then
					return false
				end
			end
		end	
	end	
	
	return true
end


function DramaMachine:update_tension(t)
	if not self._updateTensionFirst or t > self._updateTensionTimer then
		self._updateTensionFirst = true
		self._updateTensionTimer = t + self._updateTensionDelay
		if self:is_runnning() then
			self._tenRunCurr = math.min(self._tenRunMax, self._tenRunCurr + self._tenRunInc)		
		else
			self._tenRunCurr = math.max(0, self._tenRunCurr - self._tenRunDec)
		end
		
		if self._current_state:tension_on_hurt() and self:is_hurt() then
			if self:current_tension() < self._tenHurtMax  then
				self._tenHurtCurr = self._tenHurtCurr + self._tenHurtInc * self._updateTensionDelay	
			end			
		else
			self._tenHurtCurr = math.max(self._tenHurtCurr - self._tenHurtDec, 0)
		end		
		
		if self._tenEnemiesCurr <  self:get_tension_enemy_max() then
			self._tenEnemiesCurr = math.min(100, self._tenEnemiesCurr + self._tenEnemiesInc)
		else
			self._tenEnemiesCurr = math.max(0, self._tenEnemiesCurr - self._tenEnemiesDec)
		end		
		
		if self._tenEnemyTurretsCurr <  self:get_tension_turret_max() then
			self._tenEnemyTurretsCurr = math.min(100, self._tenEnemyTurretsCurr + self._tenEnemyTurretsInc)
		else
			self._tenEnemyTurretsCurr = math.max(0, self._tenEnemyTurretsCurr - self._tenEnemyTurretsDec)
		end		
	end		
end

function DramaMachine:is_in_custody()
	for i,v in pairs(managers.trade._criminals_to_respawn) do
		if v.id == self:character_name() then
			return true
		end
	end
	return false
end


function DramaMachine:trigger_line(line)
	if self:is_owner_alive_and_not_downed() then
		self._owner:sound():say(line,true,true)
	end	
end

function DramaMachine:get_all_tensions()
	return self._current_state:get_state_tension() + self._tenRunCurr + self._tenEnemiesCurr + self._tenHurtCurr + self._tenEnemyTurretsCurr
end

function DramaMachine:is_owner_alive()
	return self._has_owner and self._owner and alive(self._owner) and true or false
end

function DramaMachine:is_owner_alive_and_not_downed()
	return self._has_owner and self._owner and alive(self._owner) and not self._owner:movement():downed() and true or false
end

function DramaMachine:current_tension()
	return math.clamp(math.floor(self:get_all_tensions()), 0, 100)
end

function DramaMachine:current_enemy_tension()
	return math.clamp(math.floor(self._tenEnemiesCurr), 0, 100)
end

function DramaMachine:civilians_around()
	local amount = 0
	if self:is_owner_alive() then
		for u_key, u_data in pairs(managers.enemy:all_civilians()) do
			if u_data and u_data.unit and alive(u_data.unit) and not u_data.unit:character_damage():dead() then
				local enemy_head_pos = u_data.m_pos + math.UP * 30
				local dis = Vector3Utils:distance(self._owner:position(), enemy_head_pos)					
				local in_sight = self:is_sight_with_owner_or_teammate(enemy_head_pos)
				if in_sight or dis < self._civialianRange then
					amount = amount + 1
				end					
			end
		end		
	end	
	
	return amount
end


function DramaMachine:is_current_state_whisper()
	return self:current_state_name() == DramaMachine.STATES.Sneaking or self:current_state_name() == DramaMachine.STATES.Discovered
end


function DramaMachine:change_drama_state(state, sync)
	if self:current_state_name() == state then
		return
	end	
	
	self:change_state(state)	
	
	
	if sync then
		if self:get_state_by_name(state) then	
			if self:is_locally_owned() then
				if managers.cell_user:has_local_peer() then
					self._drama_manager:want_to_sync_state(managers.cell_user:local_peer_id(), state, self:current_tension())
				else
					self._drama_manager:debug_print("ERROR : Trying to sync drama state without a local peer!")
				end				
			end					
		else
			self._drama_manager:debug_print("ERROR : Cannot sync drama state with an invalid state name! : " .. tostring(state))
		end		
	end	
end

function DramaMachine:check_gameover_state()
	if self._game_over_state then
		return
	end	
	
	
	if self._drama_manager:is_game_over_screen() or self._drama_manager:is_victory_screen() then
		if self._drama_manager:is_victory_screen() and managers.cell_job:is_last_stage() then
			self._drama_state_empty:enable_victory_line_check(true)
		end		
		self:change_drama_state(DramaMachine.STATES.Empty, true)		
		self._game_over_state = true
	end	
end

function DramaMachine:update(t,dt)
	self:check_gameover_state()
	self:update_tension(t)
	self:update_state(t,dt)
end

function DramaMachine:suspicious_ratio_or_status()
	local status = false
	if self:is_owner_alive() then
		status = self._owner:movement()._suspicion_ratio
	end	
	return status
end