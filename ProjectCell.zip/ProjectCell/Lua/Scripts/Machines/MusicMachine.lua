dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Base.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Silence.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Sneaking.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Control.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Anticipation.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Assault.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_FakeAssault.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_Escape.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_AlessoBase.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_AlessoSneaking.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_AlessoControl.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_AlessoAnticipation.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_AlessoAssault.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_AlessoFakeAssault.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_SneakingSuspenseBase.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_SneakingSuspenseLow.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_SneakingSuspenseMedium.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_SneakingSuspenseHigh.lua")
dofile(ModPath .. "Lua/Scripts/MusicStates/MUS_SneakingSuspenseExtreme.lua")

MusicMachine = MusicMachine or blt_class(StateMachine)
MusicMachine.MusicEnabled = true
MusicMachine.MUS_States = {}
MusicMachine.MUS_States.None = "none"
MusicMachine.MUS_States.Silence = "silence"
MusicMachine.MUS_States.Sneaking = "sneaking"
MusicMachine.MUS_States.SneakingSuspenseLow = "sneaking_suspense_low"
MusicMachine.MUS_States.SneakingSuspenseMedium = "sneaking_suspense_medium"
MusicMachine.MUS_States.SneakingSuspenseHigh = "sneaking_suspense_high"
MusicMachine.MUS_States.SneakingSuspenseExtreme = "sneaking_suspense_extreme"
MusicMachine.MUS_States.Control = "control"
MusicMachine.MUS_States.Anticipation = "anticipation"
MusicMachine.MUS_States.Assault = "assault"
MusicMachine.MUS_States.FakeAssault = "fake_assault"
MusicMachine.MUS_States.Escape = "escape"


function MusicMachine:init(music_manager)
	MusicMachine.super.init(self, music_manager)
	self._is_default_music = false
	self._sneaking_track = nil
	self._last_suspense_state = nil
	self._music_manager = music_manager
	self._state_overrides = {}

	self:_setup_all_state_instances()
	self:_setup_suspenses()
	self:_setup_states()
end

function MusicMachine:_setup_state_instances_default()
	self._mus_base = MUS_Base:new()	
	self._mus_sneaking = MUS_Sneaking:new()
	self._mus_control = MUS_Control:new()
	self._mus_anticipation = MUS_Anticipation:new()
	self._mus_assault = MUS_Assault:new()
	self._mus_fake_assault = MUS_FakeAssault:new()	
	self._mus_escape = MUS_Escape:new()	
end

function MusicMachine:_setup_state_instances_alesso()
	self._mus_alesso = MUS_AlessoBase:new()
	self._mus_alesso_sneaking = MUS_AlessoSneaking:new()
	self._mus_alesso_control = MUS_AlessoControl:new()
	self._mus_alesso_anticipation = MUS_AlessoAnticipation:new()
	self._mus_alesso_assault = MUS_AlessoAssault:new()
	self._mus_alesso_fake_assault = MUS_AlessoFakeAssault:new()	
end

function MusicMachine:_setup_state_instances_sneaking()	
	self._mus_sneaking_suspense_low = MUS_SneakingSuspenseLow:new()
	self._mus_sneaking_suspense_medium = MUS_SneakingSuspenseMedium:new()
	self._mus_sneaking_suspense_high = MUS_SneakingSuspenseHigh:new()
	self._mus_sneaking_suspense_extreme = MUS_SneakingSuspenseExtreme:new()
end

function MusicMachine:_setup_all_state_instances()
	self:_setup_state_instances_default()
	self:_setup_state_instances_alesso()
	self:_setup_state_instances_sneaking()
end

function MusicMachine:_setup_states()
	self:enable_debug(false)				
	
	local level_id = Global.level_data and Global.level_data.level_id
	if level_id == "arena" then
		self:_setup_alesso()
	elseif tweak_data.levels[level_id].music == "ghost" then
		self:_setup_ghost()
	else
		self._is_default_music = true
		self:_setup_heist()
	end
	
	self:set_start_state(self._mus_base)
end

function MusicMachine:_setup_heist()
	self._start_state = self._mus_base
	self:add_state(MusicMachine.MUS_States.None, self._mus_base)	
	self:add_state(MusicMachine.MUS_States.Silence, MUS_Silence:new())	
	self:add_state(MusicMachine.MUS_States.Sneaking, self._mus_sneaking)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseLow, self._mus_sneaking_suspense_low)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseMedium, self._mus_sneaking_suspense_medium)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseHigh, self._mus_sneaking_suspense_high)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseExtreme, self._mus_sneaking_suspense_extreme)
	self:add_state(MusicMachine.MUS_States.Control, self._mus_control)
	self:add_state(MusicMachine.MUS_States.Anticipation, self._mus_anticipation)
	self:add_state(MusicMachine.MUS_States.Assault, self._mus_assault)
	self:add_state(MusicMachine.MUS_States.FakeAssault, self._mus_fake_assault)	
	self:add_state(MusicMachine.MUS_States.Escape, self._mus_escape)
end

function MusicMachine:_setup_alesso()
	self._start_state  = self._mus_alesso
	self:add_state(MusicMachine.MUS_States.None, self._mus_base)	
	self:add_state(MusicMachine.MUS_States.Silence, MUS_Silence:new())	
	self:add_state(MusicMachine.MUS_States.Sneaking, self._mus_alesso_sneaking)	
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseLow, self._mus_alesso_sneaking)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseMedium, self._mus_alesso_sneaking)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseHigh, self._mus_alesso_sneaking)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseExtreme, self._mus_alesso_sneaking)	
	self:add_state(MusicMachine.MUS_States.Control, self._mus_alesso_control)
	self:add_state(MusicMachine.MUS_States.Anticipation, self._mus_alesso_anticipation)
	self:add_state(MusicMachine.MUS_States.Assault, self._mus_alesso_assault)
	self:add_state(MusicMachine.MUS_States.FakeAssault, self._mus_alesso_fake_assault)	
	self:add_state(MusicMachine.MUS_States.Escape, self._mus_escape)
end

function MusicMachine:_setup_ghost()
	self._start_state = self._mus_base
	self:add_state(MusicMachine.MUS_States.None, self._mus_base)	
	self:add_state(MusicMachine.MUS_States.Silence, MUS_Silence:new())	
	self:add_state(MusicMachine.MUS_States.Sneaking, self._mus_base)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseLow, self._mus_base)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseMedium, self._mus_base)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseHigh, self._mus_base)
	self:add_state(MusicMachine.MUS_States.SneakingSuspenseExtreme, self._mus_base)
	self:add_state(MusicMachine.MUS_States.Control, self._mus_base)
	self:add_state(MusicMachine.MUS_States.Anticipation, self._mus_base)
	self:add_state(MusicMachine.MUS_States.Assault, self._mus_base)
	self:add_state(MusicMachine.MUS_States.FakeAssault, self._mus_base)	
	self:add_state(MusicMachine.MUS_States.Escape, self._mus_base)
end

function MusicMachine:debug_print(txt)
	if self._debug_enabled then
		CellGlobal:log("MusicMachine - " .. tostring(txt))
	end
end


function MusicMachine:_change_state(mus_state)
	if self._current_state == mus_state then
		if self._debug_enabled  then
			CellGlobal:log("[MusicMachine:_change_state] new mus_state is the same, not changing")
		end
		return
	end	
	
	if MusicMachine.MusicEnabled and mus_state then
		MusicMachine.super._change_state(self, mus_state)
	end	
	
end

function MusicMachine:is_state_name_sneaking_suspense(state_name)	
	return table.contains(self._suspense_states, state_name)
end


function MusicMachine:set_last_suspense_state(state)
	self._last_suspense_state = state
end

function MusicMachine:last_suspense_state()
	return self._last_suspense_state
end


function MusicMachine:change_last_supense_state()
end


function MusicMachine:is_default_music()
	return self._is_default_music
end


function MusicMachine:is_sneaking_state()
	return self._current_state:is_sneaking()
end

function MusicMachine:_setup_suspenses()
	self._suspense_states = {
		MusicMachine.MUS_States.SneakingSuspenseLow,
		MusicMachine.MUS_States.SneakingSuspenseMedium,
		MusicMachine.MUS_States.SneakingSuspenseHigh,
		MusicMachine.MUS_States.SneakingSuspenseExtreme
	}
	
	self._suspense_indexes = {}	
	for index, suspense_state_name in pairs(self._suspense_states) do
		self._suspense_indexes[suspense_state_name] = index
	end
	
	self._min_suspense_state_index = 1
end

function MusicMachine:set_suspense_index(index)
	self._min_suspense_state_index = self:get_fixed_suspense_index(index)	
	self:debug_print("Setting a new minimum suspense index -> " .. tostring(self._min_suspense_state_index))
	self:debug_print("Minimum suspense state name -> " .. tostring(self:get_minimum_suspense_state_name()))
end

function MusicMachine:change_to_minimum_suspense_state()
	if not self._is_default_music then
		return
	end
	
	self:change_state(self:get_minimum_suspense_state_name()) 
end

function MusicMachine:get_minimum_suspense_state_name()
	return self:get_suspense_state_name_by_index(self._min_suspense_state_index)
end


function MusicMachine:set_minimum_suspense_index(suspense_index)
	self:set_suspense_index(suspense_index)
	
	if not self._current_state:is_suspense_state() then
		return
	end	
	
	local new_suspense_state_name = self:get_minimum_suspense_state_name()
	
	local current_state_name = self:current_state_name()
	
	if current_state_name == new_suspense_state_name then
		return
	end	
	
	if self:get_suspense_index_by_name(current_state_name) < self:get_suspense_index_by_name(new_suspense_state_name) then
		self:change_state(new_suspense_state_name)
	end	
	
end

function MusicMachine:update(t,dt)
	self:update_state(t,dt)
end


function MusicMachine:on_pager_call(pager_count)
	local suspense_index = 1
	if pager_count >= 4 then		
		suspense_index = 4
	elseif pager_count >= 3 then	
		suspense_index = 3
	elseif pager_count >= 2 then	
		suspense_index = 2
	end	
	
	self:set_minimum_suspense_index(suspense_index)
end

function MusicMachine:get_fixed_suspense_index(index)
	return math.max(1, math.min(index, #self._suspense_states))
end

function MusicMachine:get_suspense_state_name_by_index(index)
	return self._suspense_states[self:get_fixed_suspense_index(index)]
end

function MusicMachine:get_suspense_index_by_name(suspense_state_name)
	return self._suspense_indexes[suspense_state_name]
end

function MusicMachine:is_suspense_state_locked(suspense_state_name)
	return self._min_suspense_state_index > self:get_suspense_index_by_name(suspense_state_name)
end

function MusicMachine:change_to_an_upcoming_suspense_state(steps)
	if not self._current_state:is_suspense_state() then
		return
	end	
	
	
	local suspense_state_name = self:get_suspense_state_name_by_index(self._min_suspense_state_index + steps)
	
	self._music_manager:change_state(suspense_state_name)
end

