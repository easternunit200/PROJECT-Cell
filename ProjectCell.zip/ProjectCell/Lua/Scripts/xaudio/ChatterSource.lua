local C = blt_class(XAudio.Source)
XAudio.ChatterSource = C

function C:set_volume(gain)
	if gain > XAudio.ChatterUnitSource.highest_volume_limit then
		error("Cannot set gain to more than "..tostring(XAudio.ChatterUnitSource.highest_volume_limit))
	elseif gain < 0 then
		error("Cannot set gain to less than 0")
	end

	self._gain = gain
end