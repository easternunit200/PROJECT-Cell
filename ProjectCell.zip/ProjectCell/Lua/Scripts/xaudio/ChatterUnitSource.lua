local C = blt_class(XAudio.Source)

XAudio.ChatterUnitSource = C
XAudio.ChatterUnitSource.highest_volume_limit = 20
XAudio.ChatterUnitSource.farthest_volume_dis = 2000000
XAudio.ChatterUnitSource.lowest_volume_dis = 2500

local highest_volume_limit = XAudio.ChatterUnitSource.highest_volume_limit
local farthest_volume_dis = XAudio.ChatterUnitSource.farthest_volume_dis
local lowest_volume_dis = XAudio.ChatterUnitSource.lowest_volume_dis

function C:init(unit, ...)
	self.super.init(self, ...)
	self._unit = unit
end


local function _get_maxixmum_vector(pos1, pos2)	
	local x = (pos1.x + pos2.x) / 2
	x = (pos1.x + x) / 2
	local y = (pos1.y + pos2.y) / 2
	y = (pos1.y + y) / 2
	local z = (pos1.z + pos2.z) / 2
	z = (pos1.z + z) / 2
	return Vector3(x, y, z)
end



function C:update(...)
	self.super.update(self, ...)
	
	if self:is_closed() then 
		return 
	end

	local unit = self._unit
	if self._unit == XAudio.PLAYER then
		unit = XAudio._player_unit
	end
	
	local cam_position
	local viewport = managers.viewport:first_active_viewport()
	if viewport then
		local cam = viewport:camera()
		if cam then
			cam_position = cam:position()
		end
	end
	
	if not alive(unit) or not cam_position then
		self:close()
		return
	end

	local pos = unit:position()
	--[[
	if unit == XAudio._player_unit then
		pos = unit:position()
	else
		pos = _get_maxixmum_vector(cam_position, unit:position())			
	end]]
	
	
	self:set_position(pos)
	if unit ~= XAudio._player_unit and self._original_gain then
		local dis = mvector3.distance_sq(pos, cam_position)	
		if dis > farthest_volume_dis then
			dis = farthest_volume_dis
		elseif dis < lowest_volume_dis then
			dis = lowest_volume_dis
		end
		if cam_position then
			local new_volume = self._original_gain + (dis / 75000)
			if new_volume > highest_volume_limit then
				new_volume = highest_volume_limit
			elseif new_volume < 0 then
				new_volume = 0
			end
			self._gain = new_volume
		end
	end
	
	-- TODO velocity and direction
end


function C:set_volume(gain, set_original_gain)
	if gain > highest_volume_limit then
		error("Cannot set gain to more than 1")
	elseif gain < 0 then
		error("Cannot set gain to less than 0")
	end

	self._gain = gain
	
	if set_original_gain then
		self._original_gain = gain
	end
end