CellReviveInteraction = CellReviveInteraction or blt_class(CellBaseInteraction)

function CellReviveInteraction:interaction_start(interactor, revive_unit, t)
	local suffix = "a"
	local revive_char_dmg_ext = revive_unit:character_damage()
	if revive_char_dmg_ext.get_revives and revive_char_dmg_ext.get_revives_max then
		local max_revives, revives = revive_char_dmg_ext:get_revives_max(), revive_char_dmg_ext:get_revives()
		local downs_counter = max_revives - revives
		if downs_counter >= max_revives - 1 then
			suffix = "c"
		elseif downs_counter >= math.floor(max_revives / 2) then
			suffix = "b"
		end		
	end
	
	local revive_line = "s09"..suffix	
	local character = managers.criminals:character_name_by_unit(interactor)	
	if revive_line and revive_line ~= "s09c" then
		if character ~= "old_hoxton" then
			if managers.cell_drama:current_tension() >= DramaStateAssault.Combat_CallOut_Tension_Filter.Min then
				if math.random() < 0.35 then
					revive_line = "s08x_sin"
				end
			end		
		end
	end		
	
	if not self._revive_timer_cooldown_t or self._revive_timer_cooldown_t < t then
		self._revive_timer_cooldown_t = t + 2
		if managers.cell_options:has_toggled("project_cell_revive_talk_tog") then
			self:say_line(interactor, revive_line)
		end		
	end	
end