CellConvertHostageInteraction = CellConvertHostageInteraction or blt_class(CellBaseInteraction)

function CellConvertHostageInteraction:init()
	self._weight_handler = WeightHandler:new()
	self._weight_handler:add_value("f41_any", 3)
	self._weight_handler:add_value("f40_any", 2)
end

function CellConvertHostageInteraction:interaction_complete(interactor, object, t)	
	if managers.cell_options:has_toggled("project_cell_hostage_convert_tog") then
		self:say_line(interactor, self._weight_handler:get_best_value().value)
	end	
end


