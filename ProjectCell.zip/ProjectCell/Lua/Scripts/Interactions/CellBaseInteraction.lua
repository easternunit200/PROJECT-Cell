CellBaseInteraction = CellBaseInteraction or blt_class()

function CellBaseInteraction:say_line(interactor, line)
	interactor:sound():say(line,true,true)
end

function CellBaseInteraction:interaction_start(interactor, object, t)
end

function CellBaseInteraction:interaction_complete(interactor, object, t)
end

function CellBaseInteraction:interaction_interrupted(interactor, object, t)
end

