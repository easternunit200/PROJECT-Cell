CellIntimidateInteraction = CellIntimidateInteraction or blt_class(CellBaseInteraction)

function CellIntimidateInteraction:init()
	self._first_tied = false
end


function CellIntimidateInteraction:interaction_complete(interactor, object)
	local sound = self._first_tied and "f03b_any" or "g26"
	self._first_tied = true
	
	if managers.cell_options:has_toggled("project_cell_tie_civilian_tog") then
		self:say_line(interactor, sound)
	end		
end