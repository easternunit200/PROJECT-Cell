LocalCellUser = LocalCellUser or blt_class()
LocalCellUser.VALUE_ON = 1
LocalCellUser.VALUE_OFF = 0
LocalCellUser.SYNCABLE_TOGGLES = {
	"project_cell_react_downed_tog",
	"project_cell_theif_stealing_tog",
	"project_cell_tog_heat_speech",
}
LocalCellUser.SYNCABLE_SLIDER_VALUES = {
	"project_cell_assault_sli",
	"project_cell_anticipation_sli",
	"project_cell_post_assault_sli"
}

function LocalCellUser:debug_print(txt)
	CellGlobal:log("LocalCellUser " .. tostring(self:name()) .. " - " .. txt)
end

function LocalCellUser:init(peer)
	self._peer = peer
	self._name = self._peer:name()
	self._from_start = false
	self._incharge = false	
	self:_setup_net_action()
end

function LocalCellUser:_setup_net_action()
	self._net_action = CellNetValidationAction:new("Peer" .. tostring(self._peer:id()), callback(self,self,"sync_cell_values"))	
end

function LocalCellUser:destroy()
	self:debug_print("Cannot destroy local user since local user should be out of the game by now..")
end

function LocalCellUser:sync_cell_values(data, sender)
	self:debug_print("Syncing local cell user values??")
end


function LocalCellUser:has_toggled(value_name)
	return managers.cell_options:has_toggled(value_name)
end

function LocalCellUser:slider_value(value_name)
	return managers.cell_options:slider_value(value_name)
end

function LocalCellUser:get_cell_values_data()
	local data = {
		t = "",
		s = {}
	}	
	for i, value_name in pairs(LocalCellUser.SYNCABLE_TOGGLES) do
		data.t = data.t .. tostring(self:has_toggled(value_name) and LocalCellUser.VALUE_ON or LocalCellUser.VALUE_OFF)
	end	
	for i, slider_name in pairs(LocalCellUser.SYNCABLE_SLIDER_VALUES) do
		table.insert(data.s, self:slider_value(slider_name))
	end	
	return data
end

function LocalCellUser:send_cell_values_to_peers()
	managers.cell_user:net_action():send_to_peers(self:get_cell_values_data())
end

function LocalCellUser:send_cell_values_to_peer(peer_id)
	managers.cell_user:net_action():send_to_peer(peer_id, self:get_cell_values_data())
end

function LocalCellUser:start_from_beginning()
	self._from_start = true
end

function LocalCellUser:has_started_from_beginning()
	return self._from_start
end

function LocalCellUser:unit()
	return self._peer:unit()
end

function LocalCellUser:alive()
	return self._peer:unit() and alive(self._peer:unit())
end

function LocalCellUser:character_name()
	return managers.criminals:character_name_by_peer_id(self._peer:id())
end

function LocalCellUser:peer_id()
	return self._peer:id()
end

function LocalCellUser:peer()
	return self._peer
end

function LocalCellUser:name()
	return self._name
end

function LocalCellUser:is_local_user()
	return true
end