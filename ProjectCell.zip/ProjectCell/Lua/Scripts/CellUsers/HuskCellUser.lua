HuskCellUser = HuskCellUser or blt_class(LocalCellUser)


function HuskCellUser:debug_print(txt)
	CellGlobal:log("HuskCellUser " .. tostring(self:name()) .. " - " .. txt)
end

function HuskCellUser:destroy()
	self._net_action:unregister()
end

function HuskCellUser:init(peer)
	HuskCellUser.super.init(self, peer)
	self._synced_toggles = {}
	self._synced_slider_values = {}	
end

function HuskCellUser:send_cell_values_to_peers()
end

function HuskCellUser:send_cell_values_to_peer(peer_id)
end


function HuskCellUser:has_toggled(value_name)
	return self._synced_toggles[value_name]
end

function HuskCellUser:slider_value(slider_name)
	return self._synced_slider_values[slider_name] or 0
end

function HuskCellUser:sync_cell_values(data)	

	self._synced_toggles = {}
	self._synced_slider_values = {}	
	if data.t and type(data.t) == "string" then
		for i = 1, #data.t do
			local value_name = LocalCellUser.SYNCABLE_TOGGLES[i]
			if value_name then
				local value_code = tonumber(data.t:sub(i,i))
				if value_code == LocalCellUser.VALUE_ON then
					self._synced_toggles[value_name] = true
				elseif value_code == LocalCellUser.VALUE_OFF then
					self._synced_toggles[value_name] = false
				end			
			end
		end
	end	
	
	if data.s and type(data.s) == "table" then
		for index, slider_value in pairs(data.s) do
			local slider_name = LocalCellUser.SYNCABLE_SLIDER_VALUES[index]
			if slider_name then
				self._synced_slider_values[slider_name] = slider_value
			end
		end
	end	
	
	self:debug_print("Successfully received synced cell values!")	
end


function HuskCellUser:is_local_user()
	return false
end