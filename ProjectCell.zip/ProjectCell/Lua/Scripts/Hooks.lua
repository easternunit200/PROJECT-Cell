CellHooks = CellHooks or {}
CellHooks.QUEQED_NETWORK_DATA = {}
CellHooks.MENU_TYPES = {
	BUTTON = 0,
	TOGGLE = 1,
	DIVIDER = 2,
	SLIDER = 3
}

function CellHooks:get_value_disabled(block)
	if block.menu_type == CellHooks.MENU_TYPES.BUTTON then
		return false
	elseif block.menu_type == CellHooks.MENU_TYPES.TOGGLE then
		return false
	elseif block.menu_type == CellHooks.MENU_TYPES.DIVIDER then
		return 0			
	elseif block.menu_type == CellHooks.MENU_TYPES.SLIDER then
		return 0		
	end
	return false
end


--[[
Hooks:Add("MenuManagerOnOpenMenu", "MenuManagerOnOpenMenu_DEADLOCKE1", function( menu_manager, menu, position )
	if menu == "menu_main" then
		DeadLocke:Load()
		DeadLocke:display_new_user(false)
		SoundDevice:set_state("wave_flag", "assault")
		--SoundDevice:set_state("acoustic_flag", "acoustic_flat")
		if blt and not blt.xaudio then
			if not DeadLocke._data.has_viewed_no_superblt_message then
				DeadLocke._data.has_viewed_no_superblt_message = true
				local menu_options = {
					[1] = {
						text = managers.localization:text("can_ban_news_exit_btn"),
						is_cancel_button = true,
					}
				}
				QuickMenu:new(managers.localization:text("can_none_superblt_title"), managers.localization:text("can_none_superblt_desc"), menu_options, true)
				DeadLocke:Save()
			end
		end
	end
end)]]


Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_DeadLocke2", function( loc )
	CellHooks.Loc = loc;
end)


Hooks:Add("NetworkReceivedData", "NetworkReceivedData_DeadLocke", function(sender, network_id, data)
	if managers.cell_network then
		managers.cell_network:execute_network_callback(network_id, data, sender)
	end
end)


Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_DeadLocke3", function( menu_manager )


	
	MenuCallbackHandler.callback_display_changelog = function(self, item)
		Steam:overlay_activate("url", "https://modworkshop.net/mod/22085#changelog")
	end
	
	function MenuCallbackHandler:callback_GenerateHeaderFiles(item)
		managers.cell_data:generateHeaderFiles();			
	end		
		
	MenuCallbackHandler.callback_reset_options = function(self, item)
		--MenuHelper:ResetItemsToDefaultValue( item, _reset_values_to_default("on"), true )
		--MenuHelper:ResetItemsToDefaultValue( item, _reset_values_to_default("off"), false )
		--DeadLocke:ApplyMyStringIndexValues()
		--DeadLocke:Save()
		CellGlobal:log("Settings reset!")
	end
	
end )



Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_DEADLOCKE4", function( menu_manager, nodes )
	MenuHelper:NewMenu( "can_menu_id" )
	MenuHelper:NewMenu( "can_music_menu_id" )
	MenuHelper:NewMenu( "can_stealth_music_menu_id" )
	MenuHelper:NewMenu( "can_big_mouth_tank_menu_id" )
end)

Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_DEADLOCKE5", function(menu_manager, nodes)	
	local menu_data = {}
	menu_data.back_callback = "on_exit_stealth_tracks_menu"
	
	nodes.can_menu_id = MenuHelper:BuildMenu( "can_menu_id")	
	nodes.can_music_menu_id = MenuHelper:BuildMenu( "can_music_menu_id" )	
	nodes.can_stealth_music_menu_id = MenuHelper:BuildMenu( "can_stealth_music_menu_id", menu_data)

	
	nodes.can_big_mouth_tank_menu_id = MenuHelper:BuildMenu( "can_big_mouth_tank_menu_id" )		

	MenuHelper:AddMenuItem( nodes.blt_options, "can_menu_id", "can_menu", "can_menu_desc")			
end)

Hooks:Add("NetworkReceivedData", "NetworkReceivedData_DeadLocke", function(sender, network_id, data)
	if network_id == DeadLockeNetwork:get_current_version() then
		DeadLockeNetwork:get_function_from_json_data(data, sender) 
	end	
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_DEADLOCKE6", function( menu_manager, nodes )	
	local loc = managers.localization
	
	
	function MenuCallbackHandler:callback_ply_spot_dozer_tog_slider(item)
		DeadLocke._data.ply_spot_dozer_chance = item:value()		
		DeadLocke:Save()	
	end 
	
	function MenuCallbackHandler:callback_ply_called_response_delay(item)
		DeadLocke._data.ply_call_toggle_delay_timer = tonumber(item:value())
		log("[DeadLocke._data.ply_call_toggle_delay_timer] set to " .. tostring(item:value()))
		DeadLocke:Save()	
	end
	
	function MenuCallbackHandler:print_out_deadlocke_hash(item)
		DeadLocke:save_hash_file_text()
	end 
	
	function MenuCallbackHandler:encode_data_blocks(item)
		if block_manager then
			block_manager:encode_data_blocks()
		end
	end 
	
	function MenuCallbackHandler:open_stealth_music_menu(item)
		managers.menu:open_node("can_stealth_music_menu_id")		
	end 
	
	function MenuCallbackHandler:open_dynamic_music_menu(item)
		managers.menu:open_node("can_music_menu_id")		
	end 
	
	function MenuCallbackHandler:clbk_deadlocke_preview_stealth_track(item)
		local music_id = item:value()
		local level_id = item:name()
		DeadLocke:listen_to_track(music_id, level_id)	
	end
	
	

	for _, v in pairs(block_manager:wrapper("PlayerModOptionsDataBlock"):get_all_blocks()) do
		DeadLocke._data[v.ValueName] = v.default_value
	end
	
	DeadLocke:Load()
	
	for _, block in pairs(block_manager:wrapper("PlayerModOptionsDataBlock"):get_all_blocks()) do
		
		
		if block.menu_type == "toggle" then
			MenuCallbackHandler[block.callback] = function(self, item)
				local enabled = item:value() == "on" and true or false
				DeadLocke:set_value(block.ValueName, enabled)			
				DeadLocke:Save()
				log("Value name "..tostring(block.ValueName).." is "..(enabled and "enabled" or "disabled"))
			end
		end
		
		local menu_data = {
			id = "can_menu_persistentID_"..tostring(block.persistentID),
			title = block.Title,
			desc = block.Desc,
			callback = DeadLocke:isNotNilorEmpty(block.callback) and block.callback or nil,
			priority = block.priority,
			disabled_color = Color(block.DisabledColorHash),
			menu_id = block.menu_id,
			value = DeadLocke:isNotNilorEmpty(block.ValueName) and DeadLocke._data[block.ValueName] or false,
			show_value = block.show_value,
			step = block.step,
			size = block.size,
			max = block.max,
			min = block.min,
			localized = block.localized,
			disabled = false
		}
		if block.disabled then
			menu_data.disabled = true
			menu_data.value = CellHooks:get_value_disabled(block)
			if DeadLocke:isNotNilorEmpty(block.disabled_desc) then
				menu_data.desc = block.disabled_desc
			end
		end
		
		if block.menu_type == MENU_TYPES.BUTTON then
			log("MenuHelper added a button "..tostring(block.name).. " with persistentID "..tostring(block.persistentID))
			MenuHelper:AddButton(menu_data)
		elseif block.menu_type == MENU_TYPES.TOGGLE then
			log("MenuHelper added a toggle "..tostring(block.name).. " with persistentID "..tostring(block.persistentID))
			MenuHelper:AddToggle(menu_data)
		elseif block.menu_type == MENU_TYPES.DIVIDER then
			log("MenuHelper added a divider "..tostring(block.name).. " with persistentID "..tostring(block.persistentID))
			MenuHelper:AddDivider(menu_data)				
		elseif block.menu_type == MENU_TYPES.SLIDER then
			log("MenuHelper added a slider "..tostring(block.name).. " with persistentID "..tostring(block.persistentID))
			MenuHelper:AddSlider(menu_data)	
		else
			log("MenuHelper added an unknown menu type of " ..tostring(block.menu_type) .. " for name " ..tostring(block.name) .. " with persistentID "..tostring(block.persistentID))
		end
	end		

end)