PlayerDialogNodeBase = PlayerDialogNodeBase or blt_class(MachineState)
