CellElementSuspenser = CellElementSuspenser or blt_class(CellElementNonSync)

function CellElementSuspenser:on_executed(instigator, ...)
	if not self._values.enabled then
		return
	end

	managers.cell_music:set_minimum_suspense_index(self._values.suspense_index)
	
	CellElementSuspenser.super.on_executed(self, instigator)
end
