CellElementNonSync = CellElementNonSync or blt_class(MissionScriptElement)


function CellElementNonSync:on_executed(instigator, alternative, skip_execute_on_executed, ...)
	if not self._values.enabled then
		return
	end

	instigator = self:_check_instigator(instigator)

	self:_reduce_trigger_times()

	if not skip_execute_on_executed or CoreClass.type_name(skip_execute_on_executed) ~= "boolean" then
		self:_trigger_execute_on_executed(instigator, alternative)
	end
end

function CellElementSuspenser:client_on_executed(instigator, ...)
	--self:on_executed(instigator, ...)
end