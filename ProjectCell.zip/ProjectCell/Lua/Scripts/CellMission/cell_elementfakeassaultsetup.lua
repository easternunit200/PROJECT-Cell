CellElementFakeAssaultSetup = CellElementFakeAssaultSetup or class(CoreMissionScriptElement.MissionScriptElement)

function CellElementFakeAssaultSetup:client_on_executed(...)
	self:on_executed(...)
end



function CellElementFakeAssaultSetup:on_script_activated()
	CellElementFakeAssaultSetup.super.on_script_activated(self)

	if self:value("execute_on_startup") then
		self:on_executed()
	end
end


function CellElementFakeAssaultSetup:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	if self._values.loud_tracks and next(self._values.loud_tracks) then
		managers.cell_music:add_custom_loud_tracks(self._values.loud_tracks)	
	end
	
	CellElementFakeAssaultSetup.super.on_executed(self, instigator)
end
