MUS_SneakingSuspenseMedium = MUS_SneakingSuspenseMedium or blt_class(MUS_SneakingSuspenseBase)

function MUS_SneakingSuspenseMedium:setup()
	MUS_SneakingSuspenseMedium.super.setup(self)
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.SneakingSuspenseMedium)	
	self:add_suspenser_max({
		state_to_switch = MusicMachine.MUS_States.SneakingSuspenseHigh,
		goal_tension = 15,
		goal_timer = 25
	})
end

function MUS_SneakingSuspenseMedium:debug_prefix()
	return "MUS_SneakingSuspenseMedium"
end
