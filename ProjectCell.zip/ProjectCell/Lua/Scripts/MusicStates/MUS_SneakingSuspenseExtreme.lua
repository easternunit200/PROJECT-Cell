MUS_SneakingSuspenseExtreme = MUS_SneakingSuspenseExtreme or blt_class(MUS_SneakingSuspenseBase)

function MUS_SneakingSuspenseExtreme:setup()
	MUS_SneakingSuspenseExtreme.super.setup(self)
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.SneakingSuspenseExtreme)	
	self:add_suspenser_min({
		state_to_switch = MusicMachine.MUS_States.SneakingSuspenseHigh,
		goal_tension = 8,
		goal_timer = 35
	})
end

function MUS_SneakingSuspenseExtreme:debug_prefix()
	return "MUS_SneakingSuspenseExtreme"
end
