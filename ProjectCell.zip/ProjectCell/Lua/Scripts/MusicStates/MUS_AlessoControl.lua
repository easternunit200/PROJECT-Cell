MUS_AlessoControl = MUS_AlessoControl or blt_class(MUS_AlessoBase)

function MUS_AlessoControl:enter(exit_data)
	if self._machine:last_state_name() == MusicMachine.MUS_States.AlessoSneaking  then
		managers.music:post_event("crowd_medium")
	end
	
	MUS_AlessoControl.super.enter(self, exit_data)
end

function MUS_AlessoControl:debug_prefix()
	return "MUS_AlessoControl"
end
