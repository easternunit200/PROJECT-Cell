MUS_AlessoFakeAssault = MUS_AlessoFakeAssault or blt_class(MUS_AlessoBase)
function MUS_AlessoFakeAssault:setup()
	MUS_AlessoFakeAssault.super.setup(self)
end

function MUS_AlessoFakeAssault:debug_prefix()
	return "MUS_AlessoFakeAssault"
end
