MUS_AlessoAssault = MUS_AlessoAssault or blt_class(MUS_AlessoBase)

function MUS_AlessoAssault:update_crowd(t, dt)
	if managers.cell_drama:current_tension() > 70 then
		self._tension_power = self._tension_power + dt
	else
		self._tension_power = 0
		self._heavy_crowd = false
	end
	
	if self._tension_power > 10 and not self._heavy_crowd then
		self._heavy_crowd = true
		self:debug_print("Get the crowd crazy!!")
		managers.music:post_event("crowd_heavy")		
	end	
end

function MUS_AlessoAssault:update(t,dt)	
	self:update_crowd(t,dt)
	MUS_AlessoAssault.super.update(self,t,dt)	
end

function MUS_AlessoAssault:debug_prefix()
	return "MUS_AlessoAssault"
end
