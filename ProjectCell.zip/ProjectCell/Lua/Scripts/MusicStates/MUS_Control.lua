MUS_Control = MUS_Control or blt_class(MUS_Base)

function MUS_Control:setup()
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.Control)
end

function MUS_Control:debug_prefix()
	return "MUS_Control"
end