MUS_Anticipation = MUS_Anticipation or blt_class(MUS_Base)

function MUS_Anticipation:setup()
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.Anticipation)
end

function MUS_Anticipation:debug_prefix()
	return "MUS_Anticipation"
end