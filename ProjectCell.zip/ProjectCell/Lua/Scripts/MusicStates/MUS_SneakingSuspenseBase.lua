MUS_SneakingSuspenseBase = MUS_SneakingSuspenseBase or blt_class(MUS_Base)

function MUS_SneakingSuspenseBase:setup()
	self._suspensers = {}
end

function MUS_SneakingSuspenseBase:enter(exit_data)
	if not self:is_block_valid() then
		return
	end
	
	self:reset_suspensers()
	
	if self._machine:had_last_state() and not self._machine:last_state():is_suspense_state() then
		self:post_stealth_track_event()
	end	
	
	self._machine:set_last_suspense_state(self)	
	MUS_SneakingSuspenseBase.super.enter(self, exit_data)	
end

function MUS_SneakingSuspenseBase:debug_prefix()
	return "MUS_SneakingSuspenseBase"
end

function MUS_SneakingSuspenseBase:add_suspenser_max(data)	
	table.insert(self._suspensers, SuspenserMax:new(data))
end

function MUS_SneakingSuspenseBase:add_suspenser_min(data)	
	table.insert(self._suspensers, SuspenserMin:new(data))
end


function MUS_SneakingSuspenseBase:reset_suspensers()
	if not next(self._suspensers) then
		return
	end
	
	for i, suspenser in pairs(self._suspensers) do
		if suspenser then
			suspenser:reset()
		end
	end
end

function MUS_SneakingSuspenseBase:update(t,dt)	
	if next(self._suspensers) then
		for i, suspenser in pairs(self._suspensers) do
			suspenser:update(t, dt)
			if not managers.cell_music:music_state_changes_locked() then
				if suspenser:check_music_switch() then
					self._machine:change_state(suspenser:state_to_switch())
					return
				end
			end			
		end	
	end
	
	
	MUS_SneakingSuspenseBase.super.update(self,t,dt)
end


function MUS_SneakingSuspenseBase:is_sneaking()
	return true
end

function MUS_SneakingSuspenseBase:is_suspense_state()
	return true
end

function MUS_SneakingSuspenseBase:is_current_state()
	return self._machine:current_state() == self
end

function MUS_SneakingSuspenseBase:post_stealth_track_event()
	managers.music:post_event(managers.cell_music:current_stealth_track())
end

function MUS_SneakingSuspenseBase:on_stealth_track_changed()
	if not managers.cell_music:is_stealth_track() then
		self._machine:change_state(MusicMachine.MUS_States.Sneaking)
		return
	end
		
	self:post_stealth_track_event()
	self:trigger_on_enter_cues()
end
