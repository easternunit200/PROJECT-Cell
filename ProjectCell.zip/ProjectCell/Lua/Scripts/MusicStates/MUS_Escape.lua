MUS_Escape = MUS_Escape or blt_class(MUS_Base)
function MUS_Escape:setup()
	MUS_Escape.super.setup(self)
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.Escape)		
	self:setup_escape()
end

function MUS_Escape:enter(exit_data)
	managers.cell_music:set_lock_on_music_state_changes(true)
	MUS_Escape.super.enter(self, exit_data)	
end

function MUS_Escape:exit()
	managers.cell_music:set_lock_on_music_state_changes(false)
	MUS_Escape.super.exit(self)	
end

function MUS_Escape:setup_escape()	
	self._escape_block = self._wrapper:get_block_by_id(CD.MusicState.AndNowWeEscape)	
	self._1min_mark = false
end

function MUS_Escape:escape_timer_left()
	return managers.groupai:state()._point_of_no_return_timer
end

function MUS_Escape:update(t,dt)
	if self._escape_block == nil then
		return
	end
	
	local timer_left = self:escape_timer_left()
	
	if not self._1min_mark and timer_left ~= nil and timer_left < 60 then
		self._1min_mark = true
		if Global.music_manager.current_track == "track_15" then
			self:post_events(self._escape_block.m_EventsOn1MinEscape)
		end		
	end
end

function MUS_Escape:debug_prefix()
	return "MUS_Escape"
end
