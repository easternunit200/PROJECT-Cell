MUS_FakeAssault = MUS_FakeAssault or blt_class(MUS_Base)

function MUS_FakeAssault:setup()
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.FakeAssault)
end


function MUS_FakeAssault:debug_prefix()
	return "MUS_FakeAssault"
end