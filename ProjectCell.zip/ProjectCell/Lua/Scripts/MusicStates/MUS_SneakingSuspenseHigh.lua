MUS_SneakingSuspenseHigh = MUS_SneakingSuspenseHigh or blt_class(MUS_SneakingSuspenseBase)

function MUS_SneakingSuspenseHigh:setup()
	MUS_SneakingSuspenseHigh.super.setup(self)
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.SneakingSuspenseHigh)
	
	self:add_suspenser_max({
		state_to_switch = MusicMachine.MUS_States.SneakingSuspenseExtreme,
		goal_tension = 20,
		goal_timer = 15
	})
	
	self:add_suspenser_min({
		state_to_switch = MusicMachine.MUS_States.SneakingSuspenseMedium,
		goal_tension = 8,
		goal_timer = 35
	})
end

function MUS_SneakingSuspenseHigh:debug_prefix()
	return "MUS_SneakingSuspenseHigh"
end