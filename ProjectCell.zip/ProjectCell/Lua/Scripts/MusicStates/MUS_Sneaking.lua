MUS_Sneaking = MUS_Sneaking or blt_class(MUS_Base)

function MUS_Sneaking:setup()
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.SneakingRegular)
end

function MUS_Sneaking:debug_prefix()
	return "MUS_Sneaking"
end

function MUS_Sneaking:update()
	MUS_Sneaking.super.update(self)
end

function MUS_Sneaking:on_stealth_track_changed()
	if managers.cell_music:is_stealth_track() then
		self._machine:change_to_minimum_suspense_state()
	end
end

function MUS_Sneaking:is_sneaking()
	return true
end
