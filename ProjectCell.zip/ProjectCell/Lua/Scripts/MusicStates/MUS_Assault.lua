MUS_Assault = MUS_Assault or blt_class(MUS_Base)

function MUS_Assault:setup()
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.Assault)
end

function MUS_Assault:debug_prefix()
	return "MUS_Assault"
end