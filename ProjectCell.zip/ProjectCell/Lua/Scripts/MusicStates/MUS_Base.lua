MUS_Base = MUS_Base or blt_class(MachineState)

function MUS_Base:init()
	self._wrapper = managers.cell_data:wrapper("MusicStateDataBlock")
end

function MUS_Base:is_block_valid()
	return self._datablock ~= nil and self._datablock.internalEnabled
end

function MUS_Base:post_events(events)
	if events == nil then
		return
	end
	
	for i, eventData in pairs(events) do
		managers.music:post_event(eventData.eventName)
	end
end

function MUS_Base:set_switches(switches)
	if switches == nil then
		return
	end
	
	for i, switchData in pairs(switches) do
		managers.music:set_switch(switchData.switchGroup, switchData.switchName)
	end
end

function MUS_Base:trigger_on_enter_cues()
	if not self:is_block_valid() then
		return
	end	
	
	self:set_switches(self._datablock.m_SwitchesOnEnter)
	self:post_events(self._datablock.m_EventsOnEnter)
end

function MUS_Base:enter(exit_data)
	self:trigger_on_enter_cues()
end

function MUS_Base:exit()
	if not self:is_block_valid()then
		return
	end
	
	local current_state_id = self._machine:current_state_id()
	if self._machine:get_state_id_by_name(MusicMachine.MUS_States.None) == current_state_id then
		return
	end
	
	
	self:post_conditional_exit_events(self._datablock.m_EventsOnExit, current_state_id)
	
end


function MUS_Base:state_is_locked()
	if not self:is_block_valid() then
		return false
	end
	
	if self._datablock.m_timing == nil then
		return false
	end
	
	if self._datablock.m_timing.minTimeInState == nil then
		return false
	end
	
	return self._t - self._state_change_t < self._datablock.m_timing.minTimeInState
end

function MUS_Base:post_conditional_exit_events(events, exitingTo)
	if events == nil then
		return 
	end
	
	if exitingTo == nil then
		return 
	end
	
	
	for i,eventData in pairs(events) do			
		if exitingTo == eventData.onlyWhenExitingTo then
			managers.music:post_event(eventData.eventName);
		end
	end
end

function MUS_Base:update(t,dt)
	if not self:is_block_valid() then
		return false
	end
	

	if self._datablock.m_timing == nil or self._datablock.m_timing.stateAfterMaxTime == nil then
		return
	end
	
	if self:max_time_reached() and self._datablock.m_timing.stateAfterMaxTime ~= self._machine:get_state_id_by_name(MusicMachine.MUS_States.None) then
		self._machine:change_state(self._datablock.m_timing.stateAfterMaxTime)
	end

	
end

function MUS_Base:max_time_reached()
	if not self:is_block_valid() then
		return false
	end
	
	if self._datablock.m_timing == nil then
		return false
	end
	
	
	
	if self._datablock.m_timing.maxTimeInState == nil or self._datablock.m_timing.maxTimeInState <= 0 then
		return false
	end
	
	return self._t - self._state_change_t > self._datablock.m_timing.maxTimeInState
end

function MUS_Base:is_sneaking()
	return false
end

function MUS_Base:is_suspense_state()
	return false
end

function MUS_Base:on_stealth_track_changed()
end


function MUS_Base:debug_prefix()
	return "MUS_Base"
end

