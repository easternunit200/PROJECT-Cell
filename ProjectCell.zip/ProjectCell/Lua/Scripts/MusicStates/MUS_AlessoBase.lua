MUS_AlessoBase = MUS_AlessoBase or blt_class(MUS_Base)

function MUS_AlessoBase:setup()
	self:setup_alesso()	
end

function MUS_AlessoBase:setup_alesso()
	self._heavy_crowd = false
	self._tension_power = 0
	self._current_muffle_level = self._current_muffle_level or ""
	self._play_event_keyword = "alesso_muffle_"
	self._muffles_ids = {}
	self._muffles_ids.alesso_muffle_3_001 = 101275	
	self._muffles_ids.alesso_muffle_3_002 = 101274
	self._muffles_ids.alesso_muffle_3_003 = 101267
	self._muffles_ids.alesso_muffle_3_004 = 101270
	self._muffles_ids.alesso_muffle_3_005 = 101269
	self._muffles_ids.alesso_muffle_3_006 = 101276
	self._muffles_ids.alesso_muffle_3_007 = 101326
	
	self._muffles_ids.alesso_muffle_4_001 = 101055	
	self._muffles_ids.alesso_muffle_4_002 = 101265	
	self._muffles_ids.alesso_muffle_4_003 = 101271	
	self._muffles_ids.alesso_muffle_4_004 = 101268	
	self._muffles_ids.alesso_muffle_4_005 = 101272	
	self._muffles_ids.alesso_muffle_4_006 = 101277
	
	self._muffles_ids.alesso_muffle_5_001 = 101266	
	self._muffles_ids.alesso_muffle_5_002 = 101264	
	self._muffles_ids.alesso_muffle_5_003 = 101278
	
	self._muffles_ids.alesso_muffle_6_001 = 101263	
	
	self._muffles_ids.alesso_muffle_7 = 101262
	
	self._muffles_ids.alesso_muffle_8 = 101261
	
	local length = string.len(self._play_event_keyword)
	self._alesso_muffle_trigger_ids = {}
	for name, id in pairs(self._muffles_ids) do
		
		self._alesso_muffle_trigger_ids[id] = string.sub(name, 1, length + 1)
	end
	
end


function MUS_AlessoBase:get_alesso_muffle_by_element_id(id)
	return  self._alesso_muffle_trigger_ids[id]
end

function MUS_AlessoBase:debug_prefix()
	return "MUS_AlessoBase"
end

function MUS_AlessoBase:is_waiting_to_respawn()
	return game_state_machine:current_state_name() == "ingame_waiting_for_respawn"
end

function MUS_AlessoBase:post_muffle_level_by_element_id(id)	
	if not self._current_element_muffle_id or self._current_element_muffle_id ~= id then
		self:debug_print("now in element shape " .. tostring(id))
		self._current_element_muffle_id = id
		local event = self:get_alesso_muffle_by_element_id(id)
		if event then
			managers.music:post_event(event)		
			self:debug_print("now playing " .. event)
		end		
	end
end

function MUS_AlessoBase:update_custody()
	if not self:is_waiting_to_respawn() then
		self._current_element_muffle_id = nil
		return
	end
	
	
	local cam_position
	local viewport = game_state_machine and game_state_machine:current_state() and game_state_machine:current_state()._viewport
	if viewport then
		local cam = viewport:camera()
		if cam then
			cam_position = cam:position()
		end
	end
	
	
	if cam_position then
		for _, data in pairs(managers.mission:scripts()) do
			for id, element in pairs(data:elements()) do
				if self._alesso_muffle_trigger_ids[id] then
					if element:value("enabled") and element:_is_inside(cam_position) then
						self:post_muffle_level_by_element_id(id)
					end	
				end						
			end
		end
	end	
end




function MUS_AlessoBase:update(t,dt)
	MUS_AlessoBase.super.update(self, t, dt)
	self:update_custody()
end