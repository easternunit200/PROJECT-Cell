MUS_AlessoAnticipation = MUS_AlessoAnticipation or blt_class(MUS_AlessoBase)

function MUS_AlessoAnticipation:enter(exit_data)	
	if self._machine:last_state_name() == MusicMachine.MUS_States.Sneaking  then
		managers.music:post_event("crowd_medium")
	end
	
	MUS_AlessoAnticipation.super.enter(self, exit_data)
end

function MUS_AlessoAnticipation:debug_prefix()
	return "MUS_AlessoAnticipation"
end
