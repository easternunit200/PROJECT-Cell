MUS_SneakingSuspenseLow = MUS_SneakingSuspenseLow or blt_class(MUS_SneakingSuspenseBase)

function MUS_SneakingSuspenseLow:setup()
	MUS_SneakingSuspenseLow.super.setup(self)
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.SneakingSuspenseLow)	
	self:add_suspenser_max({
		state_to_switch = MusicMachine.MUS_States.SneakingSuspenseMedium,
		goal_tension = 10,
		goal_timer = 25
	})
end

function MUS_SneakingSuspenseLow:debug_prefix()
	return "MUS_SneakingSuspenseLow"
end