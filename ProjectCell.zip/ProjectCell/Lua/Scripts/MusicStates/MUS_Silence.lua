MUS_Silence = MUS_Silence or blt_class(MUS_Base)

function MUS_Silence:setup()
	self._datablock = self._wrapper:get_block_by_id(CD.MusicState.Silence)
end

function MUS_Silence:debug_prefix()
	return "MUS_Silence"
end