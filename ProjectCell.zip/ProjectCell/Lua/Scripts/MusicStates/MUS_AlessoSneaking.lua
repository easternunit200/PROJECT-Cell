MUS_AlessoSneaking = MUS_AlessoSneaking or blt_class(MUS_AlessoBase)

function MUS_AlessoSneaking:debug_prefix()
	return "MUS_AlessoSneaking"
end
