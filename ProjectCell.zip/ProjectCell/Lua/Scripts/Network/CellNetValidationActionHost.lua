CellNetValidationActionHost = CellNetValidationActionHost or blt_class(CellNetValidationAction)

function CellNetValidationActionHost:request_execute_to_peers(data)
	if not self._active then
		return
	end
	
	
	if not managers.cell_user:has_local_peer() then
		self:debug_print("ERROR: Failed to ask permission when local cell peer is returning null!")
		return
	end
	
	if not managers.cell_user:has_cell_host() then
		self:debug_print("ERROR: Failed to ask permission when no Cell Host available! This should not happen! ")
		return
	end
	
	if managers.cell_user:is_cell_host() then
		self._action_callback(data, managers.cell_user:local_peer_id())
		self:send_to_peers(data)
		return
	end
	
	
	self:send_to_cell_host(data)
end



function CellNetValidationActionHost:sync_execute(data, sender)
	if not managers.cell_user:has_cell_host() then
		self:debug_print("ERROR: Cannot execute this cell validation when no cell host is available!")
		return
	end	
	
	
	if sender ~= managers.cell_user:cell_host_peer_id() then		
		self:debug_print("ERROR: CellNetValidationActionHost packet received from a non host cell user. This type of packet is only accepted from Cell Host!")
		return
	end	
	
	
	self._action_callback(data, sender)
end



function CellNetValidationActionHost:execute_to_peers(data)
	if not managers.cell_user:has_local_peer() then
		self:debug_print("ERROR: Failed to ask permission when local cell peer is returning null!")
		return
	end
	
	if not managers.cell_user:is_cell_host() then
		self:debug_print("ERROR: Cannot execute to peers as a non cell host!")
		return
	end
	

	self._action_callback(data, managers.cell_user:local_peer_id())
	self:send_to_peers(data)
end

function CellNetValidationActionHost:execute_to_peer(peer_id, data)
	if not managers.cell_user:has_local_peer() then
		self:debug_print("ERROR: Failed to ask permission when local cell peer is returning null!")
		return
	end
	
	if not managers.cell_user:is_cell_host() then
		self:debug_print("ERROR: Cannot execute to peer as a non cell host!")
		return
	end

	self._action_callback(data, managers.cell_user:local_peer_id())
	self:send_to_peer(peer_id, data)
end