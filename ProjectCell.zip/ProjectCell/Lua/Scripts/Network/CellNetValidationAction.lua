CellNetValidationAction = CellNetValidationAction or blt_class()
CellNetValidationAction.DEBUG_ENABLED = false

function CellNetValidationAction:init(packet_id, action_clbk)
	self._active = false
	self._action_callback = action_clbk
	self._packet_id = packet_id
	self:register()
end

function CellNetValidationAction:debug_print(txt)
	CellGlobal:log("CellNetValidationAction - " .. txt)
end

function CellNetValidationAction:network_id()
	return managers.cell_network:network_id()
end

function CellNetValidationAction:set_active(enabled)
	self._active = enabled
end

function CellNetValidationAction:register()
	managers.cell_network:register_action_validation(self)	
end

function CellNetValidationAction:unregister()
	managers.cell_network:unregister_action_validation(self)	
end

function CellNetValidationAction:packet_id()
	return self._packet_id
end

function CellNetValidationAction:sync_execute(data, sender)
	self._action_callback(data, sender)
end

function CellNetValidationAction:execute_to_peers(data)
	if not managers.cell_user:has_local_peer() then
		self:debug_print("ERROR: Failed to ask permission when local cell peer is returning null!")
		return
	end

	self._action_callback(data, managers.cell_user:local_peer_id())
	self:send_to_peers(data)
end

function CellNetValidationAction:execute_to_peer(peer_id, data)
	if not managers.cell_user:has_local_peer() then
		self:debug_print("ERROR: Failed to ask permission when local cell peer is returning null!")
		return
	end

	self:send_to_peer(peer_id, data)
end

function CellNetValidationAction:request_execute(data)
	self:debug_print("ERROR: This is only fit for Host specific..")
end

function CellNetValidationAction:create_a_packet(data)
	return JsonUtils:safe_encode({
		self._packet_id,
		data
	})
end


function CellNetValidationAction:send_to_peers(data)	
	if not self._active then
		return
	end
	
	LuaNetworking:SendToPeers(self:network_id(), self:create_a_packet(data))
end

function CellNetValidationAction:send_to_peers_except(peer_id, data)
	if not self._active then
		return
	end
	
	LuaNetworking:SendToPeersExcept(peer_id, self:network_id(), self:create_a_packet(data))
end

function CellNetValidationAction:send_to_peer(peer_id, data)
	if not self._active then
		return
	end
	
	LuaNetworking:SendToPeer(peer_id, self:network_id(), self:create_a_packet(data))
end

function CellNetValidationAction:send_to_cell_host(data)
	if not self._active then
		return
	end
	
	if not managers.cell_user:has_cell_host() then
		self:debug_print("ERROR: No Cell Host available! This should not happen!")
		return
	end

	
	LuaNetworking:SendToPeer(managers.cell_user:cell_host_peer_id(), self:network_id(), self:create_a_packet(data))
end