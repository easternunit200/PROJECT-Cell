CellGlobal = CellGlobal or blt_class()
CellGlobal.DEBUG_ENABLED = true
CellGlobal.Time = 0
CellGlobal.DeltaTime = 0
CellGlobal.LogPreffix = "PROJECT : Cell";


CellGlobal.InGameManagers = {	
	{
		"cell_global",
		"CellGlobalManager"
	},
	{
		"cell_data",
		"CellDataBlockManager"
	},
	{
		"cell_network",
		"CellNetworkManager"
	},
	{
		"cell_input",
		"InputManager"
	},
	{
		"cell_voice",
		"PlayerVoiceManager"
	},
	{
		"cell_user",
		"CellUserManager"
	},
	{
		"cell_options",
		"CellOptionsManager"
	},
	{
		"cell_drama",
		"DramaManager"
	},
	{
		"cell_world",
		"ChatterWorldManager"
	},
	{
		"cell_music",
		"CellMusicManager"
	},
	{
		"cell_condition",
		"PlayerConditionManager"
	},
	{
		"cell_callback",
		"CallBackManager"
	},
	{
		"cell_cooldown",
		"CoolDownManager"
	},
	{
		"cell_pager",
		"CellPagerManager"
	},
	{
		"cell_drill",
		"CellDrillManager"
	},
	{
		"cell_interaction",
		"CellInteractionManager"
	},
	{
		"cell_narrator",
		"CellNarratorManager"
	},
	{
		"cell_peer_exclusion",
		"CellPeerExclusionManager"
	},
	{
		"cell_mod",
		"CellModManager"
	},
	{
		"cell_job",
		"CellJobManager"
	},
	{
		"cell_stealth",
		"CellStealthManager"
	}
}

CellGlobal.MenuManagers = {	
	{
		"cell_global",
		"CellGlobalManager"
	},
	{
		"cell_data",
		"CellDataBlockManager"
	},
	{
		"cell_options",
		"CellOptionsManager"
	},
	{
		"cell_music",
		"CellMenuMusicManager"
	},
	{
		"cell_mod",
		"CellModManager"
	},
	{
		"cell_matchmake_handler",
		"CellMatchMakeHandlerManager"
	}
}

function CellGlobal:init(is_menu)
	self._is_menu = is_menu and true or false	
	self:_load_dev_components_pre_setup()
	
	self._mod = BLT.Mods:GetModByName("PROJECT: Cell")
	
	CellGlobal.LogPreffix = CellGlobal.LogPreffix .. " [" ..tostring(self._mod:GetVersion()).."]"
	
	self:_init_managers()
	self:_setup_managers()
	self:_post_setup_managers()
	
	self:_load_dev_components_post_setup()
	
end

function CellGlobal:mod()
	return self._mod;
end

function CellGlobal:_load_dev_components_pre_setup()		
end

function CellGlobal:_load_dev_components_post_setup()		
end


function CellGlobal:ingame()
	return not self._is_menu
end


function CellGlobal:_init_managers()
	CellGlobal:log("Initializing CellManagers!")
	
	
	self._managers = {}
	
	
	self._managers_to_setup = self._is_menu and CellGlobal.MenuManagers or CellGlobal.InGameManagers
	
	for index, manager_data in pairs(self._managers_to_setup) do
		local manager_name = manager_data[1]	
		local class_name = manager_data[2]
		
		if class_name == nil then
			error("ERROR : class name is nil! for manager name -> " .. tostring(manager_name))
			return
		end
		
		CellGlobal:log("Now registering a CellManager : " .. tostring(manager_name))
		
		local manager_class = rawget(_G, class_name)
		
		if manager_class == nil then
			error("ERROR: Manager Class " .. tostring(manager_class) " does not exist!")
			return
		end
		
		managers[manager_name] = manager_class:new()
		
		managers[manager_name]._class_name = class_name
		managers[manager_name]._manager_name = manager_name
		
		table.insert(self._managers, managers[manager_name])
		
		
	end
	
end


function CellGlobal:update_global_clock(t,dt)
	CellGlobal.Time = t
	CellGlobal.DeltaTime = dt
end

function CellGlobal:update(t,dt)
	self:update_global_clock(t,dt)
	for name, man in pairs(self._managers) do
		 man:update_clock(t,dt) 
		 man:update(t,dt) 
	end
end


function CellGlobal:log(...)
	if CellGlobal.DEBUG_ENABLED then	
		--log("Project Cell v" .. tostring(managers.cell_mod:mod_version()) .. " -", ...)
		log(CellGlobal.LogPreffix, ...)
	end
end

function CellGlobal:_setup_managers()
	for _, man in pairs(self._managers) do
		local name = man:class_name()
		local manager_name = man:manager_name()
		if man.setup then
			CellGlobal:log("Setting up manager : " .. name)
			man:set_in_menu(self._is_menu)		
			man:setup()			
		else
			CellGlobal:log("ERROR : " .. tostring(name) .. " does not have a setup function! Does the manager inherit from CellManagerBase?")
		end
	end
end


function CellGlobal:_post_setup_managers()
	for _, man in pairs(self._managers) do
		local name = man:class_name()
		local manager_name = man:manager_name()
		if man.post_setup then
			CellGlobal:log("Post Setting up manager : " .. name)
			man:post_setup()
		else
			CellGlobal:log("ERROR : " .. tostring(name) .. " does not have a post_setup function! Does the manager inherit from CellManagerBase?")
		end
	end
end


function CellGlobal:destroy()
	for _, man in pairs(self._managers) do
		if man.on_session_destroyed then
			man:debug_print("On Session Destroyed")
			man:on_session_destroyed()
		end
	end
end
