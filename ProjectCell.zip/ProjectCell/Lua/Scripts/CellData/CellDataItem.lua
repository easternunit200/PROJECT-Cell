CellDataItem = CellDataItem or blt_class()
function CellDataItem:init(data)
	self._id = data.id
	self._name = data.name
end

function CellDataItem:id()
	return self._id
end

function CellDataItem:name()
	return self._name
end

function CellDataItem:item_name()
	return  tostring(self:id()) .. " : " .. tostring(self:name())
end

function CellDataItem:index()
	return self._index
end
function CellDataItem:set_index(index)
	self._index = index
end