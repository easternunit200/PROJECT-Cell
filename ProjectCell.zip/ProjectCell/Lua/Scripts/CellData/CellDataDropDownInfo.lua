CellDataDropDownInfo = CellDataDropDownInfo or blt_class()

function CellDataDropDownInfo:init()
	self._items = {}
end

function CellDataDropDownInfo:add_item(data)		
	local item = CellDataItem:new(data)
	table.insert(self._items, item)
	item:set_index(#self._items)
end

function CellDataDropDownInfo:get_all_items()
	local items = {}
	
	for index, item in pairs(self._items) do
		items[index] = item:item_name()
	end
	
	return items
end

function CellDataDropDownInfo:get_id_from_index(index)
	return self._items[index] and self._items[index]:id() or 0
end

function CellDataDropDownInfo:get_index_from_id(id)
	for index, item in pairs(self._items) do
		if item:id() == id then
			return item:index()
		end
	end
	return 1
end