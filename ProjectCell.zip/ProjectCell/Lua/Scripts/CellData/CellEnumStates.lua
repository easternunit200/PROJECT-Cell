CellEnumStates = CellEnumStates or blt_class()

function CellEnumStates:init()
	
end


function CellEnumStates:_init_mus_states()
	self.MUS_State.None = "none"
	self.MUS_State.Silence = "silence"
	self.MUS_State.Sneaking = "sneaking"
	self.MUS_State.SneakingSuspenseLow = "sneaking_suspense_low"
	self.MUS_State.SneakingSuspenseMedium = "sneaking_suspense_medium"
	self.MUS_State.SneakingSuspenseHigh = "sneaking_suspense_high"
	self.MUS_State.SneakingSuspenseExtreme = "sneaking_suspense_extreme"
	self.MUS_State.Control = "control"
	self.MUS_State.Anticipation = "anticipation"
	self.MUS_State.Assault = "assault"
	self.MUS_State.FakeAssault = "fake_assault"
	self.MUS_State.Escape = "escape"
end