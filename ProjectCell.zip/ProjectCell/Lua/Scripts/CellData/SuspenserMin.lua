SuspenserMin = SuspenserMin or blt_class(SuspenserBase)

function SuspenserMin:has_tension_reached_goal()
	return managers.cell_drama:current_enemy_tension() < self._tension_goal
end