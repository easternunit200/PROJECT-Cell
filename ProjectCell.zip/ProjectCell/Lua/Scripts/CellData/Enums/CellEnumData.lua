CellEnumData = CellEnumData or blt_class()

function CellEnumData:_setup_enums_values()
	self._enum_values = {}
end

function CellEnumData:_setup_enums_values()
	self._enum_values = {}
end


function CellEnumData:init()
	self:_setup_enums_values()
	
	
	self:_init_drama_states()

end


function CellEnumData:_init_drama_states()
	self.DRAMA_State = {}
	self.DRAMA_State.Empty = 0
	self.DRAMA_State.Idle = 1
	self.DRAMA_State.Sneaking = 2
	self.DRAMA_State.Encounter = 3
	self.DRAMA_State.Alert = 4
end


CellEnumValue = CellEnumValue or blt_class()

function CellEnumValue:init()
	self._last_id = -1
end

