CD = CD or {}
CD.Player = {}
CD.Player.DeadLockePlayer = 1
