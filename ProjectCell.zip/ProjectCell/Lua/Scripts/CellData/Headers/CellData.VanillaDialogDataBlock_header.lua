CD = CD or {}
CD.VanillaDialog = {}
CD.VanillaDialog.ExtraBaseDialogues = 1
