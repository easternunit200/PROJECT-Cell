CD = CD or {}
CD.DramaState = {}
CD.DramaState.DRAMA_Sneaking = 1
CD.DramaState.DRAMA_Alert = 2
CD.DramaState.DRAMA_Control = 3
CD.DramaState.DRAMA_Anticipation = 4
CD.DramaState.DRAMA_Assault = 5
