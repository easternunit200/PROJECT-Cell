CD = CD or {}
CD.NarratorDialogue = {}
CD.NarratorDialogue.Play_On_Custody_no_civies = 1
CD.NarratorDialogue.Play_On_Custody_they_killed_civies = 5
CD.NarratorDialogue.Play_On_Custody_you_killed_civies = 6
CD.NarratorDialogue.TradeManager_wait_for_respawn = 2
CD.NarratorDialogue.TradeManager_no_hostages_has_cable_ties = 3
CD.NarratorDialogue.TradeManager_no_hostages_no_cable_ties = 4
