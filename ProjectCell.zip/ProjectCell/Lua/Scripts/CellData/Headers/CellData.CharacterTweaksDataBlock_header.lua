CD = CD or {}
CD.CharacterTweaks = {}
