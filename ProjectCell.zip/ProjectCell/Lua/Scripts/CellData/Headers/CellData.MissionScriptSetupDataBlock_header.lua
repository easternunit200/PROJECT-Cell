CD = CD or {}
CD.MissionScriptSetup = {}
CD.MissionScriptSetup.default = 1
