CD = CD or {}
CD.BranchBankMissionScript = {}
CD.BranchBankMissionScript.BranchBank_DramaStateFakeAssault_Alarm = 1
CD.BranchBankMissionScript.BranchBank_DramaStateFakeAssault_Setup = 2
CD.BranchBankMissionScript.Difficulty_Check_mayhem_and_above = 3
