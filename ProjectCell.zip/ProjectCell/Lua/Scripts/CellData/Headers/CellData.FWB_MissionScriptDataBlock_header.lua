CD = CD or {}
CD.FWB_MissionScript = {}
CD.FWB_MissionScript.FWB_DramaStateFakeAssault_Alarm = 1
CD.FWB_MissionScript.FWB_DramaStateFakeAssault_Setup = 2
CD.FWB_MissionScript.Difficulty_Check_mayhem_and_above = 3
