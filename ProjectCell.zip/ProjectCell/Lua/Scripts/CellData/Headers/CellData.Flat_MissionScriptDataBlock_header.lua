CD = CD or {}
CD.Flat_MissionScript = {}
CD.Flat_MissionScript.Flat_DramaStateFakeAssault_Alarm = 1
CD.Flat_MissionScript.Flat_DramaStateFakeAssault_Setup = 2
CD.Flat_MissionScript.Difficulty_Check_mayhem_and_above = 3
CD.Flat_MissionScript.ElementToggleoff_music_heist_anticipation = 4
