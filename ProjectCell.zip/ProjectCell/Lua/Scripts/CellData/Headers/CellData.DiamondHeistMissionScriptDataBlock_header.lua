CD = CD or {}
CD.DiamondHeistMissionScript = {}
CD.DiamondHeistMissionScript.BranchBank_DramaStateFakeAssault_Alarm = 1
CD.DiamondHeistMissionScript.BranchBank_DramaStateFakeAssault_Setup = 2
CD.DiamondHeistMissionScript.Difficulty_Check_mayhem_and_above = 3
