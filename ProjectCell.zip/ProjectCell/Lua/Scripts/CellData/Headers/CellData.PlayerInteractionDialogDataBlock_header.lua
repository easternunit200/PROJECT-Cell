CD = CD or {}
CD.PlayerInteractionDialog = {}
CD.PlayerInteractionDialog.robbing_bank_intro = 1
