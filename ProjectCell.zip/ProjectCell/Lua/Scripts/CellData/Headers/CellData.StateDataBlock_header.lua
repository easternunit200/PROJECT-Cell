CD = CD or {}
CD.State = {}
CD.State.wave_flag = 1
