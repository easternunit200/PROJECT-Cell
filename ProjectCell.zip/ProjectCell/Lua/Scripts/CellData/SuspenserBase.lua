SuspenserBase = SuspenserBase or blt_class()

function SuspenserBase:init(data)
	self._timer = 0
	self._tension_goal = data.goal_tension
	self._goal_timer = data.goal_timer
	self._state_to_switch = data.state_to_switch
end


function SuspenserBase:update(t, dt)
	if self:has_tension_reached_goal() then
		self._timer = self._timer + dt
	else
		self._timer = math.max(0, self._timer - dt)
	end
end

function SuspenserBase:has_tension_reached_goal()
	return false
end

function SuspenserBase:has_reached_goal_timer()
	return self._timer > self._goal_timer
end


function SuspenserBase:reset()
	self._timer = 0
end

function SuspenserBase:state_to_switch()
	return self._state_to_switch
end

function SuspenserBase:is_state_locked()
	return managers.cell_music:is_suspense_state_locked(self._state_to_switch)
end

function SuspenserBase:is_state_valid()
	return self._state_to_switch ~= nil or self._state_to_switch ~= MusicMachine.MUS_States.None
end

function SuspenserBase:check_music_switch()
	return not self:is_state_locked() and self:is_state_valid() and self:has_reached_goal_timer()
end