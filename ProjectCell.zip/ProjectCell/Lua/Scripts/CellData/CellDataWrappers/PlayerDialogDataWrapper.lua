PlayerDialogDataWrapper = PlayerDialogDataWrapper or blt_class(CellDataBaseWrapper)

function PlayerDialogDataWrapper:SetCoolDown(block, cooldown)
	if cooldown > -1 and cooldown < 7 then
		block.cooldown = cooldown
	else
		self:LogMessage("SetCoolDown", "Cooldown must be greater than -1 and less than 7")
	end	
end