SoundObjectDataWrapper = SoundObjectDataWrapper or blt_class(CellDataBaseWrapper)
	
	
function SoundObjectDataWrapper:setup()
	self:base_setup()	
end