CellDataBaseWrapper = CellDataBaseWrapper or blt_class()

function CellDataBaseWrapper:init(name)	
	self._name = name	
	self._is_setup = false
	self._wrapper = nil
	self._fileIsDirty = false
	self._m_uniqueInt = 0;
	self._descriptors = {}		
	self._fileNameNoExt = "CellData." .. self._name
	self._fileName = self._fileNameNoExt .. ".json"
	self._fileNameRes = self._fileNameNoExt .. "_res.json"
	self._fileNameBytes = self._fileNameNoExt .. "_bin.json"
	self._fileNameDefault = self._fileNameNoExt .. "_default.json"
	self._fileHeader = self._fileNameNoExt .. "_header.lua"
	self._headerPath = CellDataBlockManager.DATABLOCKS_HEADER_PATH .. self._fileHeader 
	self._filePathRes = CellDataBlockManager.DATABLOCKS_RESOURCE_PATH .. self._fileNameRes;
	self._filePath = CellDataBlockManager.DATABLOCKS_PATH .. self._fileName;
	self._filePathBin = CellDataBlockManager.DATABLOCKS_PATH .. self._fileNameBytes;
	self._filePathDefault = CellDataBlockManager.DATABLOCKS_PATH .. self._fileNameDefault;
	

	
	self._callbacks_on_post_setup = {}
	self:setup()
	
	if managers.cell_data:in_menu() then
		self:_setup_editor()
	end	
end 

function CellDataBaseWrapper:name()	
	return self._name
end

function CellDataBaseWrapper:wrapper()	
	return self._wrapper
end

function CellDataBaseWrapper:Blocks()	
	return self._wrapper.Blocks
end

function CellDataBaseWrapper:wrapper_name()	
	return self._name:gsub("DataBlock","");
end


function CellDataBaseWrapper:add_callback_on_post_setup(clbk)	
	table.insert(self._callbacks_on_post_setup, clbk)
end

function CellDataBaseWrapper:Serialize(indent)
	local writer = JsonWriter:new(self._wrapper, indent)
	writer:Write("Headers", "array")
	writer:Write("Blocks", "array")
	writer:WriteFinal("LastPersistentID", "number")	
	return writer:Results()
end


function CellDataBaseWrapper:get_file_contents()
	if CellDataBlockManager.IS_RESOURCE_FILE then
		if FileUtils:PathExists(self._filePathRes, true) then
			self:debug_print("Now loading blocks from -> " .. tostring(self._filePathRes))
			return FileUtils:ReadAllText(self._filePathRes, true)
		end	
	elseif FileUtils:PathExists(self._filePathDefault) then		
		--self:debug_print("Now loading blocks from -> " .. tostring(self._filePathBin))
		--return BinaryEncoder:Decode(CellDataBlockManager.m_binaryEncoder, FileUtils:ReadAllBytes(self._filePathBin))	
		self:debug_print("Now loading blocks from -> " .. tostring(self._filePathDefault))
		return FileUtils:ReadAllText(self._filePathDefault, false)
	end	
	
	return nil
end



function CellDataBaseWrapper:setup()
	self:base_setup()
end


function CellDataBaseWrapper:_setup_editor()
end


function CellDataBaseWrapper:base_setup()
	self:LoadFromDisk()	
	self._is_setup = true
	self:_setup_descriptor()
end

function CellDataBaseWrapper:_setup_descriptor()
end

function CellDataBaseWrapper:post_error(txt)
	error(CellGlobal.LogPreffix .. " : " .. self._name .. " - " .. txt)
end

function CellDataBaseWrapper:LoadFromDisk()
	local fileContents = self:get_file_contents()	
	if fileContents then
		local file_data = JsonUtils:safe_decode(fileContents)
	
		if not file_data then
			self._fileIsDirty = true
			self:post_error("setup_blocks, " .. self._name .. " failed to parse!  Report this crash to the developer....  In the mean time uninstall ProjectCell...")		
			return
		end
		
		if type(file_data) == "number" then
			self._fileIsDirty = true
			self:post_error("setup_blocks, " .. self._name .. " has returned a number value! This is suppose to be a string value. Report this crash to the developer....  In the mean time uninstall ProjectCell...")
			return
		end
		
		self._blocks_by_IDS = {}		
		self._blocks_by_names = {}		
		self._blockIDs_by_names = {}
		
		self._wrapper = file_data;		
		local builder = StringBuilder:new()
		if (not self._wrapper.LastPersistentID)  then
			self._wrapper.LastPersistentID = 0;	
			self._fileIsDirty = true		
			builder:AppendLine("\t\t<<Didn't have a LastPersistentID. Manually asssigning one>>")
		end
		
		
		
		if (not self._wrapper.Headers)  then
			self._wrapper.Headers = {};		
			self._fileIsDirty = true
			builder:AppendLine("\t\t<< didn't have a Headers. Manually creating one>>")
		end
		
		self:CheckLastPersistentID()
		--SerializableObject.apply_class_to_array(self._wrapper, "Headers", "CellDataHeader")	
		
		for i, block in pairs(self._wrapper.Blocks) do
			

			if block.internalEnabled == nil or type(block.internalEnabled) ~= "boolean" then
				block.internalEnabled = false
				self._fileIsDirty = true
				builder:AppendLine("\t\t<<A block has the field internalEnabled that is NOT a Boolean!!>>")
			end
			
			if not block.persistentID then
				block.persistentID = 0;
				self._fileIsDirty = true
				builder:AppendLine("\t\t<<A block didn't have a persistentID field in Wrapper !!>>")
				self:CheckPersistentID(block, false);
			end
			
			if block.persistentID <= 0 then
				self._fileIsDirty = true
				builder:AppendLine("\t\t<<A block has a persistentID of 0, reassigning!!>>")
				self:CheckPersistentID(block, false);
			end
			
			if not block.name then
				block.name = "UnnamedBlock";
				self._fileIsDirty = true
				builder:AppendLine("\t\t<<A block didn't have a name field in Wrapper!!>>")
			end

			if self._blocks_by_IDS[block.persistentID] then			
				builder:AppendLine("\t\t<<Block " ..block.name.." "..tostring(block.persistentID).."   has a duplicate ID, reassigning. >>")
				self:CheckPersistentID(block, true);	
			end

			if self._blocks_by_names[block.name] then
				builder:AppendLine("\t\t<<Block " ..block.name.." "..tostring(block.persistentID).."   has a duplicate NAME, renaming! >>")
				self:EnsureUniqueName(block, self._blocks_by_names, "", true)			
				builder:AppendLine("\t\t<<Block has been rennamed  to " ..block.name..">>")
			end
			
			
			
			--local classed_block = self._block_class:load(block)
			
			
			
			--self:clean_block(classed_block)
			
			self._wrapper.Blocks[i] = block
			
			self._blocks_by_IDS[block.persistentID] = block			
			self._blocks_by_names[block.name] = block			
			self._blockIDs_by_names[block.name] = block.persistentID			
		end
		
		
		
		
		--self:debug_print(" <<<<<<<<<<<Setup complete!>>>>>>>");	
		

		
		
		
		if self._fileIsDirty then
			self:SaveToDisk()
			self._fileIsDirty = false
			self:debug_print(" <<<<<<<NOTE: This file is dirty and had to be fixed during runtime, it has been cleaned out and saved....>>>>>>");	
			self:debug_print( builder:Results())
		else
			self:debug_print("Loaded Successfully with no problems..");	
		end
		
		
		if (not FileUtils:DirectoryExists(CellDataBlockManager.DATABLOCKS_HEADER_PATH)) then
			error("[CellDataBaseWrapper:init] ["..self._name.."] ERROR: " ..CellDataBlockManager.DATABLOCKS_HEADER_PATH.." doesn't exist! Did we delete this folder?")
		end
		
		
		if not FileUtils:LoadFile(self._headerPath) then
			CellGlobal:log("[CellDataBaseWrapper:init] ["..self._name.."] ERROR: " ..self._headerPath.." doesn't exist! We need this header file in order to utilize the data blocks more efficiently.")
		end
		
		self:PostLoadFromDisk()
		return		
	end
	
	self:debug_print("No blocks whatsoever.. Starting off fresh!")
	self:_reset_blocks()
end

function CellDataBaseWrapper:_reset_blocks()
	self._blocks_by_IDS = {}		
	self._blocks_by_names = {}		
	self._blockIDs_by_names = {}
	self._wrapper = {}
	self._wrapper.Headers = {}
	self._wrapper.Blocks = {}
	self._wrapper.LastPersistentID = 0	
end




function CellDataBaseWrapper:toggle_editor()
end


function CellDataBaseWrapper:GetDropDownInfo(id, add_none)
	local dropDownInfo = CellDataDropDownInfo:new()	
	if add_none then 
		dropDownInfo:add_item({
			id = 0,
			name = "None"
		})
	end
	
	if id and self:get_block(id) == nil then
		dropDownInfo:add_item({
			id = id,
			name = "UNKNOWN"
		})
	end
	
	for index, block in pairs(self._wrapper.Blocks) do
		dropDownInfo:add_item({
			id = block.persistentID,
			name = block.name
		})
	end
	
	return dropDownInfo
end



function CellDataBaseWrapper:LogMessage(function_name, message)
end

function CellDataBaseWrapper:debug_print(message)
	managers.cell_data:debug_print("[" .. self._name .. "] ".. message)
end


function CellDataBaseWrapper:CheckLastPersistentID(log_print)
	self._wrapper.LastPersistentID = 0
	for _, block in pairs(self._wrapper.Blocks) do
		self._wrapper.LastPersistentID = math.max(self._wrapper.LastPersistentID, block.persistentID);
	end
	
	if log_print then
		self:debug_print(" updated LastPersistentID : "..  self._wrapper.LastPersistentID);
	end	
end

function CellDataBaseWrapper:CheckPersistentID(block, force)
	if force or block.persistentID <= 0 then
		self._wrapper.LastPersistentID = self._wrapper.LastPersistentID + 1;		
		block.persistentID = self._wrapper.LastPersistentID;		
		self:debug_print("CheckPersistentID, Setting persistentID to: " .. block.persistentID);
		self._fileIsDirty = true
	end	
end

function CellDataBaseWrapper:EnsureUniqueName(block, existingNames, originalName, first)

	if first then
		self._m_uniqueInt = 0;
		originalName = block.name;
	end
	
	local nameExists = existingNames[block.name]
	
	if nameExists  then
		self._m_uniqueInt = self._m_uniqueInt + 1;		
		block.name = originalName .. "_" ..self._m_uniqueInt;
		self:EnsureUniqueName(block, existingNames, originalName, false);
	end
	
end

function CellDataBaseWrapper:print_results()
	local results = ""
	for _,block in pairs(self._wrapper.Blocks) do
		results = results.."\t\tblock.name: "..block.name.."\n"
		results = results.."\t\tblock.persistentID: "..block.persistentID.."\n"
		results = results.."\t\tblock.internalEnabled : "..tostring(block.internalEnabled).."\n\n"			
	end
	
	self:debug_print(" results:\n"..results);
	
	if self._fileIsDirty then
		self:debug_print("print_results", " this file is dirty, must stabilize it before releasing..");
	end
end

function CellDataBaseWrapper:editor()
end


function CellDataBaseWrapper:post_setup()
end

function CellDataBaseWrapper:PostLoadFromDisk()
	for i, clbk in pairs(self._callbacks_on_post_setup) do
		clbk()
	end
	
	if self._fileIsDirty then
		self:SaveToDisk()
		self._fileIsDirty = false
	end
end


function CellDataBaseWrapper:generateHeaderFile()
end

function CellDataBaseWrapper:SaveToDisk()
	self:DoSaveToDisk(false,false)
end

function CellDataBaseWrapper:SaveToDiskBinary()
	self:DoSaveToDisk(false,true)
end

function CellDataBaseWrapper:SaveToDiskAndGenerateHeader()
	self:DoSaveToDisk(true,false)
end

function CellDataBaseWrapper:SaveToDiskBinaryAndGenerateHeader()
	self:DoSaveToDisk(true,true)
end

function CellDataBaseWrapper:_start_writing(path)
end

function CellDataBaseWrapper:DoSaveToDisk(generateHeaderFile, saveBinary, is_resource)
end


function CellDataBaseWrapper:get_all_blocks()
	local list = {}
	for index, block in pairs(self._wrapper.Blocks) do
		if block.internalEnabled then
			table.insert(list,block)
		end	
	end
	return list
end

function CellDataBaseWrapper:get_wrapper_for_release()
	local cloned_wrapper = deep_clone(self._wrapper)
	
	for i = #cloned_wrapper.Blocks, 1,-1 do
		if not cloned_wrapper.Blocks[i].internalEnabled then
			table.remove(cloned_wrapper.Blocks, index)
		end
	end
	
	return cloned_wrapper
end


function CellDataBaseWrapper:get_block_by_id(ID)
	if ID == 0 then
		return nil
	end
	
	
	return self._blocks_by_IDS[ID]
end

function CellDataBaseWrapper:get_block_by_name(name)
	return self._blocks_by_names[name]
end



function CellDataBaseWrapper:get_block(value)
	if value == nil then
		return nil
	end
	
	local valType = type(value)
	if valType == "string" then
		return self:get_block_by_name(value)
	elseif valType == "number" then
		return self:get_block_by_id(value)
	end
end

function CellDataBaseWrapper:rename_block(block, newName)
	self._blockIDs_by_names[block.name] = nil
	self._blocks_by_names[block.name] = nil

	block.name = newName
	
	self:EnsureUniqueName(block, self._blocks_by_names, "", true)
	
	self._blocks_by_names[block.name] = block
	self._blockIDs_by_names[block.name] = block.persistentID
end

function CellDataBaseWrapper:add_block(block, addIndex)
	self:CheckPersistentID(block, false)
	self:EnsureUniqueName(block, self._blocks_by_names, "", true)
	
	if addIndex and addIndex >= 0 then
		table.insert(self._wrapper.Blocks, addIndex, block)
	else
		table.insert(self._wrapper.Blocks, block)
	end
	
	self._blocks_by_names[block.name] = block	
	self._blockIDs_by_names[block.name] = block.persistentID
	self._blocks_by_IDS[block.persistentID] = block
end


function CellDataBaseWrapper:add_new_block(index)
	local block = {}
	block.name = "New_Block"
	block.internalEnabled = false
	block.persistentID = 0	
	self:add_block(block, index or -1)	
	return block
end

function CellDataBaseWrapper:add_new_block_and_name(name, index)
	local new_block = self:add_new_block(index)
	self:rename_block(new_block, name)
	return new_block
end


function CellDataBaseWrapper:create_new_copy(source, index)
	--index = math.min(table.index_of(self._wrapper.Blocks, source) + 1, BlocksCount)
	index = index or -1
	
	local t = deep_clone(source)
	t.name = t.name .. "_Copy"
	t.persistentID = 0
	self:CheckPersistentID(t, false)
	
	self:add_block(t, index)
	return t	
end


function CellDataBaseWrapper:delete_block(block)
	local index = table.index_of(self._wrapper.Blocks, block)
	
	table.remove(self._wrapper.Blocks, index)
	
	self._blocks_by_names[block.name] = nil	
	self._blockIDs_by_names[block.name] = nil
	self._blocks_by_IDS[block.persistentID] = nil
end