TextDataWrapper = TextDataWrapper or blt_class(CellDataBaseWrapper)
TextDataWrapper.Language = {
	English = Idstring("english"),
	French = Idstring("french"),
	Italian = Idstring("italian"),
	German = Idstring("german"),
	Spanish = Idstring("spanish"),
	Russian = Idstring("russian"),
	Portuguese_Brazil = Idstring("portuguese"),
	Polish = Idstring("polish"),
	Japanese = Idstring("japanese"),
	Korean = Idstring("korean"),
	Chinese_Traditional = Idstring("chinese"),
	Chinese_Simplified = Idstring("chinese")
}

TextDataWrapper.FORCE_LANGUAGE = nil

function TextDataWrapper:init(name)
	TextDataWrapper.super.init(self, name)
	self:begin_translations()
end

function TextDataWrapper:create_translation_data()
	return {
		Translation = "",
		ShouldTranslate = true
	}
end

function TextDataWrapper:add_new_block(index)
	local block = TextDataWrapper.super.add_new_block(self, index)
	block.English = ""
	block.Description = ""
	block.SkipLocalization = true
	block.ImportVersion = 0
	block.ExportVersion = 0
	block.Spanish = self:create_translation_data()
	block.Polish = self:create_translation_data()
	block.Chinese_Traditional = self:create_translation_data()
	block.Chinese_Simplified = self:create_translation_data()
	block.Japanese = self:create_translation_data()
	block.Portuguese_Brazil = self:create_translation_data()
	block.Korean = self:create_translation_data()
	block.Russian = self:create_translation_data()
	block.French = self:create_translation_data()
	block.German = self:create_translation_data()
	return block
end


function TextDataWrapper:setup()
	self:base_setup()
end

function TextDataWrapper:localize(localization_key, language_data)
	if not language_data or language_data.ShouldTranslate or not language_data.Translation then
		return
	end
	
	self._current_localization_data[localization_key] = language_data.Translation
end


function TextDataWrapper:get_language_name_by_key(target_language_key)
	for lang_name, lang_data in pairs(TextDataWrapper.Language) do
		if lang_data:key() == target_language_key then
			return lang_name
		end
	end
	return "UNKNOWN LANGUAGE"
end

function TextDataWrapper:get_language_key_by_name(target_language_name)
	for lang_name, lang_data in pairs(TextDataWrapper.Language) do
		if lang_name == target_language_name then
			return lang_data:key()
		end
	end
	return nil
end


function TextDataWrapper:begin_translations()
	self._current_localization_data = {}
	self._current_language_key = SystemInfo:language():key()
	
	if TextDataWrapper.FORCE_LANGUAGE then
		self._current_language_key = self:get_language_key_by_name(TextDataWrapper.FORCE_LANGUAGE)
		self:debug_print("Forcing langauge : " .. TextDataWrapper.FORCE_LANGUAGE)
	end	
	
	for index, block in pairs(self:get_all_blocks()) do
		self._current_localization_data[block.name] = block.English
		if not block.SkipLocalization then	
			local localization_key = block.name
			if self._current_language_key == TextDataWrapper.Language.German:key() then
				self:localize(localization_key, block.German)
				
			elseif self._current_language_key == TextDataWrapper.Language.Spanish:key() then
				self:localize(localization_key, block.Spanish)
				
			elseif self._current_language_key == TextDataWrapper.Language.Russian:key() then
				self:localize(localization_key,  block.Russian)
				
			elseif self._current_language_key == TextDataWrapper.Language.French:key() then
				self:localize(localization_key,  block.French)
			end		
		end		
	end
	
	LocalizationManager:add_localized_strings(self._current_localization_data, true)
end