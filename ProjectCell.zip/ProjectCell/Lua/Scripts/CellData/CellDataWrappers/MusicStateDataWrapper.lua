MusicStateDataWrapper = MusicStateDataWrapper or blt_class(CellDataBaseWrapper)

function MusicStateDataWrapper:setup()
	self:base_setup()
	
	local music_states = {
		"None",
		"Silence",
		"Sneaking",
		"Sneaking Suspense : Low",
		"Sneaking Suspense : Medium",
		"Sneaking Suspense : High",
		"Sneaking Suspense : Extreme",
		"Control",
		"Anticipation",
		"Assault",
		"Fake Assault",
		"Escape"
	}
end