SwitchStateContainerBaseDataWrapper = SwitchStateContainerBaseDataWrapper or blt_class(CellDataBaseWrapper)

function SwitchStateContainerBaseDataWrapper:_init_definitions(switchType)
	self._switchType = switchType
	self._switchGroupDataByName = {}	
	self._switchGroupDataByID = {}	
	for _, block in pairs(self:get_all_blocks()) do
		local cell_switch_data = CellSwitchGroupData:new(block, switchType)
		self._switchGroupDataByID[block.persistentID] = cell_switch_data
		self._switchGroupDataByName[block.name] = cell_switch_data
	end
end



function SwitchStateContainerBaseDataWrapper:get_set_switch_data(switch_groupID, switchID)	
	if switch_groupID == nil then
		self:debug_print("[SwitchStateContainerBaseDataWrapper:get_set_switch_data] switch_groupID is nil!!")
		return nil
	end
	
	if switchID == nil then
		self:debug_print("[SwitchStateContainerBaseDataWrapper:get_set_switch_data] switchID is nil!!")
		return nil
	end
	
	if type(switch_groupID) ~= "number" and type(switch_groupID) ~= "string" then
		self:debug_print("[SwitchStateContainerBaseDataWrapper:get_set_switch_data] switch_groupID is invalid!!")
		return nil
	end
	
	
	
	local switchGroupData
	if type(switch_groupID) == "string" then
		switchGroupData = self._switchGroupDataByName[switch_groupID]	
	elseif type(switch_groupID) == "number" then
		switchGroupData = self._switchGroupDataByID[switch_groupID]	
	end
	
	if not switchGroupData then
		self:debug_print("[SwitchStateContainerBaseDataWrapper:get_set_switch_data] switchGroupData is not valid! : " ..tostring(switch_groupID))
		return nil
	end
	
	
	local switchData
	if type(switchID) == "string" then
		switchData = switchGroupData:_switchData_by_name(switchID) 
	elseif type(switchID) == "number" then
		switchData = switchGroupData:_switchData_by_id(switchID) 
	end
	
	if not switchData then
		self:debug_print("[SwitchStateContainerBaseDataWrapper:get_set_switch_data] switchID is not valid! : " ..tostring(switchID))
		return nil
	end
	
	return {
		switchBlock = switchGroupData:switch_block(),
		switchData = switchData
	}	
end