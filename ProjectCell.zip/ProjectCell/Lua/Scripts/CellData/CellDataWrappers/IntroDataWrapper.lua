IntroDataWrapper = IntroDataWrapper or blt_class(CellDataBaseWrapper)

function IntroDataWrapper:setup()
	self:base_setup()
end
