PlayerModOptionsDataWrapper = PlayerModOptionsDataWrapper or blt_class(CellDataBaseWrapper)

function PlayerModOptionsDataWrapper:setup()
	self:base_setup()
	
	self:add_descriptor("Title", DataDescriptor:new({
		type = DataDescriptor.DataLayoutType.TextBox,
		headerText = "TITLE OF THE NODE",
		hasHeader = true,
	}))	
	
	self:add_descriptor("Desc", DataDescriptor:new({
		type = DataDescriptor.DataLayoutType.TextBox,
		headerText = "DESCRIPTION",
		hasHeader = true,
		comment = "This will display when the mouse is hovered over the item",
	}))	
	
	self:add_descriptor("callback", DataDescriptor:new({
		type = DataDescriptor.DataLayoutType.TextBox,
		headerText = "Callback",
		hasHeader = true
	}))	
end
