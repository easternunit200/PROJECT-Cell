SoundAudioDataWrapper = SoundAudioDataWrapper or blt_class(CellDataBaseWrapper)

function SoundAudioDataWrapper:setup()
	self:base_setup()	
end