VanillaDialogDataWrapper = VanillaDialogDataWrapper or blt_class(CellDataBaseWrapper)

function VanillaDialogDataWrapper:setup()
	self:base_setup()
end