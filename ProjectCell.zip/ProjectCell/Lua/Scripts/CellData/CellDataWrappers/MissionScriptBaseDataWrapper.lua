MissionScriptBaseDataWrapper = MissionScriptBaseDataWrapper or blt_class()

function MissionScriptBaseDataWrapper:setup()
	self:base_setup()	
end