UserDataWrapper = UserDataWrapper or blt_class(CellDataBaseWrapper)

function UserDataWrapper:setup()
	self:base_setup()
end