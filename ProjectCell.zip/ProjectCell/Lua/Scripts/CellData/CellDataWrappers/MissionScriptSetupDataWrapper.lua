MissionScriptSetupDataWrapper = MissionScriptSetupDataWrapper or blt_class(CellDataBaseWrapper)

function MissionScriptSetupDataWrapper:init(...)
	MissionScriptSetupDataWrapper.super.init(self,...)
	self._current_mission_data_wrapper = nil
	self._mission_script = nil
	self._last_element_id = 0
end

function MissionScriptSetupDataWrapper:setup_mission_wrapper(mission_script)
	local block = self:get_block_by_id(1)
	
	local level_id = Global.level_data and Global.level_data.level_id
	
	if level_id then
		if block.levels and next(block.levels) then
			for _, level_data in pairs(block.levels) do
				if level_data.level_id and level_data.level_id == level_id and level_data.mission_script_name and level_data.mission_script_name == mission_script:name() then
					if level_data.load_block  then
						self:debug_print("Setting up mission_script_wrapper for " .. tostring(level_id) .. " for mission script name " .. tostring(mission_script:name()))
						self:set_mission_wrapper(managers.cell_data:wrapper(level_data.load_block), mission_script)
						return
					end					
				end				
			end
		end
	end
	
	self:debug_print("Did not find a mission_script_wrapper for " .. tostring(level_id) .. " with mission script name : " .. tostring(mission_script:name()))
end

function MissionScriptSetupDataWrapper:clean_on_executed(on_executed_params)
	for i, param in pairs(on_executed_params) do
		if not param.delay then
			param.delay = 0
		end
		if param.block_id then
			local another_block = self._current_mission_data_wrapper:get_block_by_id(param.block_id)			
			if another_block then
				if another_block.ElementID then
					param.id = another_block.ElementID
					self:debug_print("Setting Param ID " .. tostring(param.id) .. " from  block id " .. tostring(param.block_id))
				else
					self:debug_print("ERROR : another_block with an id of " .. tostring(another_block.name) .. " is missing an ElementID!!")
				end				
			else
				self:debug_print("ERROR : Could not find a block with an id : " .. tostring(param.block_id))
			end
		end
	end
end

function MissionScriptSetupDataWrapper:verify_last_mission_element(mission_script)
	for id, element in pairs(mission_script:elements()) do
		self._last_element_id = math.max(self._last_element_id, element:id())
	end
end

function MissionScriptSetupDataWrapper:get_next_mission_element_id()
	self._last_element_id = self._last_element_id + 1
	return self._last_element_id
end


function MissionScriptSetupDataWrapper:_add_element_to_existing(block)
	if not block.element then
		self:debug_print("ERROR : " .. tostring(block.name) .. " doesn't have an element!! : ")
		return
	end
	
	if block.AddToElementID and block.AddToElementID > 0 then
		local element = self._mission_script:element(block.AddToElementID)
		if element then
			table.insert(element:value("on_executed"), 
			{
				id = block.ElementID, 
				delay = block.BaseDelay or 0
			})
		else
			self:debug_print("ERROR : vanilla mission element id " .. tostring(block.AddToElementID) .. " does not exist!!")
		end								
	end		
end

function MissionScriptSetupDataWrapper:_print_new_element_added(block)
	if block.module_name and block.module_name ~= "none" then
		self:debug_print(" Created CoreMissionManager." .. tostring(block.module_name) .."."..tostring(block.class_name) .. " with element id : " .. tostring(block.ElementID))
	else
		self:debug_print(" Created " .. tostring(block.class_name) .. " with element id : " .. tostring(block.ElementID))
	end
end


function MissionScriptSetupDataWrapper:clean_values(values)
	values.base_delay = values.base_delay or 0	
	values.trigger_times = values.trigger_times or 0 	
	if values.position then
		if type(values.position) == "string" then
			value.position = StringBuilder:_string_to_vector3(values.position)
		end
	else
		values.position = Vector3(0,0,0)
	end	
	if values.rotation then
		if type(values.rotation) == "string" then
			value.rotation = StringBuilder:_string_to_rotation(values.rotation)
		end
	else
		values.rotation = Rotation(0,0,0)
	end
end

function MissionScriptSetupDataWrapper:set_mission_wrapper(wrapper, mission_script)
	self._current_mission_data_wrapper = wrapper
	self._mission_script = mission_script
	
	self:verify_last_mission_element(mission_script)	
	
	
	local elements = mission_script:elements()
	
	local all_blocks = self._current_mission_data_wrapper:get_all_blocks()
	
	for i,block in pairs(all_blocks) do		
		block.ElementID = self:get_next_mission_element_id()			
	end
	
	for i,block in pairs(all_blocks) do		
		if not mission_script:element(block.ElementID) then	
			local element_class = mission_script:_element_class(block.module_name, block.class_name)				
			if element_class then
				local data = {
					editor_name = block.name,
					id = block.ElementID,
					values = block.values
				}		

				self:clean_values(data.values)
				
				local new_element = element_class:new(mission_script, data)		
						
				new_element._class = block.class_name
				
				block.element = new_element				
				elements[block.ElementID] = new_element
				
				
				
				self:_print_new_element_added(block)				
				self:_add_element_to_existing(block)				
			end									
		end					
	end
	
	for index, block in pairs(all_blocks) do
		if block.values and block.values.on_executed and next(block.values.on_executed) then
			self:clean_on_executed(block.values.on_executed)
		end	
	end
	
	
end

function MissionScriptSetupDataWrapper:current_mission_wrapper()
	return self._current_mission_data_wrapper
end