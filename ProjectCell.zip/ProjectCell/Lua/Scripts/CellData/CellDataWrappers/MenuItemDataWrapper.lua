MenuItemDataWrapper = MenuItemDataWrapper or blt_class(CellDataBaseWrapper)

function MenuItemDataWrapper:setup()
	self:base_setup()
end

