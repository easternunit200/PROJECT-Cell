StateDataWrapper = StateDataWrapper or blt_class(SwitchStateContainerBaseDataWrapper)


function StateDataWrapper:setup()
	self:base_setup()	
end
