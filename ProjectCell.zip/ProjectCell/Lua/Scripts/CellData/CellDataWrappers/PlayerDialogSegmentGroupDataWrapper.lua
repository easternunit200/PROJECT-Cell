PlayerDialogSegmentGroupDataWrapper = PlayerDialogSegmentGroupDataWrapper or blt_class(CellDataBaseWrapper)

function PlayerDialogSegmentGroupDataWrapper:setup()
	self:base_setup()		
end
