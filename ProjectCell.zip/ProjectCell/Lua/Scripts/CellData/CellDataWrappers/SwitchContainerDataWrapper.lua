SwitchContainerDataWrapper = SwitchContainerDataWrapper or blt_class(SwitchStateContainerBaseDataWrapper)


function SwitchContainerDataWrapper:setup()
	self:base_setup()	
end