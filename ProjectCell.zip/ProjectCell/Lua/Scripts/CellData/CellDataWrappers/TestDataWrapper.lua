TestDataWrapper = TestDataWrapper or blt_class(CellDataBaseWrapper)

function TestDataWrapper:setup()
	self:base_setup()
end