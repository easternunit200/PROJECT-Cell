SoundEventDataWrapper = SoundEventDataWrapper or blt_class(CellDataBaseWrapper)

function SoundEventDataWrapper:setup()
	self:base_setup()	
end
