EnemyWatcher = EnemyWatcher or blt_class()

function EnemyWatcher:init(unit)
	self._unit = unit
	self._key = unit:key()
end

function EnemyWatcher:is_alive()
	return self._unit and alive(self._unit) and not self._unit:character_damage():dead()
end

function EnemyWatcher:remove()
end

function EnemyWatcher:update(t,dt)
	if not self:is_alive() then
		return
	end
	
	for chararacter, machine in pairs(managers.cell_drama:synced_machines()) do
		if machine:is_owner_alive() then
			local enemy_head_pos = self._unit:movement():m_head_pos()
			local is_sighted = machine:is_sight_with_owner_or_teammate(enemy_head_pos)			
			if is_sighted then
			end
		end
	end
end