LocalPlayerCondition = LocalPlayerCondition or blt_class()

function LocalPlayerCondition:init(unit)
	self._unit = unit
end

function LocalPlayerCondition:on_downed()
end

function LocalPlayerCondition:on_reset()
end

function LocalPlayerCondition:on_custody()
end

function LocalPlayerCondition:get_maximum_downs_until_death()
	local last_down = 3
	local additional_lives = managers.player:has_category_upgrade("player", "additional_lives") and true or false
	if additional_lives then
		last_down = last_down + 1
	end
	if Global.game_settings.one_down then
		last_down = last_down - 2
	end
	return last_down
end


function LocalPlayerCondition:revives_left()
	return self._unit:character_damage():get_revives()
end