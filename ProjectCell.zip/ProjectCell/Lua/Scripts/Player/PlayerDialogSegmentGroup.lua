PlayerDialogSegmentGroup = PlayerDialogSegmentGroup or class()
function PlayerDialogSegmentGroup:init(block)
	self._block_persistentID = block.persistentID
	self._drama_filter = PlayerDramaFilter:new(block.Dramafilter)
	self._tension_filter = PlayerTensionLimiter:new(block.TensionLimit)
	self._criminals_alive = block.CriminalsAlive or 0
	self._override_actors = block.PlayerOverrideActors
	self._allowedActors = block.PlayerActorsAllowed
	self._blockedActors = block.PlayerActorsBlocked
	self._switchDialogID = block.SwitchDialogID
	self._switchDialogChance = block.SwitchDialogChance
	self._conditions = PlayerActorConditions:new(block.PlayerActorConditions)
	
	self._dialog_segments = {}
	self._current_segment = nil
	self._current_params = nil
	self._current_segment_order = 0
	self._next_line_t = nil
	self._is_playing = false
	
	for i, segment_data in pairs(block.DialogSegments) do
		self._dialog_segments[i] = PlayerDialogSegment:new(segment_data, i, self)	
	end
end





function PlayerDialogSegmentGroup:get_filtered_actors(list)
	if self._blockedActors and next(self._blockedActors) then
		for actor, character in pairs(list) do
			if character == self._blockedActors[actor] then
				return false
			end
		end
	end
	
	
	if self._allowedActors and next(self._allowedActors) then
		for actor, char in pairs(self._allowedActors) do
			if actor and StringUtils:isNotNilorEmpty(char) then
				local character = managers.player_dialog:get_character_by_actor(list, actor)
				if character and character ~= char then
					return false
				end
			end
		end
	end
	
	return true
end


function PlayerDialogSegmentGroup:verify_each_segment(actors)
	local list = deep_clone(actors)	
	
	
	for i, segment in pairs(self._dialog_segments) do
		DeadLocke:debug_log("[PlayerDialogSegmentGroup:verify_each_segment] character tags for segment "..tostring(segment._order))
		local entries = segment:get_all_criminals({actors = list, skip_talking_check = true}) 
		local unskippable = segment:unskippable()
		local pass = next(entries)
		if not pass and unskippable then
			return false
		end
		if pass then
			if list then
				local test_entry = entries[math.random(#entries)]
				if test_entry then
					segment:tag_actor(list, test_entry.name)
				end
			end
		end
	end
	
	return true
end


function PlayerDialogSegmentGroup:end_segments()
	self._is_playing = false
	for i, segment in pairs(self._dialog_segments) do
		segment:destroy_segment()
	end
	self._current_segment_order = 0
	self._current_segment = nil
	self._current_params = nil
	self._next_line_t = nil
end

function PlayerDialogSegmentGroup:amount_of_char_criminals_alive()
	local amount = 0
	for u_key, u_data in pairs(managers.player_dialog:criminals()) do
		if u_data.unit and alive(u_data.unit) then
			amount = amount + 1
		end
	end
	return amount
end



function PlayerDialogSegmentGroup:next_line_delayed(timer)
	self._next_line_t = TimerManager:game():time() + timer
end


function PlayerDialogSegmentGroup:update(t, dt)
	if self._next_line_t and self._next_line_t < t then
		self._next_line_t = nil
		self:play_next_segment()		
	end
end


function PlayerDialogSegmentGroup:dialog_params()
	return self._current_params
end


function PlayerDialogSegmentGroup:play_segments(params, delay)
	self:end_segments()
	self._is_playing = true
	self._next_line_t = nil
	self._current_params = params or {}
	if self._override_actors then
		managers.player_dialog:current_dialog().actors = {}
		local actors = managers.player_dialog:current_dialog().actors
		for actor, character in pairs(self._override_actors) do
			if StringUtils:isNotNilorEmpty(character) then
				managers.player_dialog:tag_actor(actors, character, actor)
			end			
		end
	end
	
	if delay and delay > 0 then
		self:next_line_delayed(delay)
		return
	end
	
	self:play_next_segment()
end



function PlayerDialogSegmentGroup:finished(allow_switch)
	self:end_segments()
	managers.player_dialog:finished()
	
	if allow_switch then
		if self._switchDialogID > 0 then
			if self._switchDialogChance == 1 or self._switchDialogChance > math.random()  then
				managers.player_dialog:queue_dialog(self._switchDialogID, self._current_params)
			end		
		end
	end	
end

function PlayerDialogSegmentGroup:debug_hud_text(text)
	log(text)
end

function PlayerDialogSegmentGroup:get_segment_by_index(index)
	return self._dialog_segments[index]
end

function PlayerDialogSegmentGroup:get_length()
	return #self._dialog_segments
end


function PlayerDialogSegmentGroup:play_next_segment()
	self._current_segment_order = self._current_segment_order + 1
	self._current_segment = self:get_segment_by_index(self._current_segment_order)
	DeadLocke:debug_log("Attempting to play segment order " ..tostring(self._current_segment_order))
	if not self._current_segment then		
		self:finished()
		return
	end
	self._current_segment:play_line()
end




function PlayerDialogSegmentGroup:verification(params, actors, dice)
	
	local list = deep_clone(actors)
		
	if self._override_actors and next(self._override_actors) then
		list = {}
		for actor, character in pairs(self._override_actors) do			
			managers.player_dialog:tag_actor(list, character, actor)
		end
	end
	
	if not self:get_filtered_actors(list) then
		DeadLocke:debug_log("            [PlayerDialogSegmentGroup:verification] failed segment actors verification...")
		return
	end
	
	
	if not self:verify_each_segment(list) then		
		DeadLocke:debug_log("            [PlayerDialogSegmentGroup:verification] failed segment possibilities verification...")
		return false
	end
	
	
	if not self:verify_drama_state(params) then		
		DeadLocke:debug_log("            [PlayerDialogSegmentGroup:verification] drama state invalid, no go...")
		return false
	end
	
	if not self:verify_tension(params) then
		DeadLocke:debug_log("            [PlayerDialogSegmentGroup:verification] tension did not pass, no go...")
		return false
	end
	
	if self._criminals_alive and self._criminals_alive > self:amount_of_char_criminals_alive() then	
		DeadLocke:debug_log("            [PlayerDialogSegmentGroup:verification] there are less criminals alive than this segment group requires...")
		return false
	end
	
	
	
	
	return true
end





function PlayerDialogSegmentGroup:verify_drama_state(params)
	if params.m_overrideFiltersNext then
		return true
	end
	
	return self._drama_filter:is_valid()
end


function PlayerDialogSegmentGroup:verify_tension(params)
	if params.m_overrideFiltersNext then
		return true
	end
	
	return self._tension_filter:is_valid()
end


function PlayerDialogSegmentGroup:addition_verification(params)
	return true
end

function PlayerDialogSegmentGroup:handler()
	return nil
end