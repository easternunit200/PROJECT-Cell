PlayerTensionLimiter = PlayerTensionLimiter or blt_class()
PlayerTensionLimiter.NONE = 0
PlayerTensionLimiter.LOW = 1
PlayerTensionLimiter.MEDIUM = 2

function PlayerTensionLimiter:init(limit_type)
	self._limit_type = limit_type
end

function PlayerTensionLimiter:is_no_go(tension_limit)
	return managers.cell_drama:current_tension() > tension_limit
end


function PlayerTensionLimiter:is_valid()
	if self._limit_type == PlayerTensionLimiter.NONE then
		return true
	end
	
	local block = managers.cell_data:wrapper("PlayerDataBlock"):get_block_by_id(1)
	
	if self._limit_type == PlayerTensionLimiter.LOW and self:is_no_go(block.lowTensionMaxLimit) then
		return false
	end
	
	if self._limit_type == PlayerTensionLimiter.MEDIUM and self:is_no_go(block.mediumTensionMaxLimit) then
		return false
	end
	
	return true
end