PlayerDramaFilter = PlayerDramaFilter or blt_class()
function PlayerDramaFilter:init(filter)
	self._filter = filter
end

function PlayerDramaFilter:is_valid()
	return not self._filter or self._filter[managers.cell_drama:current_state_name()]
end