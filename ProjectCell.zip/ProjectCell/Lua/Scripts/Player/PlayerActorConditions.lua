PlayerActorConditions = PlayerActorConditions or blt_class()
PlayerActorConditions.CONDITIONS = {
	"Very_Close_To_ActorA",
	"Very_Close_To_ActorB",
	"Very_Close_To_ActorC",
	"Very_Close_To_ActorD",
	"Close_To_ActorA",
	"Close_To_ActorB",
	"Close_To_ActorC",
	"Close_To_ActorD",
	"Far_From_ActorA",
	"Far_From_ActorB",
	"Far_From_ActorC",
	"Far_From_ActorD",
	"Very_Far_From_ActorA",
	"Very_Far_From_ActorB",
	"Very_Far_From_ActorC",
	"Very_Far_From_ActorD",
	"Is_All_Alive",
	"Is_All_Dead",
	"Is_Arrested",
	"Is_Being_Tased",
	"Is_Carrying_Heavy",
	"Is_Carrying_Light",
	"Is_Carrying_Normal",
	"Is_Downed",
	"Is_Duo",
	"Is_Four_Alive",
	"Is_One_Alive",
	"Is_One_Dead",
	"Is_Quad",
	"Is_Solo",
	"Is_Three_Alive",
	"Is_Three_Dead",
	"Is_Trio",
	"Is_Two_Alive",
	"Is_Two_Dead"	
}



function PlayerActorConditions:init(actor_conditions)	
	self._flagsBuilder = FlagsBuilder:new(PlayerActorConditions.CONDITIONS)
	self._actor_conditions = actor_conditions
end



function PlayerActorConditions:is_valid(actor_unit, actors)
	if not self._conditions or not next(self._conditions) then
		return true
	end
	
	if self._actor_conditions.ActorA and self._actor_conditions.ActorA > 0 then
		local results = self._flagsBuilder:create_results(self._actor_conditions.ActorA)
		
		if results:has_result("Very_Close_To_ActorB") then
		
		end
	
	end

	
	return true
end


