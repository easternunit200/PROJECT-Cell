PlayerDialogCastingDirector = PlayerDialogCastingDirector or blt_class()

function PlayerDialogCastingDirector:init()
	self._current_cast = {}
	self._current_dialog_id = 0
end


function PlayerDialogCastingDirector:generate_dialog_alternatives(dialogAlternatives, params)
	local alternatives = {}
	
	local weightHandler = WeightHandler:new() 
	
	for i, data in pairs(dialogAlternatives) do
		if data.structure and data.enabled then
			local structure = data.structure
			
			local segments = {}
			for index, line in pairs(structure.lines) do
				
			end

			
		end
	end
end

function PlayerDialogCastingDirector:assign_character_for_segment(segment_index, line)
	
	
end