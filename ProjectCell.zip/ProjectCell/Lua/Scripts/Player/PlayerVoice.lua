PlayerVoice = PlayerVoice or blt_class()
PlayerVoice.DEBUG_ENABLED = false

function PlayerVoice:debug_print(txt)
	CellGlobal:log("PlayerVoice - " .. txt)
end

function PlayerVoice:init(unit)
	self._unit = unit
	self._setup = true
	self._sound = CellSoundPlayer:new(unit)
	self._start_dialog = 0
	self:RegisterVoice()
end

function PlayerVoice:RegisterVoice()
	if self._unit == nil then
		return
	end
	
	self._static_data = managers.criminals:character_static_data_by_unit(self._unit)
	self._character = managers.criminals:character_name_by_unit(self._unit)
	self._char_switch = self._static_data.voice	
	self:debug_print(string.format("Registered PlayerVoice for character : %s and it's char_switch : %s", self._character, self._char_switch))
end

function PlayerVoice:character()
	return self._character
end

function PlayerVoice:set_intensity_switch_value(switchVal)
	self._sound:SetSwitch(SD.SWITCHES.INTENSITY_STATE.GROUP, switchVal)
end

function PlayerVoice:SayLine(eventID, start_dialog, sync_callback)
	self._sound:SetSwitch(SD.SWITCHES.ROBBERS.GROUP, self._char_switch)
	self._sound:Post(eventID, callback(self,self,"VoiceCallBack"), sync_callback)
	self._start_dialog = start_dialog or 0
end


function PlayerVoice:DoSyncTriggerSound(data)
	self._sound:DoSyncTriggerSound(data)
end

function PlayerVoice:VoiceCallBack(reason)
	if reason == "finished"and self._start_dialog and self._start_dialog > 0 then
		self:debug_print("This is where we start our dialog with dialogID " .. self._start_dialog)
	end
	self._start_dialog = 0
end