PlayerDialogSegment = PlayerDialogSegment or class()
function PlayerDialogSegment:init(segment_data, order, segment_group)
	self._segment_group = segment_group
	self._line = segment_data.line
	self._actors = segment_data.actors
	self._dev_description = segment_data.DevDescription
	self._exit = segment_data.exit or 0
	self._early_exit = segment_data.early_exit or 0
	self._unskippable = segment_data.unskippable
	self._line_probability = segment_data.line_probability or 1
	self._order = order
	self._line_key = "PlayerDialogue_next_line_"..tostring(self._order)
end

function PlayerDialogSegment:tag()
	return nil
end

function PlayerDialogSegment:actor()
	return nil
end

function PlayerDialogSegment:unskippable()
	return self._unskippable
end




function PlayerDialogSegment:create_volunteer_entry_data(criminal)	
	local static_data = managers.criminals:character_static_data_by_unit(criminal)
	local character_name = managers.criminals:character_name_by_unit(criminal)	
	return {
		criminal = criminal,
		voice = static_data and static_data.voice or "none",
		name = character_name
	}
end

function PlayerDialogSegment:create_volunteer_entry_data_by_name(name)	
	local criminal = managers.criminals:character_unit_by_name(name)
	return criminal and self:create_volunteer_entry_data(criminal)
end



function PlayerDialogSegment:is_unit_part_of_entries(entries, criminal)	
	for index, entry in pairs(entries) do
		if entry and entry.criminal == criminal then
			return true
		end
	end
	return false
end





function PlayerDialogSegment:is_allowed(actors, char)
	for actor, allowed in pairs(self._actors) do
		local character = managers.player_dialog:get_character_by_actor(actors, actor)
		if character and char == character then
			return self._actors[actor]
		end
	end	
	return true
end

function PlayerDialogSegment:get_character_from_filter_list(actors)
	for actor, allowed in pairs(self._actors) do
		local character = managers.player_dialog:get_character_by_actor(actors, actor)
		if character then
			if self._actors[actor] then
				return character
			end
		end
	end	
	return nil
end

	
function PlayerDialogSegment:get_random_entry(params)	
	local new_actor_entries = {}
	for _, data in pairs(managers.groupai:state():all_char_criminals()) do
		if data and data.unit and alive(data.unit) then
			local entry = self:create_volunteer_entry_data(data.unit)
			local add = true
			
			if params.actors then
				if not self:is_allowed(params.actors, entry.name) then
					add = false
				end
			end
			
			if DeadLocke:isNotNilorEmpty(self._line) and not data.unit:sound():_sound_playback(self._line) then
				add = false
			end
			
			if not params.skip_talking_check and data.unit:sound():playback_playing() then
				add = false
			end

			if add then
				table.insert(new_actor_entries, entry)
			end
		end
	end
	return new_actor_entries[math.random(#new_actor_entries)]
end


function PlayerDialogSegment:get_all_criminals(params)	
	params = params or {}
	
	local entries = {}	
	
	for actor, allowed in pairs(self._actors) do
		if allowed then
			local character = managers.player_dialog:get_character_by_actor(params.actors, actor)
			if character then
				local unit = managers.criminals:character_unit_by_name(character)
				if unit and alive(unit) then
					table.insert(entries, self:create_volunteer_entry_data_by_name(character))
				end
			else
				table.insert(entries, self:get_random_entry(params))
			end
		end
	
	end
	

	
	return entries
end


function PlayerDialogSegment:get_entry(actors)
	local entries = self:get_all_criminals({actors = actors}) 
	if not next(entries) then
		return nil
	end
	
	return entries[math.random(#entries)]
end


function PlayerDialogSegment:destroy_segment()
	DeadLocke:stop_mod_cue(self._line_key, true)
end


function PlayerDialogSegment:next_line_line_delayed(duration)
	if duration ~= 0 then
		if self._exit ~= 0 then
			duration = duration + self._exit
		end
		if self._early_exit ~= 0 then
			duration = duration / self._early_exit
		end
	end

	self._segment_group:debug_hud_text("Delayed Next Line : "..tostring(duration))
	self._segment_group:next_line_delayed(duration)
end


function PlayerDialogSegment:tag_actor(list, character)
	if managers.player_dialog:get_actor_by_character(list, character) then
		return
	end
	
	for actr, allowed in pairs(self._actors) do
		if allowed then
			managers.player_dialog:tag_actor(list, character, actr)
		end
	end
end


function PlayerDialogSegment:play_line()
	local roll = math.rand(1)
	if self._line_probability ~= 1 then
		if self._line_probability < roll then
			DeadLocke:debug_log("segment random chance lost, ending dialogue...")
			self._segment_group:finished()
			return
		end
	end

	
	
	local chosen_entry = self:get_entry(managers.player_dialog:current_dialog().actors)
	if chosen_entry then
		self:tag_actor(managers.player_dialog:current_dialog().actors, chosen_entry.name)
		if DeadLocke:isNotNilorEmpty(self._line) then
			local playback_params = {
				cue_name = self._line_key, 
				sync = true
			}
			local saying = chosen_entry.criminal:sound():say_mod(self._line, playback_params)
			if saying and playback_params.line_duration then
				self:next_line_line_delayed(playback_params.line_duration)
				DeadLocke:debug_log("found an entry with line ".. tostring(self._line).." triggered by actor name " ..chosen_entry.name)
			else
				self._segment_group:play_next_segment()	
				DeadLocke:debug_log("An actor by the name of "..chosen_entry.name.. " has a line duration of 0 ...")
			end
		else
			DeadLocke:debug_log("An actor by the name of "..chosen_entry.name.. " will say nothing and be tagged for the next segment..")
			self._segment_group:play_next_segment()	
		end
		
	elseif not self:unskippable() then
		self._segment_group:play_next_segment()	
	else
		DeadLocke:debug_log("No entry with line ".. tostring(self._line))
		self._segment_group:finished()
	end
end