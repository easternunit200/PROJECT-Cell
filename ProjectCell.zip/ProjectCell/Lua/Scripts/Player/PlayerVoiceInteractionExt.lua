PlayerVoiceInteractionExt = PlayerVoiceInteractionExt or blt_class()

function PlayerVoiceInteractionExt:debug_print(txt)
	CellGlobal:log("PlayerVoiceInteractionExt - " .. txt)
end


function PlayerVoiceInteractionExt:init(unit)
	if unit == nil then
		self:debug_print("ERROR : unit has returned nil!!")
		return
	end
	
	self._character = managers.criminals:character_name_by_unit(unit) or managers.criminals:local_character_name()
	if self._character == nil then
		self:debug_print("ERROR : during intiation the character has returned nil!!")
		return
	end
	self._interaction_blocks = {}
	self:debug_print("Initiating extended interaction for character : " .. tostring(self._character))
	for _, block in pairs(managers.cell_data:wrapper("PlayerVoiceInteractionsDataBlock"):get_all_blocks()) do
		if block.characters and next(block.characters) and table.contains(block.characters, self._character) then
			if block.interaction_type then		
				if not self._interaction_blocks[block.interaction_type] then
					self._interaction_blocks[block.interaction_type] = block
					self:debug_print("Now adding interaction type " .. block.interaction_type .. " for character -> " .. self._character)
				else
					self:debug_print("Warning, interaction type " .. block.interaction_type .. " has occured more than once....")
				end				
			end			
		end
	end
end

function PlayerVoiceInteractionExt:get_modified_interaction(interaction_type)
	if interaction_type == nil then
		return nil
	end
	
	if not self._interaction_blocks  then
		self:debug_print("ERROR : No interaction blocks setup??!")
		return nil
	end
	
	local interaction_block = self._interaction_blocks[interaction_type]
	if not interaction_block then
		self:debug_print("ERROR : couldn't find an interaction block for " .. tostring(interaction_type))
		return nil
	end
	
	if interaction_block.target_priority_shout and interaction_block.target_priority_shout ~= "" then
		local prime_target = managers.cell_interaction:get_intimidation_data("prime_target")		
		if interaction_block.target_priority_shout ~= tweak_data.character[prime_target.unit:base()._tweak_table].priority_shout then
			return nil
		end
	end
	
	
	local weightHandler = WeightHandler:new()
	
	for index, data in pairs(interaction_block.lines) do
		weightHandler:add_value(data.line, data.weight)
	end
	
	return weightHandler:has_any() and weightHandler:get_best_value().value or nil
end 