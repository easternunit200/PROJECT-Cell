CellHooks = CellHooks or {}
CellHooks.IntroShowed = false

Hooks:Add("MenuManagerOnOpenMenu", "MenuManagerOnOpenMenu_Cell", function( menu_manager, menu, position )
	if menu == "menu_main" then		
		managers.cell_options:on_menu_entered()		
	end
end)

Hooks:Add('NetworkReceivedData', 'NetworkReceivedData_Cell', function(sender, messageType, data)
	if managers.cell_network then
		if messageType == managers.cell_network:network_id() then
			managers.cell_network:network_receive_data(sender, messageType, data)
		end
	end	
end)

Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_Cell", function( menu_manager )
	
	
	function MenuCallbackHandler:clbk_exit_project_cell_menu(item)
		if managers.cell_user and managers.cell_user:has_local_peer() then
			managers.cell_user:local_user():send_cell_values_to_peers()
		end		
		
		if managers.cell_music then
			managers.cell_music:on_stop_listening()
		end
		
		log("stop listening!!")
	end		
	
	function MenuCallbackHandler:callback_ghost_track_chooser(item)
		managers.menu:open_node("project_cell_ghost_tracks", {
			{
				back_callback = callback(MenuCallbackHandler, MenuCallbackHandler, "clbk_exit_project_cell_menu")
			}
		})
	end			
		
end )



Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_Cell", function( menu_manager, nodes )
	MenuHelper:NewMenu( "project_cell" )
	MenuHelper:NewMenu( "project_cell_ghost_tracks" )
end)

Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_Cell", function(menu_manager, nodes)	
	local menu_data = {}
	menu_data.back_callback = "clbk_exit_project_cell_menu"		
	nodes.project_cell = MenuHelper:BuildMenu( "project_cell",  menu_data)	
	MenuHelper:AddMenuItem( nodes.blt_options, "project_cell", "project_cell_title", "project_cell_desc")
    nodes.project_cell_ghost_tracks = MenuHelper:BuildMenu( "project_cell_ghost_tracks",  {})
end)
