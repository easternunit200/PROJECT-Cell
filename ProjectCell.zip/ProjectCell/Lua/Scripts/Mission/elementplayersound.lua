local ElementPlayerSay = blt_class(DeadLocke.MissionScriptElement)
DeadLocke.ElementPlayerSay = ElementPlayerSay

function ElementPlayerSay:init(...)
	DeadLocke.ElementPlayerSay.super.init(self, ...)
end
function ElementPlayerSay:client_on_executed(...)
	self:on_executed(...)
end

function ElementPlayerSay:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	local player = managers.player:player_unit()
	
	if not self._values.use_instigator then
		local params = {}
		params.position = self._values.position
		params.radius = self._values.radius ~= 0 and self._values.radius or nil
		DeadLocke:say(self._values.sound, self._values.deadlocke_value, self._values.use_ai, true, params)
	elseif player == instigator then
		if not self._values.deadlocke_value or DeadLocke:get_value(self._values.deadlocke_value) then
			if player and alive(player) then
				player:sound():say(self._values.sound, true, true)
			end
		end
	end

	DeadLocke.ElementPlayerSay.super.on_executed(self, instigator)
end
