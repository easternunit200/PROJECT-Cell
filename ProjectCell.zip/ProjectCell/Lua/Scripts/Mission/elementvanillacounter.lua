DeadLocke.ElementVanillaCounter = DeadLocke.ElementVanillaCounter or blt_class(DeadLocke.MissionScriptElement)
local ElementVanillaCounter = DeadLocke.ElementVanillaCounter

function ElementVanillaCounter:init(...)
	DeadLocke.ElementVanillaCounter.super.init(self,...)
end

function ElementVanillaCounter:_check_type(element)
	return DeadLocke.ElementCounterFilter._check_type(self, element)
end

function ElementVanillaCounter:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	if not self._values.element_id then
		return
	end
	
	local element = managers.mission:get_element_by_id(self._values.element_id)
	
	if not element then
		return
	end
	
	if not element._values.counter_target then
		return
	end
	
	if not self:_check_type(element) then
		return	
	end
	
	DeadLocke.ElementVanillaCounter.super.on_executed(self, instigator)
end 