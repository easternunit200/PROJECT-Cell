DeadLocke.MissionManager = DeadLocke.MissionManager or blt_class(CallbackHandler)
local MissionManager = DeadLocke.MissionManager

function MissionManager:init()
	DeadLocke.MissionManager.super.init(self)

	self._runned_unit_sequences_callbacks = {}
	self._scripts = {}
	self._active_scripts = {}
	self._area_instigator_categories = {}

	self:add_area_instigator_categories("none")
	self:set_default_area_instigator("none")

	self._global_event_listener = rawget(_G, "EventListenerHolder"):new()
	self._global_event_list = {}
end

function MissionManager:post_init()
	self._workspace = managers.gui_data:create_saferect_workspace()

	managers.gui_data:layout_corner_saferect_workspace(self._workspace)
	self._workspace:set_timer(TimerManager:main())

	self._fading_debug_output = self._workspace:panel():gui(Idstring("core/guis/core_fading_debug_output"))

	self._fading_debug_output:set_leftbottom(0, self._workspace:height() / 3)
	self._fading_debug_output:script().configure({
		font_size = 18,
		max_rows = 20
	})

	self._persistent_debug_output = self._workspace:panel():gui(Idstring("core/guis/core_persistent_debug_output"))

	self._persistent_debug_output:set_righttop(self._workspace:width(), 0)
	self:set_persistent_debug_enabled(false)
	self:set_fading_debug_enabled(true)
	managers.viewport:add_resolution_changed_func(callback(self, self, "_resolution_changed"))
end
function MissionManager:_resolution_changed()
	--managers.gui_data:layout_corner_saferect_workspace(self._workspace)
end

local allowed_missionscripts = {
	"mus",
	"branchbank",
	"firestarter_3",
	"firestarter_2",
	"jewelry_store",
	"dah",
	"ukrainian_job",
	"pal",
	"man",
	"crojob2",
	"arena",
	"red2",
	"kenaz",
	"vit",
	"cage",
	"roberts",
	"sah",
	"hox_3",
	"flat",
	"nmh",
	"watchdogs_1",
	"big",
	"welcome_to_the_jungle_1",
	"framing_frame_1",
	"framing_frame_2",
	"framing_frame_3",
	"gallery",
	"glace"
}


function MissionManager:parse()
	if self._loaded then
		return
	end
	local level_id = Global and Global.level_data and Global.level_data.level_id
	level_id = DeadLocke:clean_level_suffixes(level_id)
	if not table.contains(allowed_missionscripts, level_id) then
		DeadLocke:debug_log("This level_id "..level_id.." is not allowed yet!!")
		return
	end
	local file_data = DeadLocke:load_json_from_deadlocke_directory("assets/levels/"..level_id..".json")
	if not file_data then
		error("[DeadLocke.MissionScriptElement:init] could not load level name "..tostring(level_id).. " no such level!")
		return false
	end
	--local elements = file_path.default.elements
	
	self:_load_mission_file(file_data)
	self:_activate_mission()
	self._loaded = true
	self:post_init()
	return true
end

function MissionManager:_serialize_to_script(type, name)
	if Application:editor() then
		return PackageManager:editor_load_script_data(type:id(), name:id())
	else
		if not PackageManager:has(type:id(), name:id()) then
			Application:throw_exception("Script data file " .. name .. " of type " .. type .. " has not been loaded. Could be that old mission format is being loaded. Try resaving the level.")
		end

		return PackageManager:script_data(type:id(), name:id())
	end
end


function MissionManager:_load_mission_file(scripts)
	scripts._meta = nil

	for name, data in pairs(scripts) do
		data.name = name

		self:_add_script(data)
	end
end


function MissionManager:_add_script(data)
	self._scripts[data.name] = DeadLocke.MissionScript:new(data)
end

function MissionManager:scripts()
	return self._scripts
end

function MissionManager:script(name)
	return self._scripts[name]
end

function MissionManager:_activate_mission(name)
	DeadLocke:debug_log("gaspode MissionManager:_activate_mission" .. tostring(name))

	if name then
		if self:script(name) then
			self:activate_script(name)
		else
			DeadLocke:debug_log("There was no mission named " .. name .. " availible to activate!")
		end
	else
		for _, script in pairs(self._scripts) do
			if script:activate_on_parsed() then
				self:activate_script(script:name())
			end
		end
	end
end

function MissionManager:activate_script(name, ...)
	DeadLocke:debug_log("gaspode", "MissionManager:activate_script", name)

	if not self._scripts[name] then
		if Global.running_simulation then
			DeadLocke:debug_log("Can't activate mission script " .. name .. ". It doesn't exist.")

			return
		else
			DeadLocke:debug_log("Can't activate mission script " .. name .. ". It doesn't exist.")
		end
	end

	self._scripts[name]:activate(...)
end

function MissionManager:update(t, dt)
	for _, script in pairs(self._scripts) do
		script:update(t, dt)
	end
end

function MissionManager:stop_simulation(...)
	self:pre_destroy()

	for _, script in pairs(self._scripts) do
		script:stop_simulation(...)
	end

	self._scripts = {}
	self._runned_unit_sequences_callbacks = {}
	self._global_event_listener = rawget(_G, "EventListenerHolder"):new()
end

function MissionManager:on_simulation_started()
	self._pre_destroyed = nil
end

function MissionManager:add_runned_unit_sequence_trigger(id, sequence, callback)
	if self._runned_unit_sequences_callbacks[id] then
		if self._runned_unit_sequences_callbacks[id][sequence] then
			table.insert(self._runned_unit_sequences_callbacks[id][sequence], callback)
		else
			self._runned_unit_sequences_callbacks[id][sequence] = {
				callback
			}
		end
	else
		local t = {
			[sequence] = {
				callback
			}
		}
		self._runned_unit_sequences_callbacks[id] = t
	end
end

function MissionManager:runned_unit_sequence(unit, sequence, params)
	if self._pre_destroyed then
		return
	end

	if alive(unit) and unit:unit_data() then
		local id = unit:unit_data().unit_id
		id = id ~= 0 and id or unit:editor_id()

		if self._runned_unit_sequences_callbacks[id] and self._runned_unit_sequences_callbacks[id][sequence] then
			for _, call in ipairs(self._runned_unit_sequences_callbacks[id][sequence]) do
				call(params and params.unit)
			end
		end
	end
end

function MissionManager:add_area_instigator_categories(category)
	table.insert(self._area_instigator_categories, category)
end

function MissionManager:area_instigator_categories()
	return self._area_instigator_categories
end

function MissionManager:set_default_area_instigator(default)
	self._default_area_instigator = default
end

function MissionManager:default_area_instigator()
	return self._default_area_instigator
end

function MissionManager:default_instigator()
	return nil
end

function MissionManager:persistent_debug_enabled()
	return self._persistent_debug_enabled
end

function MissionManager:set_persistent_debug_enabled(enabled)
	self._persistent_debug_enabled = enabled

	if enabled then
		self._persistent_debug_output:show()
	else
		self._persistent_debug_output:hide()
	end
end

function MissionManager:add_persistent_debug_output(debug, color)
	if not self._persistent_debug_enabled then
		return
	end

	self._persistent_debug_output:script().log(debug, color)
end

function MissionManager:set_fading_debug_enabled(enabled)
	self._fading_debug_enabled = enabled

	if enabled then
		self._fading_debug_output:show()
	else
		self._fading_debug_output:hide()
	end
end

function MissionManager:add_fading_debug_output(debug, color, as_subtitle)
	if not DeadLocke.debug then
		return
	end

	if not self._fading_debug_enabled then
		return
	end

	if as_subtitle then
		self:_show_debug_subtitle(debug, color)
	else
		local stuff = {
			" -",
			" \\",
			" |",
			" /"
		}
		self._fade_index = (self._fade_index or 0) + 1
		self._fade_index = self._fade_index > #stuff and self._fade_index and 1 or self._fade_index

		self._fading_debug_output:script().log(stuff[self._fade_index] .. " " .. debug, color, nil)
	end
end

function MissionManager:_show_debug_subtitle(debug, color)
	if not self._debug_subtitle_text then
		slot3 = self._workspace:panel():text({
			font_size = 20,
			wrap = true,
			word_wrap = true,
			align = "center",
			font = "core/fonts/diesel",
			halign = "center",
			valign = "center",
			text = debug,
			color = color or Color.white
		})
	end

	self._debug_subtitle_text = slot3

	self._debug_subtitle_text:set_w(self._workspace:panel():w() / 2)
	self._debug_subtitle_text:set_text(debug)

	local subtitle_time = math.max(4, utf8.len(debug) * 0.04)
	local _, _, w, h = self._debug_subtitle_text:text_rect()

	self._debug_subtitle_text:set_h(h)
	self._debug_subtitle_text:set_center_x(self._workspace:panel():w() / 2)
	self._debug_subtitle_text:set_top(self._workspace:panel():h() / 1.4)
	self._debug_subtitle_text:set_color(color or Color.white)
	self._debug_subtitle_text:set_alpha(1)
	self._debug_subtitle_text:stop()
	self._debug_subtitle_text:animate(function (o)
		_G.wait(subtitle_time)
		self._debug_subtitle_text:set_alpha(0)
	end)
end

function MissionManager:get_element_by_id(id)
	for name, script in pairs(self._scripts) do
		if script:element(id) then
			return script:element(id)
		end
	end
end

function MissionManager:add_deadlocke_event_listener(key, events, clbk)
	self._global_event_listener:add(key, events, clbk)
end

function MissionManager:remove_deadlocke_event_listener(key)
	self._global_event_listener:remove(key)
end

function MissionManager:call_deadlocke_event(event, ...)
	self._global_event_listener:call(event, ...)
end

function MissionManager:set_deadlocke_event_list(list)
	self._global_event_list = list
end

function MissionManager:get_deadlocke_event_list()
	return self._global_event_list
end

function MissionManager:save(data)
	local state = {}

	for _, script in pairs(self._scripts) do
		script:save(state)
	end

	data.MissionManager = state
end

function MissionManager:load(data)
	local state = data.MissionManager

	for _, script in pairs(self._scripts) do
		script:load(state)
	end
end

function MissionManager:pre_destroy()
	self._pre_destroyed = true

	for _, script in pairs(self._scripts) do
		script:pre_destroy()
	end
end

function MissionManager:destroy()
	for _, script in pairs(self._scripts) do
		script:destroy()
	end
end

local MissionScript = blt_class(CallbackHandler)
DeadLocke.MissionScript = MissionScript

function MissionScript.import(module_name)
end

function MissionScript:init(data)
	DeadLocke.MissionScript.super.init(self)

	self._elements = {}
	self._element_groups = {}
	self._name = data.name
	self._activate_on_parsed = data.activate_on_parsed
	self:_create_elements(data.elements)
	if data.instances then
		for _, instance_name in ipairs(data.instances) do
			local instance_data = managers.world_instance:get_instance_data_by_name(instance_name)
			local prepare_mission_data = managers.world_instance:prepare_mission_data_by_name(instance_name)

			if not instance_data.mission_placed then
				self:create_instance_elements(prepare_mission_data)
			else
				self:_preload_instance_class_elements(prepare_mission_data)
			end
		end
	end

	self._updators = {}
	self._save_states = {}

	self:_on_created(self._elements)
end

function MissionScript:external_create_instance_elements(prepare_mission_data)
	local new_elements = self:create_instance_elements(prepare_mission_data)

	self:_on_created(new_elements)

	if self._active then
		self:_on_script_activated(new_elements)
	end
end

function MissionScript:create_instance_elements(prepare_mission_data)
	local new_elements = {}

	for _, instance_mission_data in pairs(prepare_mission_data) do
		new_elements = self:_create_elements(instance_mission_data.elements)
	end

	return new_elements
end

function MissionScript:_preload_instance_class_elements(prepare_mission_data)
	for _, instance_mission_data in pairs(prepare_mission_data) do
		for _, element in ipairs(instance_mission_data.elements) do
			self:_element_class(element._class, element.class)
		end
	end
end

function MissionScript:_create_elements(elements)
	local new_elements = {}
	
	if not elements then
		log("There is no fucking elements in this fucking level_id "..tostring(self._level_id))
		return
	end
	for _, element in pairs(elements) do
		local class = element._class		
		local new_element = self:_element_class(class):new(self, element)
		
		self._elements[element.id] = new_element
		new_elements[element.id] = new_element
		self._element_groups[class] = self._element_groups[class] or {}

		table.insert(self._element_groups[class], new_element)
	end

	return new_elements
end

function MissionScript:activate_on_parsed()
	return self._activate_on_parsed
end

function MissionScript:_on_created(elements)
	for _, element in pairs(elements) do
		if element.on_created then
			element:on_created()
		end
	end
end

function MissionScript:_element_class(class_name)
	local element_class = rawget(DeadLocke, class_name)
	if not element_class then
		element_class = DeadLocke.MissionScriptElement

		log("[MissionScript] SCRIPT ERROR: Didn't find class "..tostring(class_name))
	end

	return element_class
end

function MissionScript:activate(...)
	self._active = true
	self:_on_script_activated(clone(self._elements), ...)
end

function MissionScript:_on_script_activated(elements, ...)
	for _, element in pairs(elements) do
		element:on_script_activated()
	end

	for _, element in pairs(elements) do
		if element:value("execute_on_startup") then
			element:on_executed(...)
		end
	end
end

function MissionScript:add_updator(id, updator)
	self._updators[id] = updator
end

function MissionScript:remove_updator(id)
	self._updators[id] = nil
end

function MissionScript:update(t, dt)
	DeadLocke.MissionScript.super.update(self, dt)

	for _, updator in pairs(self._updators) do
		updator(t, dt)
	end
end

function MissionScript:_debug_draw(t, dt)
	local brush = Draw:brush(Color.red)
	local name_brush = Draw:brush(Color.red)

	name_brush:set_font(Idstring("fonts/font_medium"), 16)
	name_brush:set_render_template(Idstring("OverlayVertexColorTextured"))

	for _, element in pairs(self._elements) do
		brush:set_color(element:enabled() and Color.green or Color.red)
		name_brush:set_color(element:enabled() and Color.green or Color.red)

		if element:value("position") then
			brush:sphere(element:value("position"), 5)

			if managers.viewport:get_current_camera() then
				local cam_up = managers.viewport:get_current_camera():rotation():z()
				local cam_right = managers.viewport:get_current_camera():rotation():x()

				name_brush:center_text(element:value("position") + Vector3(0, 0, 30), utf8.from_latin1(element:editor_name()), cam_right, -cam_up)
			end
		end

		if element:value("rotation") then
			local rotation = CoreClass.type_name(element:value("rotation")) == "Rotation" and element:value("rotation") or Rotation(element:value("rotation"), 0, 0)

			brush:cylinder(element:value("position"), element:value("position") + rotation:y() * 50, 2)
			brush:cylinder(element:value("position"), element:value("position") + rotation:z() * 25, 1)
		end

		element:debug_draw(t, dt)
	end
end

function MissionScript:name()
	return self._name
end

function MissionScript:element_groups()
	return self._element_groups
end

function MissionScript:element_group(name)
	return self._element_groups[name]
end

function MissionScript:elements()
	return self._elements
end

function MissionScript:element(id)
	return self._elements[id]
end

function MissionScript:debug_output(debug, color)
	managers.mission:add_persistent_debug_output(Application:date("%X") .. ": " .. debug, color)
	DeadLocke:debug_log("editor", debug)
end

function MissionScript:is_debug()
	return true
end

function MissionScript:add_save_state_cb(id)
	self._save_states[id] = true
end

function MissionScript:remove_save_state_cb(id)
	self._save_states[id] = nil
end

function MissionScript:save(data)
	local state = {}

	for id, _ in pairs(self._save_states) do
		state[id] = {}

		self._elements[id]:save(state[id])
	end

	data[self._name] = state
end

function MissionScript:load(data)
	local state = data[self._name]

	if self._element_groups.ElementInstancePoint then
		for _, element in ipairs(self._element_groups.ElementInstancePoint) do
			if state[element:id()] then
				self._elements[element:id()]:load(state[element:id()])

				state[element:id()] = nil
			end
		end
	end

	for id, mission_state in pairs(state) do
		self._elements[id]:load(mission_state)
	end
end

function MissionScript:stop_simulation(...)
	for _, element in pairs(self._elements) do
		element:stop_simulation(...)
	end

	DeadLocke.MissionScript.super.clear(self)
end

function MissionScript:pre_destroy(...)
	for _, element in pairs(self._elements) do
		element:pre_destroy(...)
	end

	DeadLocke.MissionScript.super.clear(self)
end

function MissionScript:destroy(...)
	for _, element in pairs(self._elements) do
		element:destroy(...)
	end

	DeadLocke.MissionScript.super.clear(self)
end
