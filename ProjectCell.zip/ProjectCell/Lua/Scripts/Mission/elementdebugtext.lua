DeadLocke.ElementDebugText = DeadLocke.ElementDebugText or blt_class(DeadLocke.MissionScriptElement)

local ElementDebugText = DeadLocke.ElementDebugText

function ElementDebugText:init(...)
	DeadLocke.ElementDebugText.super.init(self,...)
end

function ElementDebugText:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	if self._values.debug_text then
		self._values.debug_string = self._values.debug_text
	end
	
	
	DeadLocke.ElementDebugText.init(self, instigator)
end