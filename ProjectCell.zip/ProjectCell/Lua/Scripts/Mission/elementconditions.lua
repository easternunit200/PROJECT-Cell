DeadLocke.ElementConditions = DeadLocke.ElementConditions or blt_class(DeadLocke.MissionScriptElement)

local ElementConditions = DeadLocke.ElementConditions

function ElementConditions:init(...)
	DeadLocke.ElementConditions.super.init(self, ...)
end

function ElementConditions:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	if self._values.only_stealth and not managers.groupai:state():whisper_mode() then
		return
	end
	
	if self._values.from_the_start and not DeadLocke.started_from_the_beginning then
		return
	end
	
	DeadLocke.ElementConditions.super.on_executed(self, instigator)
end