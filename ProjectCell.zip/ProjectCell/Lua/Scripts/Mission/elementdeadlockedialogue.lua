DeadLocke.ElementDeadLockeDialogue = DeadLocke.ElementDeadLockeDialogue or blt_class(DeadLocke.MissionScriptElement)
local ElementDeadLockeDialogue = DeadLocke.ElementDeadLockeDialogue

function ElementDeadLockeDialogue:init(...)
	DeadLocke.ElementDeadLockeDialogue.super.init(self, ...)
end


function ElementDeadLockeDialogue:client_on_executed(...)
	self:on_executed(...)
end


function ElementDeadLockeDialogue:_check_for_ssuffix(instigator)
	return self._values.dialogue	
end

function ElementDeadLockeDialogue:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	DeadLocke.ElementDeadLockeDialogue.super.on_executed(self, instigator, nil, self._values.execute_on_executed_when_done)
end


function ElementDeadLockeDialogue:_done_callback(instigator, reason)
	DeadLocke.ElementDeadLockeDialogue.super._trigger_execute_on_executed(self, instigator)
end


function ElementDeadLockeDialogue:_can_play()
	return true
end