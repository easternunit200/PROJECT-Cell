DeadLocke.ElementAddEventToUnit = DeadLocke.ElementAddEventToUnit or blt_class(DeadLocke.MissionScriptElement)
local ElementAddEventToUnit = DeadLocke.ElementAddEventToUnit


function ElementAddEventToUnit:on_script_activated()

	
	if self:value("elements") then
		for _, id in pairs(self:value("elements")) do
			local element = managers.mission:get_element_by_id(id)
			if element then
				if element.add_event_callback then
					element:add_event_callback(self:value("event_name"), callback(self, self, "on_executed"))
				end
			end
		end	
	end
	
end


function ElementAddEventToUnit:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	
	DeadLocke.ElementAddEventToUnit.super.on_executed(self, instigator)
end