local ElementPlayerState = blt_class(DeadLocke.MissionScriptElement)
DeadLocke.ElementPlayerState = ElementPlayerState

function ElementPlayerState:init(...)
	DeadLocke.ElementPlayerState.super.init(self, ...)
end
function ElementPlayerState:client_on_executed(...)
	self:on_executed(...)
end

function ElementPlayerState:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	local state = self:value("state")
	local player_unit = managers.player:player_unit()
	local requires_alive_player = false

	if self:value("state") == "electrocution" then
		state = "tased"
		requires_alive_player = true

		if alive(player_unit) then
			player_unit:movement():on_non_lethal_electrocution()
		end
	end

	if (not self:value("use_instigator") or instigator == player_unit) and (not requires_alive_player or alive(player_unit)) then
		if self:value("state") ~= "none" then
			managers.player:set_player_state(state)
		else
			DeadLocke:debug_log("Cant change to player state " .. state .. " in element " .. self._editor_name .. ".")
		end
	end

	DeadLocke.ElementPlayerState.super.on_executed(self, self._unit or instigator)
end

DeadLocke.ElementPlayerStateTrigger = DeadLocke.ElementPlayerStateTrigger or blt_class(DeadLocke.MissionScriptElement)
local ElementPlayerStateTrigger = DeadLocke.ElementPlayerStateTrigger

function ElementPlayerStateTrigger:init(...)
	DeadLocke.ElementPlayerStateTrigger.super.init(self, ...)
end

function ElementPlayerStateTrigger:on_script_activated()

	local clbk = callback(self, self, Network:is_client() and "send_to_host" or "on_executed")
	
	managers.player:add_listener(self._id, {self:value("state")}, clbk)
end

function ElementPlayerStateTrigger:send_to_host(instigator)
	if instigator then
		managers.network:session():send_to_host("to_server_mission_element_trigger", self._id, instigator)
	end
end

function ElementPlayerStateTrigger:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	DeadLocke.ElementPlayerStateTrigger.super.on_executed(self, self._unit or instigator)
end
