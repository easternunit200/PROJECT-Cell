DeadLocke.ElementPlayerDialogue = DeadLocke.ElementPlayerDialogue or blt_class(DeadLocke.MissionScriptElement)
local ElementPlayerDialogue = DeadLocke.ElementPlayerDialogue

-- Lines: 33 to 35
function ElementPlayerDialogue:init(...)
	DeadLocke.ElementPlayerDialogue.super.init(self, ...)
end


function ElementPlayerDialogue:client_on_executed(...)
	self:on_executed(...)
end


function ElementPlayerDialogue:_check_for_ssuffix(instigator)
	local dialogue = self._values.dialogue			
	if self._values.use_instigator and instigator then
		local static_data = managers.criminals:character_static_data_by_unit(instigator)
		if static_data and static_data.ssuffix then
			dialogue = dialogue:gsub("{ssuffix}", static_data.ssuffix)
		end
	end
	return dialogue
end


function ElementPlayerDialogue:_parameters(instigator, params)
	if self._values.force_quit_current then
		params.force_quit_current = true
	end
	
	if self._values.use_instigator then					
		local instigator_character = managers.criminals:character_name_by_unit(instigator)
		if instigator_character then
			params.actors = {
				A = instigator_character
			}
		end
	elseif self._values.pos_based and self._values.position then 
		local criminal = DeadLocke:closest_criminal_to_pos(DeadLocke:String_to_Vector(self._values.position), {})
		if criminal then
			local character = managers.criminals:character_name_by_unit(criminal)
			if character then
				params.actors = {
					A = character
				}
			end
		end
	end
	return params
end

function ElementPlayerDialogue:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if not self._values.play_on_player_instigator_only or instigator == managers.player:player_unit() then
		local done_cbk = self._values.execute_on_executed_when_done and callback(self, self, "_done_callback", instigator) or nil

		if self._values.dialogue and type(self._values.dialogue) == "number" and self._values.dialogue ~= 0 then
			
			if self:_can_play() then
				local params = {}	
				params.done_cbk = done_cbk				
				
				managers.player_dialog:queue_dialog(self._values.dialogue, self:_parameters(instigator, params))
			else
			
				debug_print("[ElementPlayerDialogue] Skipping muted dialogue: ", self._values.dialogue)
				if done_cbk then
					done_cbk()
				end
			end
			
		end
	end

	DeadLocke.ElementPlayerDialogue.super.on_executed(self, instigator, nil, self._values.execute_on_executed_when_done)
end


function ElementPlayerDialogue:_done_callback(instigator, reason)
	DeadLocke.ElementPlayerDialogue.super._trigger_execute_on_executed(self, instigator)
end

function ElementPlayerDialogue:_can_play()
	if self._values.only_deadlocke_host then
		return DeadLocke:incharge()
	end
	return true
end