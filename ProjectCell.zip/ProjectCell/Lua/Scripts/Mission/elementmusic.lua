DeadLocke.ElementMusic = DeadLocke.ElementMusic or blt_class(DeadLocke.MissionScriptElement)

local ElementMusic = DeadLocke.ElementMusic

function ElementMusic:init(...)
	DeadLocke.ElementMusic.super.init(self,...)
end


function ElementMusic:_can_play_music_event()	
	local block = DeadLocke:DataBlock()
	if not block or not block.allowDynamicMusic then
		return false
	end
	
	if self._values.must_be_played then
		return true
	end
	
	if self._values.skip_music_event_toggle_check or DeadLocke._data.music_event_toggle then	
		local current_track = Global.music_manager.current_track
		
		if not self._values.skip_current_track_check and not DeadLocke:is_track_allowed(current_track) then
			return false
		end
		
		current_track = DeadLocke:override_track(current_track)
		
		local track_list = self._values.track_list or {}
		
		if not next(track_list) then
			return true
		end	
		
		if self._values.excluding then
			if table.contains(track_list, current_track) then
				return false
			end	
			return true
		else			
			if table.contains(track_list, current_track) then
				return true
			end
		end
	end

	return false
end

function ElementMusic:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if not self._values.use_instigator or instigator == managers.player:player_unit() then
	
		if self._values.music_event then
		
			if self:_can_play_music_event() then
				managers.music:post_event(self._values.music_event)
			end
			
		else
			DeadLocke:debug_log("Cant play music event nil [" .. self._editor_name .. "]")
		end
		
	end
	
	DeadLocke.ElementMusic.super.on_executed(self, instigator)
end

DeadLocke.ElementMusicCheck = DeadLocke.ElementMusicCheck or blt_class(DeadLocke.ElementMusic)

local ElementMusicCheck = DeadLocke.ElementMusicCheck

function ElementMusicCheck:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	
	if not self:_can_play_music_event() then
		return
	end
	
	
	DeadLocke.ElementMusicCheck.super.on_executed(self, instigator)
end


DeadLocke.ElementStealthMusic = DeadLocke.ElementStealthMusic or blt_class(DeadLocke.ElementMusic)

local ElementStealthMusic = DeadLocke.ElementStealthMusic

function ElementStealthMusic:_can_play_music_event()
	if managers.groupai:state():whisper_mode() and DeadLocke.allow_stealth_music then
		if DeadLocke:local_user():has_started_from_beginning() then
			return true
		end
	end
	
	return false
end
