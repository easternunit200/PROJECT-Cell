DeadLocke.ElementChangeAssaultDialogue = DeadLocke.ElementChangeAssaultDialogue or blt_class(DeadLocke.MissionScriptElement)

local ElementChangeAssaultDialogue = DeadLocke.ElementChangeAssaultDialogue

function ElementChangeAssaultDialogue:init(...)
	ElementChangeAssaultDialogue.super.init(self, ...)
end

function ElementChangeAssaultDialogue:client_on_executed(...)
	self:on_executed(...)
end

function ElementChangeAssaultDialogue:on_executed(...)
	if not self._values.enabled then
		return
	end
	
	managers.player_dialog:handler("assault"):force_level_change(self._values.name, self._values.level)
	
	ElementChangeAssaultDialogue.super.on_executed(self, ...)
end