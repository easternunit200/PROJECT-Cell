DeadLocke.ElementBeginSupense = DeadLocke.ElementBeginSupense or blt_class(DeadLocke.MissionScriptElement)
local ElementBeginSupense = DeadLocke.ElementBeginSupense

function ElementBeginSupense:init(...)
	DeadLocke.ElementBeginSupense.super.init(self,...)
end


function ElementBeginSupense:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	DeadLocke:set_suspense_beginning_phase(self._values.switch)
	
	DeadLocke.MissionScriptElement.on_executed(self, instigator)
end

