DeadLocke.ElementGlobalEventTrigger = DeadLocke.ElementGlobalEventTrigger or blt_class(DeadLocke.MissionScriptElement)
local ElementGlobalEventTrigger = DeadLocke.ElementGlobalEventTrigger

function ElementGlobalEventTrigger:init(...)
	DeadLocke.ElementGlobalEventTrigger.super.init(self, ...)
end

function ElementGlobalEventTrigger:on_script_activated()
	managers.mission:add_global_event_listener(self._id, {self._values.global_event}, callback(self, self, "on_executed"))	
end


function ElementGlobalEventTrigger:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	DeadLocke.ElementGlobalEventTrigger.super.on_executed(self, instigator)
end

