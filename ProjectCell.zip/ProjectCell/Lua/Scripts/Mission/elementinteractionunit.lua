DeadLocke.ElementInteractionUnitExt = DeadLocke.ElementInteractionUnitExt or blt_class(DeadLocke.ElementInteractionExt)

local ElementInteractionUnitExt = DeadLocke.ElementInteractionUnitExt

function ElementInteractionUnitExt:on_script_activated()
	if self._values.enabled then
		if self._values.unit_ids then
			for _, id in pairs(self._values.unit_ids) do
				local unit = managers.worlddefinition:get_unit(id)
				if unit and alive(unit) then
					if unit.interaction then
						if unit:interaction() then
							if unit:interaction().set_deadlocke_mission_element then
								unit:interaction():set_deadlocke_mission_element(self)
								table.insert(self._units, unit)
							end
						end
					end
				end
			end
		end
	end
end