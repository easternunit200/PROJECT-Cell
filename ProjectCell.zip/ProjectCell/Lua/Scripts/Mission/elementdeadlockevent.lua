DeadLocke.ElementDeadLockeEvent = DeadLocke.ElementDeadLockeEvent or blt_class(DeadLocke.MissionScriptElement)

local ElementDeadLockeEvent = DeadLocke.ElementDeadLockeEvent

function ElementDeadLockeEvent:init(...)
	DeadLocke.ElementDeadLockeEvent.super.init(self, ...)
end

function ElementDeadLockeEvent:on_script_activated()

	local ckb = callback(self, self, "on_executed")
	
	DeadLocke.DeadLockeMissionManager:add_deadlocke_event_listener(self._id, {self._values.deadlocke_event}, ckb)	
end

function ElementDeadLockeEvent:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	

	DeadLocke.ElementDeadLockeEvent.super.on_executed(self, instigator)
end