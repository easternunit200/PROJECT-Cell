DeadLocke.ElementToggle = DeadLocke.ElementToggle or blt_class(DeadLocke.MissionScriptElement)

local ElementToggle = DeadLocke.ElementToggle

function ElementToggle:init(...)
	DeadLocke.ElementToggle.super.init(self,...)
end
function ElementToggle:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	for _, id in ipairs(self._values.elements) do
		local element = self._values.vanilla and managers.mission:get_element_by_id(id) or self:get_mission_element(id)
		if element then
			if self._values.toggle == "on" then
				element:set_enabled(true)
			elseif self._values.toggle == "off" then
				element:set_enabled(false)
			else
				element:set_enabled(not element:value("enabled"))
			end
		end
	end
	DeadLocke.ElementToggle.super.on_executed(self, instigator)
end