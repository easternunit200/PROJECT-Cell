DeadLocke.ElementInteractionExt = DeadLocke.ElementInteractionExt or blt_class(DeadLocke.MissionScriptElement)

local ElementInteractionExt = DeadLocke.ElementInteractionExt

function ElementInteractionExt:init(...)
	DeadLocke.ElementInteractionExt.super.init(self, ...)
	self._units = {}
end

local function is_valid_interaction(element)
	local values = element._values
	if values.trigger_list then
		for _, trigger in ipairs(values.trigger_list) do
			local notif = trigger.notify_unit_sequence
			if notif == 'enable_interaction' or notif == 'interact_enabled' or notif == 'state_interaction_enabled' then
				return true
			end
		end
	end
	return false
end




function ElementInteractionExt:on_script_activated()
	if self._values.enabled then
		if self._values.elements then
			for _, id in pairs(self._values.elements) do
				local element = managers.mission:get_element_by_id(id)
				if element and element._unit and alive(element._unit) then
					if is_valid_interaction(element) then
						if element._unit().interaction then
							if element._unit():interaction() then
								if element._unit():interaction().set_deadlocke_mission_element then
									element._unit():interaction():set_deadlocke_mission_element(self)
									table.insert(self._units, element._unit)
								end
							end
						end
					end
				end
			end
		end
	end
end


function ElementInteractionExt:on_executed(instigator, ...)
	if not self._values.enabled then
		return
	end

	DeadLocke.ElementInteractionExt.super.on_executed(self, instigator, ...)
end

function ElementInteractionExt:on_interacted(instigator)
	self:on_executed(instigator, "interacted")
end

function ElementInteractionExt:on_interact_start(instigator)
	self:on_executed(instigator, "start")
end

function ElementInteractionExt:on_interact_interupt(instigator)
	self:on_executed(instigator, "interupt")
end
