DeadLocke.DramaStateForcer = DeadLocke.DramaStateForcer or blt_class(DeadLocke.MissionScriptElement)

local DramaStateForcer = DeadLocke.DramaStateForcer

function DramaStateForcer:init(...)
	DeadLocke.DramaStateForcer.super.init(self,...)
end


function DramaStateForcer:on_executed(...)
	if not self._values.enabled then
		return
	end

	
	DramaManager:force_drama_state(self._values.state)
	
	DeadLocke.DramaStateForcer.super.on_executed(self, ...)
end



