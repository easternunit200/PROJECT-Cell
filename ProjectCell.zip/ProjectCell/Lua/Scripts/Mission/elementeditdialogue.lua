DeadLocke.ElementEditDialogue = DeadLocke.ElementEditDialogue or blt_class(DeadLocke.MissionScriptElement)

local ElementEditDialogue = DeadLocke.ElementEditDialogue

function ElementEditDialogue:init(...)
	DeadLocke.ElementEditDialogue.super.init(self,...)
end


function ElementEditDialogue:on_executed(...)
	if not self._values.enabled then
		return
	end

	if self._values.clean_dialogue_editors then
		local all_editor_names = DeadLocke.DialogManager:editor_names_list()		
		for i, name in pairs(all_editor_names) do
			DeadLocke:exclude_segment_group_editor_name(name)
		end
	end

	if self._values.add_editor_names and next(self._values.add_editor_names) then
		local editor_names = self._values.add_editor_names	
		for i, name in pairs(editor_names) do
			DeadLocke:add_segment_group_editor_name(name)
		end
	end
	
	DeadLocke.ElementEditDialogue.super.on_executed(self, ...)
end



