dofile(ModPath.. "Lua/Scripts/CellMission/cell_elementbasenonsync.lua")
dofile(ModPath.. "Lua/Scripts/CellMission/cell_elementsuspenser.lua")
dofile(ModPath.. "Lua/Scripts/CellMission/cell_elementfakeassaultsetup.lua")

CellMissionManager = CellMissionManager or blt_class(CellManagerBase)

function CellMissionManager:setup()
	
end


function CellMissionManager:_setup_mission()
	self._mission_path = "assets/CellMission/cell_" .. tostring(managers.job:current_level_id()) .. ".json";	
	if FileUtils:PathExists(self._mission_path) then
		local contents = FileUtils:ReadAllText(self._mission_path)		
		self._mission_elements = JsonUtils:safe_decode(contents)		
		if self._mission_elements then
			for _, script in pairs(managers.mission:scripts()) do
				
				
			end		
		end		
	end
end