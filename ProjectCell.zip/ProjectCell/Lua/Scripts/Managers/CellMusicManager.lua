dofile(ModPath .. "Lua/Scripts/Machines/MusicMachine.lua")

CellMusicManager = CellMusicManager or blt_class(CellManagerBase)

CellMusicManager.TRACK_TYPE = {}
CellMusicManager.TRACK_TYPE.DEFAULT = 1
CellMusicManager.TRACK_TYPE.HEIST_SPECIFIED = 2
CellMusicManager.TRACK_TYPE.STEALTH = 3

function CellMusicManager:setup()
	self._intro_event_overriden = false
	self._events_skip = {}
	self._listener_holder = EventListenerHolder:new()		
	self._custom_loud_tracks = {}
	self._machine = MusicMachine:new(self)
	self._lock_music_state_changes = false
	self._has_intro_playing = false
	self._logger = DebugLogger:new("CellMusicManager", true)
	self:add_listener("CellMusicManager.OnPagerCall", {"on_pager_call"}, callback(self,self,"on_pager_call"))	
	self:_setup_stealth_tracks()	
end

function CellMusicManager:post_setup()
	managers.cell_options:add_listener("CellMusicManager.MultipleChoiceKey", "CellOptionsManager.MultipleChoice", callback(self,self,"on_stealth_track_changed"))
	managers.cell_options:add_listener("CellMusicManager.GhostTrackIndex", "CellOptionsManager.GhostTrackIndex", callback(self,self,"on_heist_ghost_index_select"))
end


function CellMusicManager:_cell_sound_player()
	return self._csp
end


function CellMusicManager:_setup_stealth_tracks()
	self._stealth_tracks = {}
	table.insert(self._stealth_tracks, {
		track_type = CellMusicManager.TRACK_TYPE.DEFAULT,
		track = nil
	})
	
	for _, track_data in pairs(tweak_data.music.track_ghost_list) do
		table.insert(self._stealth_tracks, {
			track_type = CellMusicManager.TRACK_TYPE.STEALTH,
			track = track_data.track				
		})
	end
	
	self._stealth_track_choices = deep_clone(self._stealth_tracks)	
	
	table.insert(self._stealth_track_choices, 2, {		
		track_type = CellMusicManager.TRACK_TYPE.HEIST_SPECIFIED,
		track = nil
	})	
end


function CellMusicManager:get_ghost_track_by_index(index)
	return self._stealth_tracks[index]
end


function CellMusicManager:current_heist_stealth_track()	
	local current_level_name_id = managers.cell_job:current_level_name_id()	
	if not current_level_name_id then
		return nil
	end
	
	
	local choice = self._stealth_tracks[managers.cell_options:ghost_track_index_by_heist(current_level_name_id)]
	if choice then
		if choice.track_type == CellMusicManager.TRACK_TYPE.DEFAULT then
			return nil
		elseif choice.track_type == CellMusicManager.TRACK_TYPE.STEALTH then
			return choice.track
		end
	end	


	
	return nil
end



function CellMusicManager:current_stealth_track()
	if not CellOptionsManager.ALLOW_STEALTH_TRACKS  then
		return nil	
	end
	
	
	local stealth_track_choice = self._stealth_track_choices[managers.cell_options:multiple_choice_by_key("project_cell_suspense_choice")]
	if stealth_track_choice then
		if stealth_track_choice.track_type == CellMusicManager.TRACK_TYPE.DEFAULT then
			return nil		
		elseif stealth_track_choice.track_type == CellMusicManager.TRACK_TYPE.HEIST_SPECIFIED then
			return self:current_heist_stealth_track()
		elseif stealth_track_choice.track_type == CellMusicManager.TRACK_TYPE.STEALTH then
			return stealth_track_choice.track
		end
	end	
	return nil
end

function CellMusicManager:is_stealth_track()
	return self:current_stealth_track() ~= nil
end


function CellMusicManager:machine()
	return self._machine
end

function CellMusicManager:call_listeners(event, params)
	self._listener_holder:call(event, params)
end

function CellMusicManager:add_listener(key, events, clbk)
	self._listener_holder:add(key, events, clbk)
end

function CellMusicManager:remove_listener(key)
	self._listener_holder:remove(key)
end

function CellMusicManager:update(t,dt)
	if self._machine then
		self._machine:update_machine(t,dt)
	end	
end

function CellMusicManager:set_lock_on_music_state_changes(enabled)
	self._lock_music_state_changes = enabled
end

function CellMusicManager:music_state_changes_locked()
	return self._lock_music_state_changes
end

function CellMusicManager:change_state(name)
	if self._lock_music_state_changes then
		return
	end
	
	if self._machine:current_state_name() == name then
		return
	end
	
	
	self._machine:change_state(name)
end

function CellMusicManager:post_event(event)	
	managers.music:post_event(event)
end

function CellMusicManager:is_suspense_state_locked(state_name)
	return self._machine:is_suspense_state_locked(state_name)
end


function CellMusicManager:set_switch(switchGroup, switchName)	
	Global.music_manager.source:set_switch(switchGroup, switchName)
end

function CellMusicManager:get_heist_music_style()
	local level_id = Global.level_data and Global.level_data.level_id	
	if level_id then
		return tweak_data.levels:get_music_style(level_id)
	end
	return nil
end

function CellMusicManager:check_override_intro_heist_event()
	if self:get_heist_music_style() == "heist" then
		self._intro_event_overriden = true
		self:add_skip_event("intro")
		self:start_sneaking_music()		
	end	
end

function CellMusicManager:normalize_heist_intro()
	if self._intro_event_overriden then
		self._intro_event_overriden = false
		self:remove_skip_event("intro")
	end
end

function CellMusicManager:add_skip_event(event)
	if not table.contains(self._events_skip, event) then
		table.insert(self._events_skip, event)
	end
end

function CellMusicManager:remove_skip_event(event)
	if table.contains(self._events_skip, event) then
		table.delete(self._events_skip, event)
	end
end

function CellMusicManager:on_event_skip(event)
	if table.contains(self._events_skip, event) then
		return true
	end
	return false
end

function CellMusicManager:add_custom_loud_tracks(tracks)
	if type(tracks) == "string" then
		tracks = {tracks}
	end
	
	for _, track in pairs(tracks) do
		table.insert(self._custom_loud_tracks, track)
	end
end

function CellMusicManager:is_current_track_pdth()	
	local key = "track_pth_"
	local current_track = Global.music_manager.current_track	
	return current_track:sub(1, #key) == key or table.contains(self._custom_loud_tracks, current_track)
end


function CellMusicManager:is_default_music()
	return self._machine:is_default_music()
end

function CellMusicManager:start_sneaking_music()
	if self:is_sneaking_state() then
		return
	end
	
	
	local music_sneaking_state = MusicMachine.MUS_States.Sneaking	

	if self:is_default_music() and self:is_stealth_track() then
		music_sneaking_state = self:get_minimum_suspense_state_name()
	end	
	
	self:change_state(music_sneaking_state)	
end

function CellMusicManager:get_minimum_suspense_state_name()
	return self._machine:get_minimum_suspense_state_name()
end

function CellMusicManager:is_sneaking_state()
	return self._machine:is_sneaking_state()
end

function CellMusicManager:on_stop_listening()	
end

function CellMusicManager:on_stealth_track_changed()	
	self._machine:current_state():on_stealth_track_changed()
end


function CellMusicManager:on_heist_ghost_index_select(data)
	if managers.cell_job:current_level_name_id() == data.heist then
		self:on_stealth_track_changed()
	end
end

function CellMusicManager:preview_sneaking_track(track)
end

function CellMusicManager:on_pager_call(pager_count)
	self._machine:on_pager_call(pager_count)
end

function CellMusicManager:change_to_minimum_suspense_state()
	self._machine:change_to_minimum_suspense_state()
end

function CellMusicManager:set_minimum_suspense_index(suspense_index)
	self._machine:set_minimum_suspense_index(suspense_index)
end

function CellMusicManager:change_to_an_upcoming_suspense_state(steps)
	self._machine:change_to_an_upcoming_suspense_state(steps)
end

function CellMusicManager:has_intro_playing()
	return self._has_intro_playing 	
end

function CellMusicManager:set_intro_playing(enabled)
	if enabled then
		SoundDevice:set_rtpc("option_music_volume", 0)
	else		
		SoundDevice:set_rtpc("option_music_volume", Global.music_manager.volume * 100)
	end
	self._has_intro_playing = enabled	
end