ChatterWorldManager = ChatterWorldManager or blt_class(CellManagerBase)

function ChatterWorldManager:get_cam_position()
	local cam_position = Vector3()
	local viewport = managers.viewport:first_active_viewport()
	if viewport then
		local cam = viewport:camera()
		if cam then
			cam_position = cam:position()
		end
	end
	return cam_position
end

function ChatterWorldManager:in_sight(from, to, ignore_unit, slot_mask)
	local ray_table = {
		"ray", 
		from, 
		to, 
		"slot_mask", 
		slot_mask or managers.slot:get_mask("AI_visibility")
	}
	
	if ignore_unit then
		table.insert(ray_table, "ignore_unit")
		table.insert(ray_table, ignore_unit) 
	end
	local ray = World:raycast(unpack(ray_table))
	return not ray
end

function ChatterWorldManager:enemy_in_field_of_view(player, enemy)
	local my_head_pos = player:movement():m_head_pos()
	local cam_fwd = player:camera():forward()
	local u_head_pos = enemy:movement():m_head_pos() + math.UP * 30 
	local vec = u_head_pos - my_head_pos
	local dis = mvector3.normalize(vec)
	local ray = World:raycast("ray", my_head_pos, u_head_pos, "slot_mask", managers.slot:get_mask("AI_visibility"), "ray_type", "ai_vision", "ignore_unit", {enemy})
	local max_angle = 90
	local angle = vec:angle(cam_fwd)

	if math.abs(angle) > max_angle then
		return false
	end
	
	if not ray or mvector3.distance_sq(ray.position, u_head_pos) < 900 then
		return true
	end
	
	return false
end