CellDataBlockManager = CellDataBlockManager or blt_class(CellManagerBase)
CellDataBlockManager.DATABLOCKS_RESOURCE_PATH = CellDataBlockManager.DATABLOCKS_RESOURCE_PATH or ""
CellDataBlockManager.DATABLOCKS_PATH = "assets/CellData/"
CellDataBlockManager.DATABLOCKS_HEADER_PATH = "Lua/Scripts/CellData/Headers/"
CellDataBlockManager.CELLDATA_WRAPPER_PATH = "Lua/Scripts/CellData/CellDataWrappers/"
CellDataBlockManager.CELLDATA_SCRIPT_PATH = "Lua/Scripts/CellData/"

CellDataBlockManager.IS_RESOURCE_FILE = false

CellDataBlockManager.m_binaryEncoder = nil
CellDataBlockManager.ALL_DATABLOCK_TYPES = {
	--"MissionScriptSetupDataBlock",
	--"BranchBankMissionScriptDataBlock",
	--"FWB_MissionScriptDataBlock",
	--"Flat_MissionScriptDataBlock",
	--"DiamondHeistMissionScriptDataBlock",
	--"DiamondHeistMissionScriptDataBlock",
	--"DramaStateDataBlock",
	--"PlayerInteractionDialogDataBlock",
	"DrillReminderCharacterDataBlock",
	"PlayerVoiceInteractionsDataBlock",
	"CharacterTweaksDataBlock",
	"CharacterDataBlock",		
	"UserDataBlock",
	"IntroDataBlock",
	"PlayerDataBlock",
	"MusicStateDataBlock",
	"TextDataBlock",
	"NarratorDialogueDataBlock",
	"MenuItemDataBlock",
	"VanillaDialogDataBlock",
	"VanillaSoundEventDataBlock"
}


function CellDataBlockManager:setup()	
	CellDataBlockManager.m_binaryEncoder = BP_Coder:new(672683)
	self:setup_all_blocks()
end 




function CellDataBlockManager:SaveAllDataBlocksToDisk(generateHeaderFile, saveBinary, is_resource)
	for _, wrapper in pairs(self._block_wrappers) do
		if wrapper then
			wrapper:DoSaveToDisk(generateHeaderFile, saveBinary, is_resource)
		end
	end
end


function CellDataBlockManager:generate_all_header_files()
	for _, wrapper in pairs(self._block_wrappers) do
		if wrapper then
			wrapper:generateHeaderFile()
		end
	end
end


function CellDataBlockManager:setup_all_blocks()
	self._block_wrappers = {}
	
	if not FileUtils:DirectoryExists(CellDataBlockManager.DATABLOCKS_PATH) then
		error(CellDataBlockManager.DATABLOCKS_PATH .. " does not exist! Are we missing data blocks directory?")
	end
	
	
	local wrapper_types = CellDataBlockManager.ALL_DATABLOCK_TYPES
	if wrapper_types then
		for index, name in pairs(wrapper_types) do
			self:setup_wrapper(name)			
		end			
	end	
end



function CellDataBlockManager:setup_wrapper(wrapperName)		
	local customWrapperName = wrapperName:gsub("DataBlock","DataWrapper");	
	FileUtils:LoadFile(CellDataBlockManager.CELLDATA_WRAPPER_PATH ..customWrapperName..".lua");
	local new_wrapper = rawget(_G, customWrapperName)		
	if not new_wrapper then
		new_wrapper = CellDataBaseWrapper
		self:debug_print("Loading Base Wrapper..")
	else
		self:debug_print("Loading Wrapper : " .. tostring(customWrapperName))
	end	
	
	self._block_wrappers[wrapperName] = new_wrapper:new(wrapperName)	
end



function CellDataBlockManager:wrapper(wrapperName)
	if not self._block_wrappers[wrapperName] then
		self:debug_print(" wrapperName "..tostring(wrapperName).." not valid!!")
		return nil
	end
	return self._block_wrappers[wrapperName]
end
