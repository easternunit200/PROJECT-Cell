CoolDownManager = CoolDownManager or blt_class(CellManagerBase)

function CoolDownManager:setup()
	self._cooldowns = {}
	self._t = 0
end

function CoolDownManager:update(t,dt)
	self._t = t
end

function CoolDownManager:apply_cooldown(key, timer)
	self._cooldowns[key] = self._t + timer
end

function CoolDownManager:has_cooldown(key)
	return self._cooldowns[key] and self._cooldowns[key] > self._t
end