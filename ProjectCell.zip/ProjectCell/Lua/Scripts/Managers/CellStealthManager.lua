CellStealthManager = CellStealthManager or blt_class(CellManagerBase)
CellStealthManager.BAN_DIALOG = {
	"pager_a",
	"pager_b",
	"pager_d",
	"pager_e",
	"pager_f",
	"pager_g",
	"pager_h",
	"pat_05",
	"radio_missed",
	"radio_break",
	"radio_failed",
	"p01",
	"drl_alm_snd"
}

CellStealthManager._called_reasons = {
	alarm_pager_not_answered = "radio_missed",
	alarm_pager_hang_up = "radio_break",
	alarm_pager_bluff_failed = "radio_failed",
	cam_drill = "drl_alm_snd",
	civ_drill = "drl_alm_snd",
	cop_drill = "drl_alm_snd"
}




function CellStealthManager:get_ban_dialog_by_reason(reason)
	for blame, dialog in pairs(CellStealthManager._called_reasons) do
		if blame == reason then
			return dialog
		end
	end
	return nil
end

function CellStealthManager:state_blame(reason)
	local dialog = self:get_ban_dialog_by_reason(reason)
	if dialog then
		managers.dialog:queue_narrator_dialog(dialog, {})
	end	
end

function CellStealthManager:on_called_reason(reason) 
	managers.cell_callback:add_delayed_callback("CellStealthManager.StealthFailedBlame", math.rand(2,3), callback(self,self,"state_blame", reason))	
end
