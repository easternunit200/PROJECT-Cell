PlayerConditionManager = PlayerConditionManager or blt_class(CellManagerBase)
function PlayerConditionManager:setup()
	self._players_downed_counter = {}
	self._criminal_added_key = "PlayerConditionManager_CriminalAdded"
	self._criminal_removed_key = "PlayerConditionManager_CriminalRemove"
	managers.criminals:add_listener(self._criminal_added_key, {"on_criminal_added"}, callback(self, self, "on_criminal_added"))		
end


function PlayerConditionManager:on_reset(unit)
	local character = managers.criminals:character_name_by_unit(unit)
	
	if managers.groupai:state():is_unit_team_AI(unit) then
		self:debug_print("character : " .. tostring(character) .. " is a bot and their downs are non-effective!")
		return
	end
	
	self._players_downed_counter[unit:key()] = 0	
	self:debug_print("character " .. tostring(character) .. " has reset their downs ")
end

function PlayerConditionManager:on_custody(unit)
	local character = managers.criminals:character_name_by_unit(unit)
	self._players_downed_counter[unit:key()] = 0	
	self:debug_print("character " .. tostring(character) .. " has went to custody, their downs are reset..")
end

function PlayerConditionManager:reacted_downed(downed_unit)	

	if managers.cell_user:is_cell_host() and downed_unit and alive(downed_unit) then
		local volunteers = {}
		for id, cell_user in pairs(managers.cell_user:all_cell_users()) do
			if cell_user:has_toggled("project_cell_react_downed_tog") then
				local user_unit = cell_user:unit()
				if user_unit and alive(user_unit) then
					if user_unit ~= downed_unit then
						local dis = Vector3Utils:distance(user_unit:position(), downed_unit:position())					
						if dis < 20  then
							table.insert(volunteers, user_unit)
						end					
					end				
				end			
			end		
		end	
		
		if next(volunteers) then
			local random_user_unit = volunteers[math.random(#volunteers)]		
			random_user_unit:sound():say("g29",true,true)
		end
	end	
	
	self._react_callback = nil
end

function PlayerConditionManager:delayed_reaction(downed_unit)
	if self._react_callback then
		return
	end
	
	self._react_callback = callback(self,self,"reacted_downed", downed_unit)
	
	managers.cell_callback:add_delayed_callback("PlayerConditionManager_DownedReaction", 0.5, self._react_callback)
end

function PlayerConditionManager:on_downed(unit)
	self:delayed_reaction(unit)
	if managers.groupai:state():is_unit_team_AI(unit) then
		return
	end
	
	local u_key = unit:key()
	if self._players_downed_counter[u_key] then
		self._players_downed_counter[u_key] = self._players_downed_counter[u_key] + 1
		
		local character = managers.criminals:character_name_by_unit(unit)
		self:debug_print(tostring(character) .. " HAS BEEN DOWNED!!")
		self:debug_print("character " .. tostring(character) .. " should now have " .. tostring(self._players_downed_counter[u_key]) .. " down(s).")
	end	
end


function PlayerConditionManager:on_reset_by_character(character)
	local unit = managers.criminals:character_unit_by_name(character)	
	if unit then
		if not managers.groupai:state():is_unit_team_AI(unit) then
			self:on_reset(unit)		
		end		
	else
		self:debug_print("ERROR : tried to reset a character's downed with a unit returning nil!!!")		
	end
end


function PlayerConditionManager:get_maximum_downs_until_death(unit)
	local u_key = unit:key()
	local last_down = 3
	local additional_lives
	if unit:base().is_local_player then
		additional_lives = managers.player:has_category_upgrade("player", "additional_lives") and true or false
	end
	if additional_lives then
		last_down = last_down + 1
	end
	if Global.game_settings.one_down then
		last_down = last_down - 2
	end
	return last_down
end

function PlayerConditionManager:get_revive_data_by_unit(unit)
	local revive_char_dmg_ext = unit:character_damage()
	if revive_char_dmg_ext.get_revives and revive_char_dmg_ext.get_revives_max then
		return revive_char_dmg_ext:get_revives_max(), revive_char_dmg_ext:get_revives()
	end
end




function PlayerConditionManager:report_criminal_downs()
	for i,v in pairs(managers.groupai:state():all_player_criminals()) do
		local revives = v.unit:character_damage():get_revives()
		local max_revives = v.unit:character_damage():get_revives_max()
		local character = managers.criminals:character_name_by_unit(v.unit)
		local message = string.format("character : %s\n\tdowns %s/%s", tostring(character), tostring(revives), tostring(max_revives))
		self:debug_print(message)
	end
end


function PlayerConditionManager:on_criminal_added(name, unit, peer_id, ai)
	local failure = false	
	if unit == nil then
		unit = managers.criminals:character_unit_by_name(name)
	end	
	if not ai then
		if unit then			
			self._players_downed_counter[unit:key()] = 0	
		else
			failure = true	
		end		
	end	
	self:debug_print((ai and "Bot" or "Player") .. " character added : " .. name)	
	if failure then
		self:debug_print("ERROR : when adding " ..(ai and "bot" or "player") .. " character : " .. name .. " their unit has returned nil!!")
	end
end
