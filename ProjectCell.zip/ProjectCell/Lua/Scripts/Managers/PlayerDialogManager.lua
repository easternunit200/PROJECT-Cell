PlayerDialogManager = PlayerDialogManager or blt_class(CellManagerBase)

function PlayerDialogManager:setup()
	self._startDialog_action = CellNetValidationActionHost:new("dia_str", callback(self,self,"do_start_dialog"))
	self._endDialog_action = CellNetValidationActionHost:new("dia_end", callback(self,self,"do_end_dialog"))
	self._playerDialogCoolDownTimers = {}	
	self._blockedDialogs = {}
	self._dialog_caster = PlayerDialogCastingDirector:new()
	self._dialog_wrapper = managers.cell_data:wrapper("PlayerInteractionDialogDataBlock")	
end


function PlayerDialogManager:post_setup()
	self:prepare_drama_filter()	
end

function PlayerDialogManager:prepare_drama_filter()
	self._dialogDramaFilterParsed = {}
	local allBlocks = self._dialog_wrapper:get_all_blocks()
	local states = managers.cell_drama:machine:states()		
	
	for	i, block in pairs(allBlocks) do
		local drama_filter = {}				
		for _, state in pairs(states) do
			drama_filter[state.STATE_NAME] = true
		end				
		
		if block.dramaFilter ~= nil then
			drama_filter[DramaMachine.STATES.Sneaking] = block.dramaFilter.Sneaking
			drama_filter[DramaMachine.STATES.Alert] = block.dramaFilter.Alert
			drama_filter[DramaMachine.STATES.Control] = block.dramaFilter.Control
			drama_filter[DramaMachine.STATES.Anticipation] = block.dramaFilter.Anticipation
			drama_filter[DramaMachine.STATES.Assault] = block.dramaFilter.Assault				
		end
		
		self._dialogDramaFilterParsed[block.persistentID] = drama_filter
		
	end
end


function PlayerDialogManager:_setup_listeners()
	self._criminal_added_key = "PlayerDialogManager_CriminalAdded"
	self._criminal_removed_key = "PlayerDialogManager_CriminalRemove"
	managers.criminals:add_listener(self._criminal_added_key, "on_criminal_added", callback(self, self, "on_criminal_added"))	
end

function PlayerDialogManager:on_criminal_added(unit)	
end


function PlayerDialogManager:get_character_id_by_unit(unit)
	for id, data in pairs(managers.criminals:characters()) do
		if data.unit == unit then
			return id
		end
	end
	return nil
end

function PlayerDialogManager:get_character_unit_by_id(char_id)
	for id, data in pairs(managers.criminals:characters()) do
		if id == char_id then
			return data.unit
		end		
	end
	return nil
end

function PlayerDialogManager:want_to_start_dialog(dialog_id, params)
	params = self:on_parameters_modified(params)
	
	local data = {}
	
	data.dialog_id = dialog_id
	data.A = params.A or -1
	data.B = params.B or -1
	data.C = params.C or -1
	data.D = params.D or -1
	
	self:_startDialog_action:Ask(data)	
end


function PlayerDialogManager:on_parameters_modified(params)
	params = params or {}
	for _, actor in pairs({"A","B","C","D"}) do
		if params[actor] and type(params[actor]) == "userdata" then
			local character_id = self:get_character_id_by_unit(params[actor])
			if character_id then
				params[actor] = character_id
			end			
		end
	end	
	
	return params
end

function PlayerDialogManager:end_dialog(trigger_unit, dialog_id, params)
end


function PlayerDialogManager:do_start_dialog(data, sender)
	local block = self._dialog_wrapper:get_block_by_id(data.dialog_id)	
	if block == nil or not block.internalEnabled then
		return
	end

	if self._blockedDialogs[data.dialog_id] then
		return
	end
	
	local current_state_name = managers.cell_drama:current_state_name()
	local int = managers.cell_drama:current_state_id()
	
	local dialog_log = "<<<<<------>>>\nParsed DialogID -> " .. tostring(data.dialog_id) .."\nDramaManager.CurrentState -> " .. tostring(current_state_name) .."\nint -> " .. tostring(int)
	self:debug_print(dialog_log)
	
	local machine = managers.cell_drama:machine()
	if not self._dialogDramaFilterParsed[block.persistentID][current_state_name] then		
		self:debug_print("do_start_dialog, dialog ID " .. tostring(data.dialog_id) .. " did not pass drama filter with current state " .. tostring(current_state_name))
		return
	end
	
	
	local available_alternatives = {}
	for i,alternative in pairs(block.dialogAlternatives) do
		if alternative.structure and alternative.structure.enabled then
			
		end
	end
end