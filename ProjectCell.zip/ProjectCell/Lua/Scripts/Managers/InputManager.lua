InputManager = InputManager or blt_class(CellManagerBase)

function InputManager:GetKeyDown(key)
	return Input:keyboard():down(Idstring(key))
end
