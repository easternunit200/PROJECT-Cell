dofile(ModPath .. "Lua/Scripts/Machines/CallBackMachine.lua")
CallBackManager = CallBackManager or blt_class(CellManagerBase)
function CallBackManager:init()
	self._machine = CallBackMachine:new(self)
end

function CallBackManager:add_delayed_callback(id, timer, clbk)
	self._machine:add_delayed_callback(id, timer, clbk)
end

function CallBackManager:remove_delayed_clbk(id)
	self._machine:remove_delayed_clbk(id)
end

function CallBackManager:update(t,dt)
	self._machine:update_machine(t,dt)
end