dofile(DeadLocke._path.."Lua/NewDialogSystem/PlayerTensionLimiter.lua")
dofile(DeadLocke._path.."Lua/NewDialogSystem/PlayerDramaFilter.lua")
dofile(DeadLocke._path.."Lua/NewDialogSystem/PlayerActorConditions.lua")
dofile(DeadLocke._path.."Lua/NewDialogSystem/PlayerDialogSegmentGroup.lua")
dofile(DeadLocke._path.."Lua/NewDialogSystem/PlayerDialogSegment.lua")

PlayerDialogManager = PlayerDialogManager or class(CellManagerBase)
PlayerDialogManager.m_overrideFiltersNext = false
PlayerDialogManager.COOLDOWNS = {}
PlayerDialogManager.COOLDOWNS.Unlimited = 0,
PlayerDialogManager.COOLDOWNS.VeryShortCooldown = 1
PlayerDialogManager.COOLDOWNS.ShortCooldown = 2
PlayerDialogManager.COOLDOWNS.MediumCooldown = 3
PlayerDialogManager.COOLDOWNS.LongCooldown = 4
PlayerDialogManager.COOLDOWNS.VeryLongCooldown = 5
PlayerDialogManager.COOLDOWNS.Once = 6


function PlayerDialogManager:setup()
	self._cooldowns = {}
	self._blocked_dialogs = {}
	self._start_dialog = nil
	self._end_dialog = nil
	self._user_data = managers.cell_data:wrapper("UserDataBlock"):get_block_by_id(1)
	self._playerData = managers.cell_data:wrapper("PlayerDataBlock"):get_block_by_id(1)
	self:on_incharge(true)
	self:_setup()
end


function PlayerDialogManager:update_segment_group(t,dt)
	if self._current_dialog and self._current_dialog.segment_group then
		self._current_dialog.segment_group:update(t, dt)
	end
end


function PlayerDialogManager:update(t,dt)
	self:update_segment_group(t, dt)
end



function PlayerDialogManager:on_incharge(enabled)
	CellGlobal:log("[PlayerDialogManager:on_incharge] I'm "..(enabled and "incharge" or "not incharge"))
	
	self._start_dialog = callback(self, self, enabled and "start_dialog" or "request_to_start_dialog")
	self._end_dialog = callback(self, self, enabled and "end_dialog" or "request_to_end_dialog")
end

function PlayerDialogManager:on_deadlocke_peer_joined_response(peer_id)
	if DeadLocke:incharge() then
		local t = TimerManager:game():time()
		
		for id, timer in pairs(self._cooldowns) do
			if timer then
				local cooldown_timer = timer - t
				if cooldown_timer > 0 then
					DeadLockeNetwork:send_json_data_to_peer(peer_id, "sync_dialog_cooldown", id, cooldown_timer)
				end
			end
		end
		
		for id, is_blocked in pairs(self._blocked_dialogs) do
			if is_blocked then
				DeadLockeNetwork:send_json_data_to_peer(peer_id, "sync_dialog_cooldown", id, -1)
			end
		end
	end	
end



function PlayerDialogManager:check_dialog_cooldown_timer(id)
	if self._blocked_dialogs[id] then
		return false
	end
	
	
	return not self._cooldowns[id] or self._cooldowns[id] < TimerManager:game():time()
end



function PlayerDialogManager:allowed_to_start_dialog()
	if self._user_data and self._user_data.allowPlayerDialog then
		return true
	end
	return false
end

function PlayerDialogManager:queue_dialog(id, params)	
	if not self:allowed_to_start_dialog() then
		CellGlobal:log("[PlayerDialogManager:stop_dialog] dialogue is not allowed")
		return
	end
	if self._start_dialog then
		self._start_dialog({id, params})
	end
end

function PlayerDialogManager:stop_dialog(priority)
	if not self:allowed_to_start_dialog() then
		CellGlobal:log("[PlayerDialogManager:stop_dialog] dialogue is not allowed")
		return
	end
	if self._end_dialog then
		self._end_dialog(priority)
	end
end


function PlayerDialogManager:get_best_story_information(verification_data)
	
	local best_dia_priority
	local segment_group_map = {}
	local rand = math.rand(1)
	
	local block = self._dialog_blocks[verification_data.id]
	
	for _, data in pairs(block.list) do
	
		local weighthandler = WeightHandler:new()
		local storyblock = managers.cell_data:wrapper("PlayerDialogStoryDataBlock"):get_block_by_id(data.StoryID)
		if storyblock then
			local alternatives = storyblock.story[storyblock.currentOrder + 1].alternatives
			
			if next(alternatives) then
				for index, alternative in pairs(alternatives) do
					local SegmentGroupBlockID = alternative.SegmentGroupBlockID
					if SegmentGroupBlockID and SegmentGroupBlockID > 0 then
						local segment_group_block = managers.cell_data:wrapper("PlayerDialogSegmentGroupDataBlock"):get_block_by_id(SegmentGroupBlockID)
						if segment_group_block and segment_group_block.internalEnabled then
							local segment_group = PlayerDialogSegmentGroup:new(segment_group_block)
							if segment_group and segment_group:verification(verification_data.params, verification_data.actors, rand) then
								local tree_info = {
									block = storyblock,
									segment_group = segment_group
								}
								weighthandler:add_value(tree_info, alternative.alternative_weight)
							end
						end
					end
				end
			end
		end
		
		if weighthandler:has_any() then
			local best_alternative = weighthandler:get_best_value()	
			if best_alternative then
				table.insert(segment_group_map, best_alternative)
			end
		end
		
	end


	if not next(segment_group_map) then
		DeadLocke:debug_log("[PlayerDialogManager:get_best_story_information] segment groupIDS empty!!!!\n")
		return nil
	end


	return segment_group_map[math.random(#segment_group_map)].value
end



function PlayerDialogManager:criminals()
	return managers.groupai:state():all_char_criminals()
end

function PlayerDialogManager:character_ID_by_name(name)
	local characters = {}
	for id, data in pairs(managers.criminals:characters()) do
		if data.name == name then
			return id
		end
	end
	return nil
end

function PlayerDialogManager:character_name_by_ID(CharID)
	local characters = {}
	for id, data in pairs(managers.criminals:characters()) do
		if id == CharID then
			return data.name
		end
	end
	return nil
end


function PlayerDialogManager:get_random_character(skip_downed) 
	local criminals = {}
	for u_key, u_data in pairs(self:criminals()) do
		if u_data and u_data.unit and alive(u_data.unit) and (skip_downed or u_data.unit:movement():downed())  then
			table.insert(criminals, managers.criminals:character_name_by_unit(u_data.unit) )
		end
	end
	if next(criminals) then
		local random_index = math.random(#criminals)
		return criminals[random_index]
	end
	return nil
end



function PlayerDialogManager:get_character_by_actor(list, actr)
	for character, actor in pairs(list) do
		if actr == actor then
			return character
		end
	end
	return nil
end

function PlayerDialogManager:get_actor_by_character(list, chr)
	for character, actor in pairs(list) do
		if character == chr then
			return actor
		end
	end
	return nil
end




function PlayerDialogManager:tag_actor(list, character, actor)
	if not DeadLocke:isNotNilorEmpty(actor) then
		return
	end
	
	list[character] = actor
end





function PlayerDialogManager:finished()
	if self._current_dialog.params.done_cbk then
		self._current_dialog.params.done_cbk("done")
	end
	
	self._current_dialog = nil
	DeadLocke:debug_log("[PlayerDialogManager:finished()] finished!")
end

function PlayerDialogManager:can_end_dialog(priority)
	if self._current_dialog and self._current_dialog.priority and self._current_dialog.priority > priority  then		
		return true
	end
	return false
end


function PlayerDialogManager:end_dialog(priority)
	if self:can_end_dialog(priority) then
		if self._current_dialog.segment_group then
			self._current_dialog.segment_group:end_segments()
		end
		if self._current_dialog.params.done_cbk then
			self._current_dialog.params.done_cbk("quit")
		end
		self._current_dialog.actors = {}
		self._current_dialog = nil
	end
	DeadLocke:debug_log("[PlayerDialogManager:end_dialog()] ended dialog!!!")
end

function PlayerDialogManager:request_to_end_dialog(priority)
	--DeadLockeNetwork:send_json_data_to_peer_incharge("request_to_end_dialog", priority)
end

function PlayerDialogManager:request_to_start_dialog(request_dialog)
	local id = request_dialog[1]
	local params = request_dialog[2]
	
	local actors_strings = ""
	if params.actors and next(params.actors) then
		for actor, character in pairs(params.actors) do
			actors_strings = actors_strings .. self:character_ID_by_name(character) .. " ".. actor .. "-"
		end		
	end
	
	--DeadLockeNetwork:send_json_data_to_peer_incharge("request_to_start_dialog", id, actors_strings, params.force_quit_current and true or false)
end

function PlayerDialogManager:current_dialog()
	return self._current_dialog
end


function PlayerDialogManager:get_character_by_character_index(character)
	local character_data = managers.criminals:character_data_by_name(character)
	return table.get_key(self:characters(), character_data)	
end


function PlayerDialogManager:get_character_index_by_character(index)
	return self:characters()[index]
end

function PlayerDialogManager:sync_cooldown(id, timer)
	if not self._dialog_blocks[id] then
		return
	end
	
	local cooldown = self._dialog_blocks[id].cooldown
	if cooldown == PlayerDialogManager.COOLDOWNS.Once then
		self._blocked_dialogs[id] = true
		return
	end
	
	if timer < 0  then
		return
	end
	
	self._cooldowns[id] = TimerManager:game():time() + timer
end


function PlayerDialogManager:add_cooldown(dialogID)
	if not self._dialog_blocks[dialogID] then
		return
	end
	
	local t = TimerManager:game():time()
	local cooldown = self._dialog_blocks[dialogID].cooldown	
	if self._playerData.cooldown == PlayerDialogManager.COOLDOWNS.Unlimited then
		return
	end
	
	
	if cooldown == PlayerDialogManager.COOLDOWNS.VeryShortCooldown then
		self._cooldowns[dialogID] = t + self._playerData.VeryShortDialogCooldown
	elseif cooldown == PlayerDialogManager.COOLDOWNS.ShortCooldown then
		self._cooldowns[dialogID] = t + self._playerData.ShortDialogCooldown
	elseif cooldown == PlayerDialogManager.COOLDOWNS.MediumCooldown then
		self._cooldowns[dialogID] = t + self._playerData.MediumDialogCooldown
	elseif cooldown == PlayerDialogManager.COOLDOWNS.LongCooldown then
		self._cooldowns[dialogID] = t + self._playerData.LongDialogCooldown
	elseif cooldown == PlayerDialogManager.COOLDOWNS.VeryLongCooldown then
		self._cooldowns[dialogID] = t + self._playerData.VeryLongDialogCooldown
	elseif cooldown == PlayerDialogManager.COOLDOWNS.Once then
		self._blocked_dialogs[dialogID] = true
	end
	
	if DeadLocke:incharge() then
		if self._cooldowns[dialogID] then
			--DeadLockeNetwork:send_json_data_to_peers("sync_dialog_cooldown", dialogID, self._cooldowns[dialogID] - t)
		elseif self._blocked_dialogs[dialogID] then
		    --DeadLockeNetwork:send_json_data_to_peers("sync_dialog_cooldown", dialogID, -1)
		end
	end
	
end

function PlayerDialogManager:sync_start_dialog(id, actors_strings, force_quit_current)
	if not DeadLocke:incharge() then
		return
	end
	
	local params = {}
	
	if force_quit_current then	
		params.force_quit_current = true
	end
	
	if actors_strings ~= "" then
		params.actors = {}
		local actor_list = string.split(actors_strings, "-")
		for i, actor_data in pairs(actor_list) do
			local character_info = string.split(actor_data, " ")
			local charID = character_info[1]
			local actor = character_info[2]
			self:tag_actor(params.actors, self:character_name_by_ID(charID), actor)
		end
	end
	
	self:queue_dialog(id, params)
end

function PlayerDialogManager:SetStoryOrder(storyID, order, sync)
	local storyData = self._storyBlocks[storyID]
	local storyBlock = storyData.block
	
	if not order then
		if storyBlock.story[storyData.currentStory + 2] then
			order = storyData.currentOrder + 1			
		end
	end
	
	
	
	if sync and DeadLocke:incharge() then
		--DeadLockeNetwork:send_json_data_to_peers("set_story_order", storyID, storyData.currentOrder)
		
		storyData.currentOrder = order
	end
end


function PlayerDialogManager:start_dialog(request_dialog)
	
	
	local id = request_dialog[1]
	local params = request_dialog[2]
	
	if not params.skip_idle_check and managers.platform:presence() == "Idle" then
		return
	end
	
	
	if not self._dialog_blocks[id] then
		return
	end
	
	
	if params.force_quit_current then
		self:stop_dialog(-1000)
	end
	
	if self._current_dialog then
		return
	end
	
	
	
	local verification_data = {
		id = id,
		params = params,
		actors = {}
	}
	
	if params.actors and next(params.actors) then
		for actor, character in pairs(params.actors) do
			self:tag_actor(verification_data.actors, character, actor)
		end
	end
	
	local pass = false
	
	if self._dialog_blocks[id].probabilityToTrigger == 1 or math.random() < self._dialog_blocks[id].probabilityToTrigger then
		pass = true
	end
	
	if params.m_overrideFiltersNext then
		pass = true
	end
	
	
	
	
	if pass and (params.m_overrideFiltersNext or self:check_dialog_cooldown_timer(id)) then
		local story = self:get_best_story_information(verification_data)
		if story then
			self._current_dialog = verification_data
			self._current_dialog.segment_group = story.segment_group
			self._current_dialog.priority = self._dialog_blocks[id].priority
			local random_delay = math.rand(self._dialog_blocks[id].random_delay.x, self._dialog_blocks[id].random_delay.y)
			
			self._current_dialog.segment_group:play_segments(params, random_delay)
			
			self:SetStoryOrder(story.block.persistentID, nil, true)
			
			self:add_cooldown(id)
		end	
	end
	

end


function PlayerDialogManager:_setup()
	self._dialog_blocks = {}
	self._storyBlocks = {}

	
	for _, block in pairs(managers.cell_data:wrapper("PlayerDialogDataBlock"):get_all_blocks()) do			
		if self._dialog_blocks[block.persistentID] then
			error("[PlayerDialogManager:setup] block persistentID " ..tostring(block.persistentID).." already defined!!!")
		end		
		self._dialog_blocks[block.persistentID] = block		
	end	
	
	for index, block in pairs(managers.cell_data:wrapper("PlayerDialogStoryDataBlock"):get_all_blocks()) do
		self._storyBlocks[block.persistentID] = {
			currentStory = 0,
			block = block,
			storyID = block.persistentID
		}
	end
	
end 
