CellMissionBase = CellMissionBase or blt_class()

function CellMissionBase:init(block)
	self._block = block
	self._element_id = block.ElementID
	self._enabled = block.Enabled;
end

function CellMissionBase:on_executed(instigator)
	if not self._enabled then
		return
	end

end