core:import("CoreMissionScriptElement")

CellElementToggle = CellElementToggle or class(CoreMissionScriptElement.MissionScriptElement)

-- Lines 6-8
function CellElementToggle:init(...)
	CellElementToggle.super.init(self, ...)
end

-- Lines 10-12
function CellElementToggle:client_on_executed(...)
	self:on_executed(...)
end

function CellElementToggle:on_script_activated()
	CellElementToggle.super.on_script_activated(self)

	if self:value("execute_on_startup") then
		self:on_executed()
	end
end

-- Lines 14-37
function CellElementToggle:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	
	local elements = {}
	
	if self._values.blocks and next(self._values.blocks) then
		for _, block_id in pairs(self._values.blocks) do
			local block = managers.cell_data:wrapper("MissionScriptSetupDataBlock"):current_mission_wrapper():get_block_by_id(block_id)
			if block then
				if block.element then
					table.insert(elements, block.element)
				else
					CellGlobal:log("ERROR : block of name " .. tostring(block.name) .. " with id " .. tostring(block.persistentID) .. " does not have an element!!")
				end
			else
				CellGlobal:log("ERROR : block id " .. tostring(block_id) .. " doesn't exist!!")
			end
		end
	end
	
	if self._values.elements and next(self._values.elements) then
		for _, element_id in pairs(self._values.elements) do
			local element = self:get_mission_element(element_id)
			if element then
				table.insert(elements, element)
			else
				log("ERROR : element_id " .. tostring(element_id) .. " does not exist!!")
			end
		end
	end

	for _, element in pairs(elements) do
		if element then
			if self._values.toggle == "on" then
				element:set_enabled(true)

				if self._values.set_trigger_times and self._values.set_trigger_times > -1 then
					element:set_trigger_times(self._values.set_trigger_times)
				end
			elseif self._values.toggle == "off" then
				element:set_enabled(false)
			else
				element:set_enabled(not element:value("enabled"))
			end

			element:on_toggle(element:value("enabled"))
		end
	end

	CellElementToggle.super.on_executed(self, instigator)
end
