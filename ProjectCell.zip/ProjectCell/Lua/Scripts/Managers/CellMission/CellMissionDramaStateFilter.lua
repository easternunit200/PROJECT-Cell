core:import("CoreMissionScriptElement")

CellElementDramaState = CellElementDramaState or class(CoreMissionScriptElement.MissionScriptElement)

function CellElementDramaState:client_on_executed(...)
	self:on_executed(...)
end



function CellElementDramaState:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	
	managers.cell_drama:change_state(self._values.state_id, true)	
	CellElementDramaState.super.on_executed(self, instigator)
end
