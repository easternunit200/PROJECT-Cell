core:import("CoreMissionScriptElement")

CellElementDifficultyCheck = CellElementDifficultyCheck or class(CoreMissionScriptElement.MissionScriptElement)

function CellElementDifficultyCheck:client_on_executed(...)
	self:on_executed(...)
end



function CellElementDifficultyCheck:on_script_activated()
	CellElementDifficultyCheck.super.on_script_activated(self)

	if self:value("execute_on_startup") then
		self:on_executed()
	end
end


function CellElementDifficultyCheck:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	if not self._values.difficulty then
		return
	end
		
	local diff = Global.game_settings and Global.game_settings.difficulty or "hard"
	
	local pass = false
	
	
	
	if diff == "easy" and self._values.difficulty.easy then
		pass = true
	end
	
	if diff == "normal" and self._values.difficulty.normal then
		pass = true
	end
	
	if diff == "hard" and self._values.difficulty.hard then
		pass = true
	end
	
	if diff == "overkill" and self._values.difficulty.very_hard then
		pass = true
	end
	
	if diff == "overkill_145" and self._values.difficulty.overkill then
		pass = true
	end
	
	if diff == "easy_wish" and self._values.difficulty.mayhem then
		pass = true
	end		
	
	if diff == "overkill_290" and self._values.difficulty.death_wish then
		pass = true
	end
	
	
	if diff == "sm_wish" and self._values.difficulty.death_sentence then
		pass = true
	end
	
	
		
	if pass then
		CellElementDifficultyCheck.super.on_executed(self, instigator)
	end
	
end
