CellDrillManager = CellDrillManager or blt_class(CellManagerBase)
CellDrillManager.REMINDER_TIMERS = {
	Min = 30,
	Max = 75,
	TimeIncrease = 15
}

function CellDrillManager:setup()
	self._jammed_drills = {}
	self._active_drills = {}
end

function CellDrillManager:all_active_drills()
	return self._active_drills
end

function CellDrillManager:narrator_drill_jammed_dialogue(d_data)
	if not d_data.narrator_jammed_dialogues or not next(d_data.narrator_jammed_dialogues) then
		return
	end
	
	
	local narrator_line = d_data.narrator_jammed_dialogues[d_data.jammed_count <= 1 and 1 or 2]
	
	local suffix = self:get_drill_amount(d_data.drill_type) <= 1 and "sin" or "plu"
	
	if narrator_line and managers.groupai:state():bain_state() and managers.cell_options:has_toggled("project_cell_sam_misc_tog") then
		managers.dialog:queue_narrator_dialog(string.format(narrator_line, suffix) , {delay = 1})
	end
	
end

function CellDrillManager:get_drill_name(unit)
	local tweak_data = unit and unit.interaction and unit:interaction() and unit:interaction().tweak_data
	local drill_name = tweak_data and tweak_data:gsub('_jammed',''):gsub('_upgrade','')
	return drill_name
end


function CellDrillManager:register_drill(unit)
	if not unit then
		return
	end
	
	local u_sighting = {
		unit = unit,
		pos = unit:position(),
		priority = 6,
		drill_type = "default",
		jammed_count = 0,
		narrator_jammed_dialogues = {}
	}
	if unit.base and unit:base() then
		local drill_name = self:get_drill_name(unit)
		if unit:base().is_huge_lance then
			u_sighting.priority = 1
			u_sighting.drill_type = "lance"
		elseif drill_name == "lance" then
			u_sighting.priority = 2
			u_sighting.drill_type = "lance"
			u_sighting.narrator_jammed_dialogues = {"d05x_%s","d06x_%s"}
		elseif unit:base().is_hacking_device then
			u_sighting.priority = 3
			u_sighting.drill_type = "hacking_device"
			if drill_name == "reboot_computer" then
				u_sighting.narrator_jammed_dialogues = {"d07b_%s","d08b_%s"}
			else
				u_sighting.narrator_jammed_dialogues = {"d07a_%s","d08a_%s"}
			end			
		elseif unit:base().is_saw then
			u_sighting.priority = 4
			u_sighting.drill_type = "saw"
			u_sighting.narrator_jammed_dialogues = {"d03_sin","d04_sin"}
		elseif unit:base().is_drill then
			u_sighting.priority = 5
			u_sighting.drill_type = "drill"
			u_sighting.narrator_jammed_dialogues = {"d01x_%s","d01x_%s"}
		end
		
	end
	
	self._active_drills[unit:key()] = u_sighting	
end

function CellDrillManager:unregister_drill(unit)
	if not unit then
		return
	end
	
	
	self._active_drills[unit:key()] = nil	
end

function CellDrillManager:register_jammed_drill(unit)
	if not unit then
		return
	end
	
	local u_key = unit:key()
	
	if not self._active_drills[u_key] then
		self:debug_print("ERROR : Trying to register an unknown jammed drill that is not valid!!")
		return
	end
	
	
	self._jammed_drills[u_key] = self._active_drills[u_key]	
	
	
	self._jammed_drills[u_key].jammed_count = self._jammed_drills[u_key].jammed_count + 1
	
	self:narrator_drill_jammed_dialogue(self._jammed_drills[u_key])
	if next(self._jammed_drills) and not self._drill_remind_clbk then
		self._next_jammed_reminder_t = CellDrillManager.REMINDER_TIMERS.Min
		self._drill_remind_id = "CellDrillJammed"
		self._drill_remind_clbk = callback(self, self, "_drill_reminder_clbk")
		managers.cell_callback:add_delayed_callback(self._drill_remind_id, 20, self._drill_remind_clbk)
	end
end


function CellDrillManager:get_drill_amount(drill_type)
	local amount = 0
	for u_key, u_sighting in pairs(self._active_drills) do
		if u_sighting.drill_type == drill_type then
			amount = amount + 1
		end		
	end
	return amount
end

function CellDrillManager:unregister_jammed_drill(unit)
	if not unit then
		return
	end
	

	self._jammed_drills[unit:key()] = nil
	if not next(self._jammed_drills) and self._drill_remind_clbk then
		managers.cell_callback:remove_delayed_clbk(self._drill_remind_id)
		self._drill_remind_clbk = nil
	end
end

function CellDrillManager:closest_jammed_drill()
	local close_u_data_d, best_priority, close_u_data
	local close_pos = managers.player:player_unit() and managers.player:player_unit():position() or Vector3()
	for u_key, u_data in pairs(self._jammed_drills) do
		local close_dis = mvector3.distance_sq(close_pos, u_data.pos)
		if (not close_u_data_d or close_dis < close_u_data_d) and (not best_priority or u_data.priority <= best_priority) then
			close_u_data_d = close_dis
			close_u_data = u_data
			best_priority = u_data.priority
		end
	end
	return close_u_data
end

CellDrillManager.REMMINDER_COMMENTS_IDS = {}
CellDrillManager.REMMINDER_COMMENTS_IDS.Drill = 1
CellDrillManager.REMMINDER_COMMENTS_IDS.Hacking_Device = 2
CellDrillManager.REMMINDER_COMMENTS_IDS.Saw = 3
CellDrillManager.REMMINDER_COMMENTS_IDS.Thermal_Lance = 4
CellDrillManager.REMMINDER_COMMENTS_IDS.Default = 5

function CellDrillManager:get_best_drill_reminder_block_by_character(character, drill_type)

	local best_block = nil
	for _, block in pairs(managers.cell_data:wrapper("DrillReminderCharacterDataBlock"):get_all_blocks()) do
		if block.drill_type == drill_type then
			if not block.characters or not next(block.characters) or table.contains(block.characters, character) then
				if not best_block or best_block.priority <= block.priority then
					best_block = block
				end
			end
		end		
	end
	
	return best_block
end

function CellDrillManager:drill_remminder_comment(d_data)
	local announcers = {}
	
	local best_priority, closest_distance
	local close_pos = managers.player:player_unit() and managers.player:player_unit():position() or Vector3()
	
	for u_key, u_data in pairs(managers.groupai:state():all_char_criminals()) do
		if u_data.unit and alive(u_data.unit) and not u_data.unit:base().is_local_player and not u_data.unit:movement():downed() then
			local criminal_name = managers.criminals:character_name_by_unit(u_data.unit)
			if criminal_name then				
				local block = self:get_best_drill_reminder_block_by_character(criminal_name, d_data.drill_type)				
				if block then
					local distance = mvector3.distance_sq(close_pos, u_data.unit:movement():m_head_pos())
					table.insert(announcers, {
						unit = u_data.unit,
						block = block,
						distance = 	distance,
						criminal_name = criminal_name
					})
					
					self:debug_print("adding a block " .. tostring(block.name) .. " with character " .. criminal_name .. " with a priority of " .. tostring(block.priority))
					best_priority = best_priority and math.max(best_priority, block.priority) or block.priority
					
					self:debug_print("best priority so far : "  .. tostring(best_priority))
				end				
			end
		end	
	end
	
	if next(announcers) then	
		
		
		for i=#announcers, 1,-1 do
			local announcer_data = announcers[i]
			if announcer_data then
				if announcer_data.block.priority < best_priority then
					self:debug_print("block of "..tostring(announcer_data.block.name) .. " is less important " .. tostring(announcer_data.block.priority) .. " < " .. tostring(best_priority) .. " removing " .. tostring(announcer_data.criminal_name))
					table.remove(announcers, i)
				else
					local distance = announcer_data.distance
					closest_distance = closest_distance and math.min(closest_distance, distance) or distance
					self:debug_print("block of "..tostring(announcer_data.block.name) .. " is equally important " .. tostring(announcer_data.block.priority) .. " : " .. tostring(best_priority) .. " keeping " .. tostring(announcer_data.criminal_name))
				end	
			end
				
		end	
		
		
		if next(announcers) then
			for i=#announcers, 1,-1 do
				local announcer_data = announcers[i]
				if closest_distance then
					local farther = announcer_data.distance > closest_distance
					self:debug_print("is character " .. tostring(announcer_data.criminal_name) .. " farther? " .. tostring(announcer_data.distance) .. " > " .. tostring(closest_distance) .. " " .. (farther and "YES" or "NO"))
				
					if farther then
						table.remove(announcers, i)
					end		
				end					
			end	
		end			
		

		if next(announcers) then
			local winner = announcers[math.random(#announcers)]
			
			local block = winner.block
			
			local remminder_comment = block.FirstJammedComment
			
			if d_data.jammed_count and d_data.jammed_count > 1 then
				remminder_comment = block.SecondJammedComment
			end	
			
			local suffix = self:get_drill_amount(d_data.drill_type) <= 1 and "sin" or "plu"
			
			remminder_comment = remminder_comment:gsub("{suffix}",suffix)

			if remminder_comment then
				winner.unit:sound():say(remminder_comment, false, true)
			end		
			
		end
		
		return
	end
	
	self:debug_print("no announcer found!!")
end



function CellDrillManager:_drill_reminder_clbk()

	local d_data = self:closest_jammed_drill()
	if d_data and d_data.drill_type then
		if not managers.groupai:state():whisper_mode() then
			self:drill_remminder_comment(d_data)		
		end		
	end
	
	managers.cell_callback:add_delayed_callback(self._drill_remind_id, self._next_jammed_reminder_t, self._drill_remind_clbk)
	
	
	
	self._next_jammed_reminder_t = math.min(self._next_jammed_reminder_t + CellDrillManager.REMINDER_TIMERS.TimeIncrease, CellDrillManager.REMINDER_TIMERS.Max)
end

function CellDrillManager:all_jammed_drills()
	return self._jammed_drills
end