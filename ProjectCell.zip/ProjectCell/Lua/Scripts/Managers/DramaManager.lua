dofile(ModPath.."Lua/Scripts/Machines/DramaMachine.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaStateFilterBase.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaStateFilterClient.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaStateFilterForced.lua")
dofile(ModPath.."Lua/Scripts/DramaStates/DramaStateFilterChill.lua")


DramaManager = DramaManager or blt_class(CellManagerBase)
function DramaManager:setup()
	self._criminal_comment_data = {}
	self._has_forced_state = false
	self._revive_line_cooldown_t = nil	
	self._last_downed_time = 0
	self._has_last_down_time = false
	self._downedCommentCoolDownTimer = nil	
	
	self:_setup_criminal_listeners()	
	self:_reset_synced_states()	
	self:_setup_listener()
	
	self._machine = DramaMachine:new(self)	
end

function DramaManager:post_setup()
	self:_setup_post_drama_states()
	self:_setup_network()
	self:_setup_user_clbks()
	self:_setup_drama_filters()
end


function DramaManager:_setup_drama_filters()
	self._filtered_state_host = DramaStateFilterBase:new()		
	self._filtered_state_client = DramaStateFilterClient:new()		
	self._filtered_state_forced = DramaStateFilterForced:new()
	self._filtered_state_chill = DramaStateFilterChill:new()
	
	
	if managers.cell_job:is_chill_heist() then
		self._filtered_state_default = self._filtered_state_chill	
	else
		self._filtered_state_default = self._filtered_state_host	
	end
	
	self._current_state_filtered = self._filtered_state_default			
end



function DramaManager:_setup_network()
	self._drama_sync_action = CellNetValidationAction:new("DRA", callback(self,self,"do_sync_state"))	
end


function DramaManager:_setup_post_drama_states()
	self._discovered_state = self._machine:get_state_by_name(DramaMachine.STATES.Discovered)
end

function DramaManager:_setup_user_clbks()
	managers.cell_user:add_cell_host_callback(callback(self,self,"on_cell_host"))
	managers.cell_user:add_left_callback(callback(self,self,"on_user_left"))
end

function DramaManager:_setup_criminal_listeners()
	self._criminal_added_key = "DramaManager_CriminalAdded"
	self._criminal_removed_key = "DramaManager_CriminalRemove"
	managers.criminals:add_listener(self._criminal_added_key, {"on_criminal_added"}, callback(self, self, "on_criminal_added"))		
end

function DramaManager:_setup_listener()
	self._listener_holder = EventListenerHolder:new()
end

function DramaManager:on_user_left(peer_id)
	self._peers_synced_states[peer_id] = DramaMachine.STATES.Idle
	self._peers_synced_tensions[peer_id] = 0
end


function DramaManager:criminal_record(unit)
	return managers.groupai:state():criminal_record(unit:key())
end

function DramaManager:on_criminal_hurt(unit, attacker, dmg_percent)
	local record = self:criminal_record(unit)
	if not record then
		return
	end
	
	if unit:base().is_local_player then
		self._machine:current_state():on_local_damage(record, attacker, dmg_percent)
	else
		self._machine:current_state():on_teammate_damage(record, attacker, dmg_percent)
	end	
end

function DramaManager:on_criminal_disabled(unit)
	local record = self:criminal_record(unit)
	if not record then
		return
	end
	
	if record.status == "disabled" then
		managers.cell_condition:delayed_reaction(record.unit)
	end	
	
	if unit:base().is_local_player then
		self._machine:current_state():on_local_disabled(record)
	else
		self._machine:current_state():on_teammate_disabled(record)
	end	
end

function DramaManager:on_criminal_neutralized(unit)
	local record = self:criminal_record(unit)
	if not record then
		return
	end
	
	
	if unit:base().is_local_player then
		self._machine:current_state():on_local_neutralized(record)
	else
		self._machine:current_state():on_teammate_neutralized(record)
	end	
end

function DramaManager:on_fake_assault_setup()	
end

function DramaManager:is_game_over_screen()
	return game_state_machine:current_state_name() == "gameoverscreen"
end

function DramaManager:is_victory_screen()
	return game_state_machine:current_state_name() == "victoryscreen"
end


function DramaManager:_call_listeners(event, params)
	self._listener_holder:call(event, params)
end

function DramaManager:add_listener(key, events, clbk)
	self._listener_holder:add(key, events, clbk)
end

function DramaManager:remove_listener(key)
	self._listener_holder:remove(key)
end


function DramaManager:on_criminal_added(name, unit, peer_id, ai)
	if unit == nil then
		self:debug_print("ERROR : Character " .. tostring(name) .. " unit has returned nil!!")
		return 
	end
	
	
	if unit:base().is_local_player then
		self._machine:set_owner(unit, name)
	end
end

function DramaManager:on_cell_host(enabled)
	self._filtered_state_default = enabled and self._filtered_state_host or self._filtered_state_client
end


function DramaManager:on_criminal_removed(char_data)
end


function DramaManager:_reset_synced_states()	
	self._peers_synced_tensions = {}
	self._peers_synced_states = {}
	
	for i=1, CriminalsManager.MAX_NR_CRIMINALS do
		self._peers_synced_states[i] = DramaMachine.STATES.Idle
		self._peers_synced_tensions[i] = 0
	end
end

function DramaManager:reset_state()	
	self:change_state(DramaMachine.STATES.Idle, true)
end

function DramaManager:machine()
	return self._machine
end

function DramaManager:do_sync_state(data, sender)
	local peer_id = data.peer_id or sender
	local state_id = data.state_id or DramaMachine.STATES.Idle
	local tension = data.tension or 0
	self:sync_change_state(peer_id, state_id, tension)
end


function DramaManager:want_to_sync_state(peer_id, state_id, tension)	
	self._drama_sync_action:execute_to_peers({
		peer_id = peer_id,
		state_id = state_id,
		tension = tension	
	})
end



function DramaManager:update(t, dt)
	self._machine:update_machine(t,dt)
end


function DramaManager:current_tension()
	return self._machine:current_tension()
end

function DramaManager:current_enemy_tension()
	return self._machine:current_enemy_tension()
end

function DramaManager:has_local_machine()
	return self._machine and true or false
end


function DramaManager:is_runnning()
	return self._machine:is_runnning()
end

function DramaManager:get_tension_max()
	return self._machine:get_tension_max()
end

function DramaManager:is_hurt()
	return self._machine:is_hurt()
end

function DramaManager:get_best_canditate(toggle_name, include_bots, bot_toggle_name)
	return managers.cell_user:get_best_canditate(toggle_name, include_bots, bot_toggle_name)
end

function DramaManager:sync_change_state(peer_id, state_name, tension)	
	self._peers_synced_states[peer_id] = state_name
	self._peers_synced_tensions[peer_id] = tension	
	self:debug_print("Syncing peer id " .. tostring(peer_id) .. " to state name : " ..state_name .. " with tension : " .. tostring(tension))
end


function DramaManager:check_synced_states(wanted_state)	
	local synced_states = {}	
	
	if managers.cell_user:has_cell_host() then
		for peer_id, state_name in pairs(self._peers_synced_states) do	
			if managers.cell_user:cell_host_peer_id() == peer_id then
				synced_states[state_name] = true
			end			
		end	
	end	
	
	if wanted_state then
		return synced_states[wanted_state]	
	end	
	
	return synced_states
end


function DramaManager:log_player_states()
	for peer_id, state_name in pairs(self._peers_synced_states) do	
		local cell_user = managers.cell_user:get_cell_user_by_peer_id(peer_id)		
		if cell_user then
			CellGlobal:log("Cell User " .. tostring(cell_user:name()) .. " is in drama state --> " .. tostring(state_name))
		end
	end	
end

function DramaManager:is_character_in_drama_state(character, wanted_state)
	return self._peers_synced_states[character] and self._peers_synced_states[character] == wanted_state or false
end

function DramaManager:states()
	return self._machine:states()
end


function DramaManager:force_drama_state(state, sync)	
	if type(state) == "number"  then
		state = self._machine:get_state_name_by_ID(state)
	end
	if self._machine:get_state_by_name(state) then
		if not self._has_forced_state then
			self._has_forced_state = true
			self._current_state_filtered = self._filtered_state_forced
		end
		
		self._current_state_filtered:set_forced_state(state)		
		
		self:change_state(state, sync)
	end
end


function DramaManager:unforce_drama_state()
	if self._has_forced_state then
		self._has_forced_state = false
		self._current_state_filtered = self._filtered_state_default	
	end	
end


function DramaManager:any_enemies_alarmed()
	for u_key, u_data in pairs(managers.enemy:all_enemies()) do
		if u_data and u_data.unit and alive(u_data.unit) and not u_data.unit:movement():cool() then
			if not u_data.unit:anim_data().hands_tied then
				return true
			end			
		end
	end	 
	for u_key, u_data in pairs(managers.enemy:all_civilians()) do
		if u_data and u_data.unit and alive(u_data.unit) and not u_data.unit:movement():cool() then
			if not u_data.unit:anim_data().drop and not u_data.unit:anim_data().tied and not u_data.char_tweak.is_escort then
				return true
			end			
		end
	end	 
	return false
end




function DramaManager:enemies_alarmed_within_range(range)
	local amount = 0
	local player = managers.player:player_unit()
	if player and alive(player) then
		for u_key, u_data in pairs(managers.enemy:all_enemies()) do
			if u_data and u_data.unit and alive(u_data.unit) and not u_data.unit:movement():cool() then
				local distance = mvector3.distance_sq(player:movement():m_head_pos(), u_data.m_pos)
				if distance < range then
					amount = amount + 1				
				end
			end
		end	 
	end	
	return amount
end

function DramaManager:go_to_chill()
	return self._current_state_filtered:go_to_chill()
end

function DramaManager:go_to_sneaking()
	return self._current_state_filtered:go_to_sneaking()
end

function DramaManager:go_to_encounter()
	return self._current_state_filtered:go_to_encounter()
end

function DramaManager:go_to_assault()	 
	return self._current_state_filtered:go_to_assault()
end

function DramaManager:go_to_alert()
	return self._current_state_filtered:go_to_alert()
end

function DramaManager:go_to_control()
	return self._current_state_filtered:go_to_control()
end

function DramaManager:go_to_fake_assault()
	return self._current_state_filtered:go_to_fake_assault()
end

function DramaManager:go_to_anticipation()
	return self._current_state_filtered:go_to_anticipation()
end

function DramaManager:go_to_discovered()
	return self._current_state_filtered:go_to_discovered()
end

function DramaManager:is_in_custody()
	return game_state_machine:current_state_name() == "ingame_waiting_for_respawn"
end

function DramaManager:on_downed(unit)	
	local is_locally_owned = unit:base().is_local_player
	local params = { 
		downed_unit = unit,
		is_locally_owned = is_locally_owned,
		persistent_downs = false
	}
	
	
	self._last_downed_time = self._t
	
	
	if is_locally_owned then
		if self._last_local_downed_time and self._last_local_downed_time + 20 > self._t then
			params.persistent_downs = true
		end
		self._last_local_downed_time = self._t
	end
	
	
	managers.cell_callback:add_delayed_callback("DramaManager_ReportDowns", 4, callback(self,self,"on_report_downed", params))
end

function DramaManager:on_report_downed(params)
	if self._machine:is_current_state_whisper() then
		return
	end
	
	
	if self._downedCommentCoolDownTimer and self._downedCommentCoolDownTimer > self._t then
		return
	end	
	
	if managers.cell_options:has_toggled("project_cell_sam_misc_tog")  then
		if params.downed_unit and alive(params.downed_unit) then
			local max_revives, revives = PlayerConditionManager:get_revive_data_by_unit(params.downed_unit)			
			if params.is_locally_owned then
			
				local suffix = nil
				if revives == 1 then
					suffix = "b"
				elseif params.persistent_downs then
					suffix = "a"
				end	

				if suffix then
					managers.dialog:queue_narrator_dialog("x01" .. suffix,{})
					self._downedCommentCoolDownTimer = self._t + 30
				end
				
			end			
		end
	end
end


function DramaManager:set_discovered(is_locally_discovered)	
	if self:go_to_sneaking() then
		self._discovered_state:set_discovered_locally(is_locally_discovered)	
		self:change_state(DramaMachine.STATES.Discovered, true)
	end	
end



function DramaManager:current_state()
	return self._machine:current_state()
end


function DramaManager:current_state_name()
	return self._machine:current_state_name()
end

function DramaManager:current_state_id()
	return self._machine:current_state_id()
end


function DramaManager:change_state(name, sync)
	self._machine:change_drama_state(name, sync)		
end


function DramaManager:suspicious_ratio_or_status()
	return self._machine:suspicious_ratio_or_status()
end

function DramaManager:log_suspicious_ratio_or_status()
	self:debug_print("Suspicious Ratio : " .. tostring(self:suspicious_ratio_or_status()))
	self:debug_print("Discovered : " .. tostring(managers.hud._hud_suspicion._discovered))
end

function DramaManager:discovered()
	return self:suspicious_ratio_or_status() == true
end