dofile(ModPath.. "Lua/Scripts/Interactions/CellBaseInteraction.lua")
dofile(ModPath.. "Lua/Scripts/Interactions/CellIntimidateInteraction.lua")
dofile(ModPath.. "Lua/Scripts/Interactions/CellReviveInteraction.lua")
dofile(ModPath.. "Lua/Scripts/Interactions/CellConvertHostageInteraction.lua")

CellInteractionManager = CellInteractionManager or blt_class(CellManagerBase)
CellInteractionManager.DEBUG_ENABLED = false

function CellInteractionManager:setup()
	self:_setup_tweak_data()
	self._current_indimidation_data = nil
	self._has_intimidation_action = false
end

function CellInteractionManager:_setup_tweak_data()
	self._interactions = {}
	
	self._interactions.intimidate = CellIntimidateInteraction:new()
	self._interactions.revive = CellReviveInteraction:new()
	self._interactions.hostage_convert = CellConvertHostageInteraction:new()
end


function CellInteractionManager:interaction_complete(interactor, object, tweak_data, t)	
	if not tweak_data or tostring(tweak_data) == "nil" then
		return
	end
	
	self:debug_print("interaction completed tweak data : " .. tostring(tweak_data))
	
	
	if self._interactions[tweak_data] then
		self._interactions[tweak_data]:interaction_complete(interactor, object, t)
	end
end

function CellInteractionManager:interaction_interrupted(interactor, object, tweak_data, t)	
	if not tweak_data or tostring(tweak_data) == "nil" then
		return
	end
	
	self:debug_print("interaction interrupted tweak data : " .. tostring(tweak_data))
	
	if self._interactions[tweak_data] then
		self._interactions[tweak_data]:interaction_interrupted(interactor, object, t)
	end
end

function CellInteractionManager:interaction_start(interactor, object, tweak_data, t)	
	if not tweak_data or tostring(tweak_data) == "nil" then
		return
	end
	
	self:debug_print("interaction started tweak data : " .. tostring(tweak_data))
	
	if self._interactions[tweak_data] then
		self._interactions[tweak_data]:interaction_start(interactor, object, t)
	end
end

function CellInteractionManager:set_intimidation_action(intimidation_data)
	self._current_indimidation_data = intimidation_data
	self._has_intimidation_action = true
end

function CellInteractionManager:release_intimidation_action()
	self._has_intimidation_action = false
end

function CellInteractionManager:has_intimidation_action()
	return self._has_intimidation_action
end

function CellInteractionManager:get_intimidation_data(key)
	return self._current_indimidation_data[key]
end

function CellInteractionManager:get_intimidate_sound_name_override(sound_name)
	local has_intimidation_action = self:has_intimidation_action()
	local t = CellGlobal.Time
	if has_intimidation_action then
		local voice_type = self:get_intimidation_data("voice_type")
		local plural = self:get_intimidation_data("plural")
		if voice_type == "stop" or voice_type == "down" then
			if self._shout_at_civilian_t and self._shout_at_civilian_t + 2 > t then
				if not plural then
					sound_name = "f02b_sin"
				end
			end
			self._shout_at_civilian_t = t	
		elseif voice_type == "cuff_cop" then
			if math.random() < 0.25 then
				sound_name = "f03b_any"
			end
		else
			local override_sound = managers.cell_voice:get_modified_interaction(voice_type)
			if override_sound and override_sound ~= "{default}" then
				sound_name = override_sound
			end	
		end
	
	end
	
	self:release_intimidation_action()
	return sound_name
end