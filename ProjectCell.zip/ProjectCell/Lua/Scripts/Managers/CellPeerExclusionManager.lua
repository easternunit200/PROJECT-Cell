CellPeerExclusionManager = CellPeerExclusionManager or blt_class(CellManagerBase)

function CellPeerExclusionManager:setup()
	self._exclude_peers = {}	
	managers.cell_user:add_left_callback(callback(self,self,"delete_exclusion"))
end

function CellPeerExclusionManager:all_excluded_peers()
	return self._exclude_peers
end

function CellPeerExclusionManager:is_peer_id_excluded(peer_id)
	return table.contains(self._exclude_peers, peer_id)
end

function CellPeerExclusionManager:exclude_peer(peer_id)
	if not table.contains(self._exclude_peers, peer_id) then
		self:debug_print("Peer ID : " .. tostring(peer_id) .. " will no longer hear cell lines.")
		table.insert(self._exclude_peers, peer_id)
		return
	end
	
	self:debug_print("Peer ID : " .. tostring(peer_id) .. " has already been excluded from the cell lines.")
end

function CellPeerExclusionManager:delete_exclusion(peer_id)
	if table.contains(self._exclude_peers, peer_id) then
		table.delete(self._exclude_peers, peer_id)
		self:debug_print("Peer ID : " .. tostring(peer_id) .. " will be able to hear cell lines again")
		return
	end
	
	self:debug_print("Peer ID : " .. tostring(peer_id) .. " already can hear cell lines.")
end