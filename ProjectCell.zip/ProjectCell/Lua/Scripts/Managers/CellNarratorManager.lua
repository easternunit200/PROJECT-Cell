CellNarratorManager = CellNarratorManager or blt_class(CellManagerBase)
CellNarratorManager.CELL_NARRATOR = false
CellNarratorManager.DEBUG_ENABLED = false
CellNarratorManager._sam_override_dialogues = {
	pln_branchbank_stage1_01 = "Play_sam_branchbank_stage1_01",
	pln_branchbank_stage1_02 = "Play_sam_branchbank_stage1_02",
	pln_branchbank_stage1_03 = "Play_sam_branchbank_stage1_03",
	pln_branchbank_stage1_04 = "Play_sam_branchbank_stage1_04",
	pln_branchbank_stage1_05 = "Play_sam_branchbank_stage1_05",
	pln_branchbank_stage1_08 = "Play_sam_branchbank_stage1_08",
	pln_branchbank_stage1_11 = "Play_sam_branchbank_stage1_11",
	pln_branchbank_stage1_12 = "Play_sam_branchbank_stage1_12",
	pln_branchbank_stage1_13 = "Play_sam_branchbank_stage1_13",
	pln_branchbank_stage1_14 = "Play_sam_branchbank_stage1_14",
	pln_branchbank_stage1_16 = "Play_sam_branchbank_stage1_16",
	pln_branchbank_stage1_18 = "Play_sam_branchbank_stage1_18",
	pln_branchbank_stage1_19 = "Play_sam_branchbank_stage1_19",
	pln_branchbank_stage1_21 = "Play_sam_branchbank_stage1_21",
	pln_branchbank_stage1_25 = "Play_sam_branchbank_stage1_25",
	pln_branchbank_stage1_29 = "Play_sam_branchbank_stage1_29",
	pln_branchbank_stage1_30 = "Play_sam_branchbank_stage1_30",
	pln_branchbank_stage1_35 = "Play_sam_branchbank_stage1_35",
	pln_branchbank_stage1_37 = "Play_sam_branchbank_stage1_37",
	pln_branchbank_stage1_38 = "Play_sam_branchbank_stage1_38",
	pln_branchbank_stage1_40 = "Play_sam_branchbank_stage1_40",
	pln_branchbank_stage1_80 = "Play_sam_branchbank_stage1_80",
	pln_branchbank_stage1_81 = "Play_sam_branchbank_stage1_81",
	pln_branchbank_stage1_82 = "Play_sam_branchbank_stage1_82",
	pln_branchbank_stage1_83 = "Play_sam_branchbank_stage1_83",
	pln_branchbank_stage1_84 = "Play_sam_branchbank_stage1_84",
	pln_branchbank_stage1_85 = "Play_sam_branchbank_stage1_85",
	pln_branchbank_stage1_86 = "Play_sam_branchbank_stage1_86",
	pln_branchbank_stage1_87 = "Play_sam_branchbank_stage1_87",
	pln_branchbank_stage1_88 = "Play_sam_branchbank_stage1_88",
	pln_branchbank_stage1_89 = "Play_sam_branchbank_stage1_89"
}

CellNarratorManager._custom_narrators = {
	locke = "loc",
	bain = "ban"
}


function CellNarratorManager:setup()
	self._elements_overriden_dialogues = {}
	self._has_last_narrator_preffix = false
	self._last_narrator_prefix = nil
	self:_init_region()
end


function CellNarratorManager:post_setup()	
	self:_setup_custom_narrator()
end

function CellNarratorManager:_setup_custom_narrator()
	if CellNarratorManager.CELL_NARRATOR then
		self:_setup_custom_mission_dialogues()		
	end
end

function CellNarratorManager:_setup_custom_mission_dialogues()
	table.insert(ElementDialogue.MutedDialogs, "play_sam_")
	for _, script in pairs(managers.mission:scripts()) do
		self:_parse_custom_dialogues(script:elements())
	end
end

function CellNarratorManager:_parse_custom_dialogues(list_elements)
	for id, element in pairs(list_elements) do
		local dialogue = element:value("dialogue")
		if dialogue then						
			local custom_dialogue = CellNarratorManager._sam_override_dialogues[dialogue]				
			if custom_dialogue then
				self._elements_overriden_dialogues[id] = {
					custom_dialogue = custom_dialogue,
					default_dialogue = dialogue
				}
			end
		end						
	end
end


function CellNarratorManager:_set_custom_narrator(narrator)		
	local narrator_prefix = CellNarratorManager._custom_narrators[narrator]
	if narrator_prefix and managers.dialog then
		self:_set_default_narrator()
		self._has_last_narrator_preffix = true
		self._last_narrator_prefix = managers.dialog._narrator_prefix
		managers.dialog._narrator_prefix = "Play_" .. narrator_prefix .. "_"
	end
end

function CellNarratorManager:_set_default_narrator()
	if self._has_last_narrator_preffix then
		self._has_last_narrator_preffix = false
		managers.dialog._narrator_prefix = self._last_narrator_prefix
	end
end

function CellNarratorManager:_init_region()
	local level_id = Global.level_data and Global.level_data.level_id
	local level_tweak = tweak_data.levels[level_id]		
end

function CellNarratorManager:play_dialog(id, params)
	local block = managers.cell_data:wrapper("NarratorDialogueDataBlock"):get_block_by_id(id)
	
	if not block or not block.internalEnabled then
		return
	end
	
	
	params = params or {}
	
	if managers.dialog and managers.groupai and managers.groupai:state():bain_state() then
		if block.PlayDialogue then
			if block.IgnorePrefix then
				managers.dialog:queue_dialog(block.PlayDialogue, params)
			else
				managers.dialog:queue_narrator_dialog(block.PlayDialogue, params)
			end		
		end
		
	end	
end

function CellNarratorManager:play_dialogs_in_segments(dialogIDS)	
	if not dialogIDS or not next(dialogIDS) then
		return
	end

	local segments = {}
	for index, dialogID in pairs(dialogIDS) do
		table.insert(segments, function()
			local params = {}			
			function params.done_cbk(reason)
				local nextSegment = table.remove(segments, 1)				
				if nextSegment then
					nextSegment()
				end				
			end					
			self:play_dialog(dialogID, params)
		end)		
	end
	
	if segments[1] then
		local firstsegment = table.remove(segments, 1)		
		firstsegment();
	end		
end


function CellNarratorManager:on_dialog_ended(reason)
	if reason == "finished" then
		managers.subtitle:set_visible(false)
		managers.subtitle:set_enabled(false)
		managers.dialog:finished()
	end	
end

function CellNarratorManager:set_sam_intensity_by_drama_state(drama_state)
end


function CellNarratorManager:set_whisper(enabled)
end


function CellNarratorManager:stop()
end

function CellNarratorManager:set_switch(switchGroup, switchName)
end


function CellNarratorManager:post_event_for_dialog(event_id)
end

function CellNarratorManager:post_event(event_id, callback, sync_callback)
end