CellOptionsManager = CellOptionsManager or blt_class(CellManagerBase)
CellOptionsManager.ModPath = ModPath
CellOptionsManager.SavePath = SavePath
CellOptionsManager.MENU_ITEM_TYPE = {}
CellOptionsManager.MENU_ITEM_TYPE.NONE = 0
CellOptionsManager.MENU_ITEM_TYPE.TOGGLE = 1
CellOptionsManager.MENU_ITEM_TYPE.SLIDER = 2
CellOptionsManager.MENU_ITEM_TYPE.MULTIPLE_CHOICE = 3
CellOptionsManager.MENU_ITEM_TYPE.GHOST_TRACK_CHOOSER = 4
CellOptionsManager.MENU_ITEM_TYPE.DIVIDER = 5
CellOptionsManager.ALLOW_STEALTH_TRACKS = false			--- Some users are experiencing crashes when setting this to true.
														--- Crash log related to this prints out vague information.
														--- Till then I'll just leave this off :/



function CellOptionsManager:setup()
	self._menu_entered = false
	self:_setup_mod_data()
	self._callback_toggle_id = "project_cell_callback_toggle_value_"
	self._callback_slider_id = "project_cell_callback_slide_value_"
	self._callback_multiple_choice_id = "project_cell_callback_multi_choice_value_"
	self._callback_value_index = 0	
	self._user_data = self:get_default_data()
	self._path = CellOptionsManager.ModPath
	self._save_path = CellOptionsManager.SavePath .. "CellSaveData.txt"
	self:_setup_listeners()
end

function CellOptionsManager:post_setup()
	self._menu_item_blocks = managers.cell_data:wrapper("MenuItemDataBlock"):get_all_blocks()	
	self:_setup_values()	
	self:_setup_menus()	
	self:_setup_menu_nodes()	
	self:_load_user_settings()
	self:_set_items_status()
end


function CellOptionsManager:get_default_data()
	return {
		toggles = {},
		sliders = {},
		intros = {},
		multiple_choice_keys = {},
		ghost_tracks = {}
	}
end

function CellOptionsManager:is_toggle(name)
	return self._mod_data.toggles[name] and true or false
end


function CellOptionsManager:is_slider(name)
	return self._mod_data.sliders[name] and true or false
end

function CellOptionsManager:is_obsolete_projects_present()
	return false
end

function CellOptionsManager:_setup_mod_data()
	self._mod_data = self:get_default_data()
end



function CellOptionsManager:get_toggle_callback_name()
	self._callback_value_index = self._callback_value_index + 1
	return self._callback_toggle_id .. tostring(self._callback_value_index)
end

function CellOptionsManager:get_slider_callback_name()
	self._callback_value_index = self._callback_value_index + 1
	return self._callback_slider_id .. tostring(self._callback_value_index)
end

function CellOptionsManager:get_multiple_choice_callback_name()
	self._callback_value_index = self._callback_value_index + 1
	return self._callback_multiple_choice_id .. tostring(self._callback_value_index)
end


function CellOptionsManager:create_toggle_item(data)
	local callback_name = self:get_toggle_callback_name()
	
	 MenuCallbackHandler[callback_name] = function(_, item)
		self:set_toggle_value(data.id, item:value() == "on", true)
	 end
	 
	 
	 local item = MenuHelper:AddToggle({
		id = data.id,
		title = data.title,
		desc = data.desc,
		callback = callback_name,
		priority = data.priority,
		menu_id = data.menu_id,
		value = data.value,
		show_value = data.show_value,
		localized = data.localized,
		disabled = data.disabled
	})
	return item
end

function CellOptionsManager:create_divider_item(data)
	local item = MenuHelper:AddDivider({
		id = data.id,
		size = data.size,
		menu_id = "project_cell",
		priority = data.priority,
	})
	return item
end

function CellOptionsManager:create_slider_item(data)
	local callback_name = self:get_slider_callback_name()	
	 MenuCallbackHandler[callback_name] = function(_, item)
		self:set_slider_value(data.id, MathUtils:get_fixed_value(item:value()), true)
	 end
	 
	 local item = MenuHelper:AddSlider({
		id = data.id,
		title = data.title,
		desc = data.desc,
		callback = callback_name,
		value = data.value,
		min = data.min or 0,
		max = data.max or 1,
		step = data.step or 0.01,
		show_value = data.show_value,
		menu_id = data.menu_id,
		priority = data.priority,
		disabled = data.disabled
	})
	return item
end

function CellOptionsManager:create_multiple_choice_item(data)
	local callback_name = self:get_multiple_choice_callback_name()	
	MenuCallbackHandler[callback_name] = function(_, item)
		self:set_multiple_choice_key(data.id, item:value())
	end	
	 local item = MenuHelper:AddMultipleChoice({
		id = data.id,
		title = data.title,
		desc = data.desc,
		callback = callback_name,
		items = data.items,
		value = data.value,
		menu_id = data.menu_id,
		localized = data.localized,
		priority = data.priority
	})
	
	return item
end

function CellOptionsManager:create_ghost_selector(data)
	local callback_name = "cell_ghost_track_" .. data.heist
	MenuCallbackHandler[callback_name] = MenuCallbackHandler[callback_name] or function(_, item)
		self:set_ghost_track_for_heist(data.heist, item:value())
	end	
	 local item = MenuHelper:AddMultipleChoice({
		id = data.id,
		title = data.title,
		desc = data.desc,
		callback = callback_name,
		items = data.items,
		menu_id = data.menu_id,
		localized = data.localized,
		localize_help = data.localize_help,
		priority = data.priority
	})
	return item
end


function CellOptionsManager:_setup_listeners()
	self._listener_holder = EventListenerHolder:new()	
end


function CellOptionsManager:add_listener(key, events, clbk)
	self._listener_holder:add(key, events, clbk)
end

function CellOptionsManager:remove_listener(key)
	self._listener_holder:remove(key)
end

function CellOptionsManager:call_listeners(event, params)
	self._listener_holder:call(event, params)
end

function CellOptionsManager:_setup_values()
	for index, block in pairs(managers.cell_data:wrapper("IntroDataBlock"):get_all_blocks()) do
		if block.value then
			self._mod_data.intros[block.value] = true
		end		
	end
end

function CellOptionsManager:is_default_music_track(job_id)
	local job_tweak = tweak_data.narrative.jobs[job_id]
	if job_tweak.job_wrapper then
		for _, wrapped_job in ipairs(job_tweak.job_wrapper) do
			for _, level_data in ipairs(tweak_data.narrative.jobs[wrapped_job].chain) do
				if tweak_data.levels:get_music_style(level_data.level_id) == "heist" then
					if tweak_data.levels[level_data.level_id].ghost_bonus then
						return true
					end
				end
			end
		end
	else
		for _, level_data in ipairs(job_tweak.chain) do
			if tweak_data.levels:get_music_style(level_data.level_id) == "heist" then
				if tweak_data.levels[level_data.level_id].ghost_bonus then
					return true
				end
			end
		end
	end

	return false

end


function CellOptionsManager:get_tracks_list()
	local track_list = {}
	local jobs_taken = {}

	for _, job_id in ipairs(tweak_data.narrative:get_jobs_index()) do
		local job_tweak = tweak_data.narrative:job_data(job_id)

		if self:is_default_music_track(job_id) and not jobs_taken[job_tweak.name_id] then
			--log("JOB ID - " .. tostring(job_id) .. " is a default heist!")
			local text_id, _ = tweak_data.narrative:create_job_name(job_id, true)
			local chain = tweak_data.narrative:job_chain(job_id)
			local days = #chain

			jobs_taken[job_tweak.name_id] = true
			
			if days > 1 then
				for i = 1, days do
					table.insert(track_list, {
						job_id = job_id,
						name_id = job_tweak.name_id .. "_" .. tostring(i),
						day = i,
						sort_id = text_id,
						text_id = text_id .. " - " .. managers.localization:text("menu_jukebox_heist_day", {
							day = i
						})
					})
					
				end
			else
			
				local track_data = {
					job_id = job_id,
					name_id = job_tweak.name_id,
					sort_id = text_id,
					text_id = text_id
				}
				
				table.insert(track_list, track_data)
				
			end
		else
			--log("ERROR : JOB ID - " .. tostring(job_id) .. " is not a default heist!")
		end
		
	end
	
	
	table.sort(track_list, function (x, y)
		return x.sort_id == y.sort_id and x.text_id < y.text_id or x.sort_id < y.sort_id
	end)
	
	return track_list
end

function CellOptionsManager:_setup_menus()
	self._project_cell_menu = MenuHelper:GetMenu( "project_cell" )
	self._project_cell_ghost_menu = MenuHelper:GetMenu( "project_cell_ghost_tracks" )
end


function CellOptionsManager:_setup_menu_nodes()

	for index, block in pairs(self._menu_item_blocks) do
		local new_item = nil
		if block.Type == CellOptionsManager.MENU_ITEM_TYPE.TOGGLE then
			
			new_item = self:create_toggle_item({
				id = block.name,
				title = block.Title,
				desc = block.Description,
				priority = block.Priority,
				menu_id = "project_cell",
				value = false,
				show_value = block.ShowValue,
				localized = true,
				disabled = false			
			})
			
			self._mod_data.toggles[block.name] = new_item
		elseif block.Type == CellOptionsManager.MENU_ITEM_TYPE.SLIDER then
			new_item = self:create_slider_item({
				id = block.name,
				title = block.Title,
				desc = block.Description,
				value = block.Min,
				min = block.Min or 0,
				max = block.Max or 1,
				step = block.Step or 0.01,
				show_value = block.ShowValue,
				menu_id = "project_cell",
				priority = block.Priority,
				disabled = false
			})
			
			self._mod_data.sliders[block.name] = new_item
		elseif block.Type == CellOptionsManager.MENU_ITEM_TYPE.DIVIDER then
			new_item = self:create_divider_item({
				id = block.name,
				size = block.Size,
				priority = block.Priority
			})				
		end
		
		if new_item then
			self._project_cell_menu:add_item(new_item)
		end
	end
	
	

	
	if CellOptionsManager.ALLOW_STEALTH_TRACKS then	
		
		local block = managers.cell_data:wrapper("MenuItemDataBlock"):get_block_by_name("project_cell_suspense_choice")
	
		local suspense_music_items = {"project_cell_suspense_track_none", "project_cell_suspense_track_heist_specific"}
		
		for _, track_data in pairs(tweak_data.music.track_ghost_list) do
			table.insert(suspense_music_items, "menu_jukebox_screen_" .. track_data.track)
		end	 
		
		if block then
			
		
			local new_item = self:create_multiple_choice_item({
				id = block.name,
				title = block.Title,
				desc = block.Description,
				value = 1,
				items = suspense_music_items,
				show_value = true,
				menu_id = "project_cell",
				priority = block.Priority
			})
			
			if new_item then
				self._mod_data.multiple_choice_keys[block.name] = new_item
				self._project_cell_menu:add_item(new_item)
			end
		end
	
	
		local cloned_suspense_music_items = deep_clone(suspense_music_items)	
		table.remove(cloned_suspense_music_items, 2)

		
		for i, track_data in pairs(self:get_tracks_list()) do
			local item = self:create_ghost_selector({
				id = "project_cell_ghost_track_" .. track_data.name_id,
				heist = track_data.name_id,
				title = track_data.text_id,
				desc = managers.localization:text("project_cell_heist_suspense_choice_desc"),
				value = 1,
				items = cloned_suspense_music_items,
				show_value = true,
				menu_id = "project_cell_ghost_tracks",
				localized = false,
				localize_help = "true",
				priority = i * -1
			})
			
			self._mod_data.ghost_tracks[track_data.name_id] = item	
			self._project_cell_ghost_menu:add_item(item)
		end
		
		local item = MenuHelper:AddButton({
			id = "project_cell_ghost_track_selector",
			title = "project_cell_ghost_track_selector_title",
			desc = "project_cell_ghost_track_selector_title",
			callback = "callback_ghost_track_chooser",
			back_callback = callback(self,self,"callback_exit_menu"),
			menu_id = "project_cell",
			priority = -100
		})	

		self._project_cell_menu:add_item(item)
	end

end


function CellOptionsManager:_old_projects_detected()
	for name, item in pairs(CellHooks.MenuItems.Toggles) do
		item:set_value("off")
		item:set_enabled(false)
	end	
	for name, item in pairs(CellHooks.MenuItems.Sliders) do
		item:set_enabled(false)
	end	
end


function CellOptionsManager:get_save_data()
	local save_data = self:get_default_data()	
	
	for value_name, _ in pairs(self._mod_data.toggles) do
		save_data.toggles[value_name] = self:has_toggled(value_name)
	end	
	
	for slider_name, _ in pairs(self._mod_data.sliders) do
		save_data.sliders[slider_name] = self:slider_value(slider_name)
	end	
	
	for index, block in pairs(managers.cell_data:wrapper("IntroDataBlock"):get_all_blocks()) do
		if block.value then
			save_data.intros[block.value] = self:has_seen_intro(block.value)
		end		
	end	
	
	for multiple_choice_name, _ in pairs(self._mod_data.multiple_choice_keys) do
		save_data.multiple_choice_keys[multiple_choice_name] = self:multiple_choice_by_key(multiple_choice_name)
	end	
	
    for heist, _ in pairs(self._mod_data.ghost_tracks) do
		save_data.ghost_tracks[heist] = self:ghost_track_index_by_heist(heist)
	end
	
	return save_data
end


function CellOptionsManager:save_user_settings()
	local save_data = self:get_save_data()
	local file = io.open( self._save_path, "w+" )
	if file then
		local json_string = JsonUtils:safe_encode( save_data )		
		file:write(json_string)
		file:close()		
		self:debug_print("Saved user data to path -> " .. self._save_path)
	end
end

function CellOptionsManager:callback_exit_menu()

	if managers.cell_user and managers.cell_user:has_local_peer() then
		managers.cell_user:local_user():send_cell_values_to_peers()
	end		
	
	if managers.cell_music then
		managers.cell_music:on_stop_listening()
	end
	
	log("stop listening!!")
end

function CellOptionsManager:_load_user_settings()
	local file = io.open( self._save_path, "r" )
	if file then	
		local json_string = file:read("*all")
		self._user_data = JsonUtils:safe_decode(json_string or {}) or {}		
		file:close()
		self:debug_print("Cell user data succefully loaded.")		
	else
		self:debug_print("Cell user data didn't exist, creating a new one.")		
	end
	self:clean_load_settings()
end

function CellOptionsManager:clean_load_settings()
	local clean_save = false
	if not self._user_data or type(self._user_data) ~= "table" then
		clean_save = true
		self._user_data = {}
		self:debug_print("ERROR : user data is corrupted, cleaning it up!!")	
	end
	if not self._user_data.toggles or type(self._user_data.toggles) ~= "table" then
		clean_save = true
		self._user_data.toggles = {}
		self:debug_print("ERROR : user data for toggles is corrupted!!, cleaning it up!!")	
	end
	if not self._user_data.sliders or type(self._user_data.sliders) ~= "table" then
		clean_save = true
		self._user_data.sliders = {}
		self:debug_print("ERROR : user data for sliders is corrupted!!, cleaning it up!!")	
	end
	
	if not self._user_data.intros or type(self._user_data.intros) ~= "table" then
		clean_save = true
		self._user_data.intros = {}
		self:debug_print("ERROR : user data for intros is corrupted!!, cleaning it up!!")	
	end
	
	if not self._user_data.multiple_choice_keys or type(self._user_data.multiple_choice_keys) ~= "table" then
		clean_save = true
		self._user_data.multiple_choice_keys = {}
		self:debug_print("ERROR : user data for multiple_choice_keys is corrupted!!, cleaning it up!!")	
	end
	
	if not self._user_data.ghost_tracks or type(self._user_data.ghost_tracks) ~= "table" then
		clean_save = true
		self._user_data.ghost_tracks = {}
		self:debug_print("ERROR : user data for ghost_tracks is corrupted!!, cleaning it up!!")	
	end
	
	if clean_save then
		self:save_user_settings()
	end	
end

function CellOptionsManager:_set_items_status()
	for value_name, item in pairs(self._mod_data.toggles) do
		item:set_value(self:has_toggled(value_name) and "on" or "off")
	end	
	
	for value_name, item in pairs(self._mod_data.sliders) do		
		item:set_value(self:slider_value(value_name))
	end	
	
	for value_name, item in pairs(self._mod_data.multiple_choice_keys) do
		item:set_value(self:multiple_choice_by_key(value_name))
	end	
	
	for heist, item in pairs(self._mod_data.ghost_tracks) do
		item:set_value(self:ghost_track_index_by_heist(heist))
	end	
end

function CellOptionsManager:send_user_changes()
	if managers.cell_user then
		managers.cell_user:send_local_cell_values_to_peers()
	end		
end

function CellOptionsManager:query_user_changes()	
	if C_Global:ingame() and not Global.game_settings.single_player then
		managers.cell_callback:add_delayed_callback("CellOptionsManager.send_user_changes", 1, callback(self, self, "send_user_changes"))
	end
end


function CellOptionsManager:set_toggle_value(value_name, enabled, sync)
	if not value_name or type(value_name) ~= "string" then
		return
	end
	
	if type(enabled) ~= "boolean" then
		return
	end
	
	if not self._mod_data.toggles[value_name] then
		self:debug_print("ERROR : toggle name " .. tostring(value_name) .. " is invalid!")
		return
	end
	
	self._user_data.toggles[value_name] = enabled
	
	self:debug_print("Now setting toggle " .. tostring(value_name) .. " : " .. tostring(enabled))
	self:call_listeners("CellOptionsManager.Toggle", {value_name = value_name, enabled = enabled})	
	self:save_user_settings()
	if sync then
		self:query_user_changes()
	end
end

function CellOptionsManager:has_toggled(value_name)
	return self._user_data.toggles[value_name] and true or false
end

function CellOptionsManager:slider_value(slider_name)
	return self._user_data.sliders[slider_name] or 0
end

function CellOptionsManager:set_slider_value(slider_name, value, sync)
	if not slider_name or type(slider_name) ~= "string" then
		return
	end
	
	if not value or type(value) ~= "number" then
		return
	end
	
	if not self._mod_data.sliders[slider_name]  then
		self:debug_print("ERROR : slider name " .. tostring(slider_name) .. " is invalid!")
		return
	end
	
	self._user_data.sliders[slider_name] = value
	self:save_user_settings()	
	if sync then
		self:query_user_changes()
	end
end

function CellOptionsManager:set_multiple_choice_key(itemKey, value)
	if not itemKey or type(itemKey) ~= "string" then
		return
	end
	
	if not value or type(value) ~= "number" then
		return
	end
	
	if not self._mod_data.multiple_choice_keys[itemKey] then
		self:debug_print("ERROR : itemKey " .. tostring(itemKey) .. " is invalid!")
		return
	end
	
	self:debug_print("Now setting itemKey " .. tostring(itemKey) .. " -> " ..tostring(value))
	self._user_data.multiple_choice_keys[itemKey] = value
	
	self:call_listeners("CellOptionsManager.MultipleChoice", {itemKey = itemKey, choice_index = value})	
	self:save_user_settings()
end

function CellOptionsManager:set_ghost_track_for_heist(heist, ghost_track_index)
	if not heist or type(heist) ~= "string" then
		return
	end
	
	if not ghost_track_index or type(ghost_track_index) ~= "number" then
		return
	end	

	
	self:debug_print("Now setting ghost track\nheist : " .. tostring(heist) .. "\nghost_track_index : " .. tostring(ghost_track_index))
	self._user_data.ghost_tracks[heist] = ghost_track_index
	

	self:call_listeners("CellOptionsManager.GhostTrackIndex", {heist = heist, ghost_track_index = ghost_track_index})	
	self:save_user_settings()
end

function CellOptionsManager:set_intro_seen(intro_name, enabled)
	if not intro_name or type(intro_name) ~= "string" then
		return
	end
	
	if type(enabled) ~= "boolean" then
		return
	end
	
	if not self._mod_data.intros[intro_name] then
		self:debug_print("ERROR : intro name " .. tostring(intro_name) .. " is invalid!")
		return
	end
	
	
	self:debug_print("Now setting intro seen " .. tostring(intro_name) .. " -> " ..tostring(enabled))
	self._user_data.intros[intro_name] = enabled
	self:save_user_settings()
end

function CellOptionsManager:has_seen_intro(intro_name)
	return self._user_data.intros[intro_name] and true or false
end

function CellOptionsManager:multiple_choice_by_key(itemKey)
	return self._user_data.multiple_choice_keys[itemKey] or 1
end

function CellOptionsManager:ghost_track_index_by_heist(name_id)
	return self._user_data.ghost_tracks[name_id] or 1
end

function CellOptionsManager:on_menu_entered()
	if self._menu_entered then
		return
	end
	
	self._menu_entered = true
	if SoundDevice then
		SoundDevice:set_state("wave_flag", "assault")
		SoundDevice:set_state("acoustic_flag", "acoustic_flat")
	end
	
	blt.xaudio.setup()	
	
	local music_intro_played = false
	CellHooks.IntroShowed = true
	
	local menu_options = {
		[1] = {
			text = "Okay!",
			callback = function()
				CellGlobal:log("Stop music!!")				
			end,
			is_cancel_button = true
		}
	}
	
	local user_data_block = managers.cell_data:wrapper("UserDataBlock"):get_block_by_id(CD.User.Default)
	if user_data_block then
		local block = managers.cell_data:wrapper("IntroDataBlock"):get_block_by_id(user_data_block.IntroductionID)		
		if block then
			if not block.Ignore and (block.Forced or not self:has_seen_intro(block.value)) then
				QuickMenu:new(managers.localization:text(block.IntroTitle), managers.localization:text(block.IntroDesc, {CELL_USER = managers.network.account:username_id()}), menu_options, true)		
				if block.MusicEvent and block.MusicEvent ~= "" then
					music_intro_played = true	
				end
				
				self:set_intro_seen(block.value, true)
			end	

			if self:is_obsolete_projects_present() then
				self:_old_projects_detected()
				QuickMenu:new(managers.localization:text("project_cell_obsolete_deadlocke_title"), managers.localization:text("project_cell_obsolete_deadlocke_desc"), menu_options, true)	
			end
		end		
	end
end
