CellMenuMusicManager = CellMenuMusicManager or blt_class(CellMusicManager)
CellMenuMusicManager.PREVIEW_STEALTH_TRACKS = false

function CellMenuMusicManager:setup()
	self:_setup_stealth_tracks()
end

function CellMenuMusicManager:on_stealth_track_changed()
	--[[local track = self:current_stealth_track()
	if track == nil or track == "heist_specific" then
		self:on_stop_listening()
		return
	end
	self:start_listening(track)]]
end

function CellMenuMusicManager:on_stop_listening()
	if self._listening then
		self._listening = false
		managers.music:music_ext_listen_stop()
		managers.music:post_event("stop_all_music")
		managers.music:post_event(managers.music:jukebox_menu_track("mainmenu"))
	end	
end

function CellMenuMusicManager:start_listening(track)
	if CellMenuMusicManager.PREVIEW_STEALTH_TRACKS then
		self._listening = true
		managers.music:music_ext_listen_start(track)
	end
end

function CellMenuMusicManager:on_heist_ghost_index_select(data)
	local track = self:get_ghost_track_by_index(data.ghost_track_index)
	if track == nil then
		self:on_stop_listening()
		return
	end
	self:start_listening(track)
end