CellPagerManager = CellPagerManager or blt_class(CellManagerBase)

function CellPagerManager:setup()
	self._pager_count = 0
	self._pager_keys = {}
end

function CellPagerManager:pager_dialog(line)
	if managers.dialog and managers.groupai and managers.groupai:state():bain_state() then
		if managers.cell_options:has_toggled("project_cell_narrator_pager_tog") then
			managers.dialog:queue_narrator_dialog(line, {})
		end		
	end
end


function CellPagerManager:on_pager_answered(counter)
	local line
	
	if counter == 1 then
		line = "pager_b"
	elseif counter == 2 then
		line = "pager_d"
		if math.random() < 0.35 then
			line = "pager_e"
		end
	elseif counter == 3 then
		line = "pager_f"
	elseif counter == 4 then
		line = "pager_g"
	elseif counter >= 5 then
		line = "pager_h"
	end
	
	if line then
		managers.cell_callback:add_delayed_callback("CellPagerManager_pager_answered_"..tostring(count), 2, callback(self,self,"pager_dialog",line))		
	end
	
end


function CellPagerManager:inform_pager_contact(urgent)
	local t = Application:time()	
	if self._informTimer and self._informTimer + 6 > t then
		return
	end	
	self._informTimer = t
	managers.cell_callback:add_delayed_callback("CellPagerManager_pager_contact_urgent_"..tostring(urgent), 1, callback(self,self,"pager_dialog",urgent and "pat_05" or "pager_a"))
end

function CellPagerManager:set_pager_counter(u_key)
	if self._pager_keys[u_key] then
		return
	end
	
	self._pager_count = self._pager_count + 1
	
	self._pager_keys[u_key] = {}
	self._pager_keys[u_key].answered = false
	self._pager_keys[u_key].pager_count = self._pager_count
	self._pager_keys[u_key].on_pager_answered_clbk = callback(self, self, "on_pager_answered", self._pager_count)
	
	managers.cell_music:call_listeners("on_pager_call", self._pager_count)
end

function CellPagerManager:on_loaded_pagers(pagers_amount)
	self._pager_count = pagers_amount
	managers.cell_music:call_listeners("on_pager_call", pagers_amount)
end

function CellPagerManager:pager_count()
	return self._pager_count
end



function CellPagerManager:on_pager_interaction_complete(u_key)
	if not self._pager_keys[u_key] then
		return
	end	

	
	if self._pager_keys[u_key].answered then
		return
	end
	
	
	self._pager_keys[u_key].answered = true
	
	if self._pager_keys[u_key].pager_count == self._pager_count then
		self._pager_keys[u_key].on_pager_answered_clbk()
	end	
end