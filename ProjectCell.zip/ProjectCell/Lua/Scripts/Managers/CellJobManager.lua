CellJobManager = CellJobManager or blt_class(CellManagerBase)

function CellJobManager:setup()
	self._is_chill_heist = self:current_level_name_id() == "heist_chill"
end

function CellJobManager:current_level_name_id()
	local current_level_name_id = nil
	local current_job_data = managers.job:current_job_data()
	if current_job_data then
		local days = #managers.job:current_job_chain_data()
		current_level_name_id = current_job_data.name_id
		if current_level_name_id then
			if days and days > 1 then
				current_level_name_id = current_level_name_id .. "_" .. managers.job:current_stage()
			end	
		end
	end		
	return current_level_name_id
end

function CellJobManager:is_last_stage()
	return #managers.job:current_job_chain_data() == managers.job:current_stage()
end


function CellJobManager:is_chill_heist()
	return self._is_chill_heist
end