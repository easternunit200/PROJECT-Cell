CellModManager = CellModManager or blt_class(CellManagerBase)

function CellModManager:setup()
	self._mod = BLT.Mods:GetModByName("PROJECT: Cell")	
end

function CellModManager:mod_version()
	return self._mod:GetVersion()
end