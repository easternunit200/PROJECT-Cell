PlayerVoiceManager = PlayerVoiceManager or blt_class(CellManagerBase)
function PlayerVoiceManager:setup()
	blt.xaudio.setup()
	self._voices = {}
	self._interactionExt = nil
	self._voices_by_character = {}
	self:setup_listener()	
end

function PlayerVoiceManager:setup_listener()
	self._criminal_added_key = "PlayerVoiceManager_CriminalAdded"
	self._criminal_removed_key = "PlayerVoiceManager_CriminalRemove"
	managers.criminals:add_listener(self._criminal_added_key, {"on_criminal_added"}, callback(self, self, "on_criminal_added"))		
end

function PlayerVoiceManager:get_modified_interaction(interaction_type)
	return self._interactionExt:get_modified_interaction(interaction_type)
end

function PlayerVoiceManager:setup_interation_ext(unit)
	self._interactionExt = PlayerVoiceInteractionExt:new(unit)
end

function PlayerVoiceManager:on_criminal_added(name, unit, peer_id, ai)
	if unit == nil then
		unit = managers.criminals:character_unit_by_name(name)
	end
	
	if unit == nil then
		self:debug_print("ERROR : No unit for the character : " .. tostring(name))
		return
	end
	
	
	--[[local key = unit:key()
	local new_voice = PlayerVoice:new(unit)
	self._voices[key] = new_voice
	self._voices_by_character[name] = new_voice]]
	
	if unit == managers.player:player_unit() then
		self:setup_interation_ext(unit)	
	end
end
