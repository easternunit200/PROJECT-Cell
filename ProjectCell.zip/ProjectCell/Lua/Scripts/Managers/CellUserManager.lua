dofile(ModPath.."Lua/Scripts/CellUsers/LocalCellUser.lua")
dofile(ModPath.."Lua/Scripts/CellUsers/HuskCellUser.lua")

CellUserManager = CellUserManager or blt_class(CellManagerBase)
function CellUserManager:setup()
	self._users = {}
	self._user_joined_callbacks = {}
	self._user_left_callbacks = {}
	self._cell_host_callbacks = {}
	self._is_local_peer_dirty = false
	self._local_dirty_peer = nil
	self._local_user = nil
	self._has_local_peer = false
	self._queue_request = false
	self._beginner = false
	self._dirty_peer_goal_register_timer = 1
	self._pending_peer_ids = {}
	self._handshakes_peer_ids = {}
	self:_setup_cell_net_validations()	
end

function CellUserManager:_setup_cell_net_validations()
	self._net_action = CellNetValidationAction:new("User", callback(self,self,"do_sync_cell_values"))	
	self._verify_action = CellNetValidationAction:new("Vali", callback(self,self,"do_validation"))	
	self._received_action = CellNetValidationAction:new("Regi", callback(self,self,"do_register"))	
	
	self:add_left_callback(callback(self,self,"delete_pending_peer_id"))
end

function CellUserManager:delete_pending_peer_id(peer_id)
	self._pending_peer_ids[peer_id] = nil
	self._handshakes_peer_ids[peer_id] = nil
end


function CellUserManager:add_pending_peer_id(peer_id, saved_data, handshake_pended)
	if not self._pending_peer_ids[peer_id] then		
		self._pending_peer_ids[peer_id] = saved_data
	end
	
	if handshake_pended then
		self:debug_print("adding a yet to be handshaked peer id " .. tostring(peer_id))
		self._handshakes_peer_ids[peer_id] = true
	else
		self:debug_print("adding a pending peer id " .. tostring(peer_id))
	end
end


function CellUserManager:get_best_canditate(toggle_name, include_bots, bot_toggle_name)
	local handler = WeightHandler:new()
	for id, cell_user in pairs(self:all_cell_users()) do
		local user_weight = 0.5				
		if toggle_name then
			if managers.cell_options:is_slider(toggle_name) then
				user_weight = cell_user:slider_value(toggle_name)	
			elseif managers.cell_options:is_toggle(toggle_name) then
				if not cell_user:has_toggled(toggle_name) then
					user_weight = 0	
				end
			end					
		end		
		local user_unit = cell_user:unit()
		if user_unit and alive(user_unit) and user_weight ~= 0 then
			handler:add_value(user_unit, user_weight)
		end	
	end	
	
	if Network:is_server() and include_bots and bot_toggle_name then
		local bot_weight = managers.cell_options:slider_value(bot_toggle_name)
		if bot_weight > 0 then
		
			local bots = {}
			for u_key, u_data in pairs(managers.groupai:state():all_AI_criminals()) do
				if u_data.unit and alive(u_data.unit) and not u_data.unit:movement():downed() then
					table.insert(bots, u_data.unit)
				end
			end
			
			if next(bots) then
				local random_index = math.random(1, #bots)
				handler:add_value(bots[random_index], bot_weight)
			end
			
		end
	end
	
	if handler:has_any() then
		return handler:get_best_value().value
	end
	
	return nil
end


function CellUserManager:do_validation(data, sender_id)
	if not self:has_local_peer() then
		self:debug_print("Tried to register a cell user without local_peer setup! Adding pending peer id " .. tostring(sender_id))
		self:add_pending_peer_id(sender_id, data, true)
		return
	end
	self:do_register(data, sender_id)
	self:send_handshake(sender_id)
end

function CellUserManager:do_register(data, sender_id)
	if self:is_peer_registered(sender_id) then
		self:debug_print("Sender ID " .. tostring(sender_id) .. " has been registered already!")
		return
	end
	
	local current_version = managers.cell_network:version()
	if data.v ~= current_version then
		self:debug_print("Cell User's version mismatch! Current Version : " .. tostring(current_version) .. " Cell User's Version : " .. tostring(data.v))
		return
	end	
	

	if not managers.network or not managers.network.session or not managers.network:session() then
		self:debug_print("Tried to register a cell user without managers.network:session() setup! Adding pending peer id " .. tostring(sender_id))
		self:add_pending_peer_id(sender_id, data, false)
		return
	end
	
	if managers.network:session():peer(sender_id) == nil then
		self:debug_print("Peer id " .. tostring(sender_id) .. " is trying to be registered, but the peer is returning nil! Pending this specific peer id...")
		self:add_pending_peer_id(sender_id, data, false)
		return
	end
	
	
	local new_cell_user = self:register_user_peer_id(sender_id, data.b and true or false)	
	if new_cell_user then
		if data.c then
			new_cell_user:sync_cell_values(data.c)	
		end
	end	

	
end

function CellUserManager:get_entry_data()
	local data = {}	
	data.b = self._beginner and true or false	
	data.c = self._local_user:get_cell_values_data()
	data.v = managers.cell_network:version()
	return data
end

function CellUserManager:send_request()
	self._verify_action:send_to_peers(self:get_entry_data())	
end

function CellUserManager:send_handshake(peer_id)	
	self._received_action:send_to_peer(peer_id, self:get_entry_data())	
end

function CellUserManager:net_action()
	return self._net_action
end


function CellUserManager:send_local_cell_values_to_peers()
	if not self._has_local_peer then
		return
	end
	
	self._net_action:send_to_peers(self._local_user:get_cell_values_data())
end

function CellUserManager:send_local_cell_values_to_peer(peer_id)
	if not self._has_local_peer then
		return
	end
	
	self._net_action:send_to_peer(peer_id, self._local_user:get_cell_values_data())
end


function CellUserManager:get_cell_user_by_peer_id(peer_id)
	return self._users[peer_id]
end

function CellUserManager:all_cell_users()
	return self._users
end

function CellUserManager:get_cell_user_by_unit(unit)
	for id, cell_user in pairs(self._users) do
		if cell_user:unit() == unit then
			return cell_user
		end
	end	
	return nil
end

function CellUserManager:get_cell_user_by_character(character)
	for id, cell_user in pairs(self._users) do
		if cell_user:character_name() == character then
			return cell_user
		end
	end
	
	return nil
end

function CellUserManager:do_sync_cell_values(data, sender)
	local cell_user = self._users[sender] 
	
	if not cell_user then
		self:debug_print("ERROR : Peer id " .. tostring(sender) .. " is not registered as a cell user!!")
		return
	end
	
	cell_user:sync_cell_values(data)	
end


function CellUserManager:attempt_to_send_request()
	if self._has_local_peer then
		self:send_request()
		return
	end	
	self:queue_request()
end

function CellUserManager:update_queue_request()
	if not self._queue_request then
		return
	end
	
	if not self._has_local_peer then
		return
	end
	
	self:debug_print("Request sent, via queueing...")	
	self:send_request()	
	self._queue_request = false
end

function CellUserManager:queue_request()
	self:debug_print("[BaseNetworkSession:on_load_complete] Tried to send a request to peers without a local peer, queueing the request..")
	self._queue_request = true
end

function CellUserManager:update(t,dt)
	self:update_dirty_local_peer(t,dt)
	self:update_queue_request()
	self:update_pending_peer_ids()
end



function CellUserManager:update_pending_peer_ids()
	if not managers.network or not managers.network.session or not managers.network:session() then
		return
	end
	
	if not self:has_local_peer() then
		return
	end	
	
	if not next(self._pending_peer_ids) then
		return
	end	
	
	for peer_id, user_data in pairs(self._pending_peer_ids) do
		local peer = managers.network:session():peer(peer_id)			
		if peer ~= nil then
			local handshake_pended = self._handshakes_peer_ids[peer_id]			
			self:delete_pending_peer_id(peer_id)
			self:do_register(user_data, peer_id)	
			if handshake_pended then
				self:send_handshake(peer_id)
				self:debug_print("Registered after managers.network has been setup for peer id " .. tostring(peer_id) .. " and handshaked!")	
			else
				self:debug_print("Registered after managers.network has been setup for peer id " .. tostring(peer_id))	
			end
					
		end
	end
	
end

function CellUserManager:register_user_peer_id(peer_id, is_beginner)	
	return self:register_user(managers.network:session():peer(peer_id), false, is_beginner)
end

function CellUserManager:is_peer_registered(peer_id)
	return self._users[peer_id] and true or false
end

function CellUserManager:set_beginner(enable)
	self._beginner = enable
	for i, user in pairs(self._users) do
		if user then
			user:start_from_beginning()
		end		
	end
end

function CellUserManager:is_beginner()
	return self._beginner
end

function CellUserManager:update_dirty_local_peer(t,dt)
	if self._local_dirty_peer == nil then
		return
	end	
	
	
	if self._local_dirty_peer:id() > 0 then
		self._dirty_peer_goal_register_timer = self._dirty_peer_goal_register_timer - dt		
		if self._dirty_peer_goal_register_timer <= 0 then
			self:register_user(self._local_dirty_peer, true, false)
			self._local_dirty_peer = nil
		end		
	end
end


function CellUserManager:register_local_peer(peer)
	if peer:id() <= 0 then
		self:debug_print("Queuing local dirty peer : " .. tostring(peer:name()))
		self._local_dirty_peer = peer
	else
		self:register_user(peer, true, false)
	end
end

function CellUserManager:register_user(peer, is_local, is_beginner)
	is_beginner = is_beginner and true or false
	local peer_id = peer:id()
	local new_user
	if is_local then
		new_user = LocalCellUser:new(peer)
		self._local_user = new_user		
		self._has_local_peer = true
		self:debug_print("Registered Local CellUser : " .. peer:name() .. " with peer id " .. tostring(peer_id) .. " is beginner " .. tostring(is_beginner))
	else
		new_user = HuskCellUser:new(peer)
		self:debug_print("Registered Husk CellUser : " .. peer:name() .. " with peer id " .. tostring(peer_id) .. " is beginner " .. tostring(is_beginner))
	end
	
	if is_beginner then
		new_user:start_from_beginning()
	end	
	
	self._users[peer_id] = new_user
	
	self:on_peer_joined(peer_id)
	
	self:determine_cell_host()
	
	return new_user
end

function CellUserManager:local_user()
	return self._local_user
end

function CellUserManager:local_peer_id()
	return self._local_user:peer_id()
end

function CellUserManager:add_join_callback(clbk)
	table.insert(self._user_joined_callbacks, clbk)
end

function CellUserManager:add_left_callback(clbk)
	table.insert(self._user_left_callbacks, clbk)
end

function CellUserManager:add_cell_host_callback(clbk)
	table.insert(self._cell_host_callbacks, clbk)
end

function CellUserManager:on_peer_joined(peer_id)
	for _, clbk in pairs(self._user_joined_callbacks) do
		if clbk then
			clbk(peer_id)
		end
	end
end

function CellUserManager:on_peer_left(peer_id)
	for _, clbk in pairs(self._user_left_callbacks) do
		if clbk then
			clbk(peer_id)
		end
	end
end

function CellUserManager:on_cell_host(enabled)
	for _, clbk in pairs(self._cell_host_callbacks) do
		if clbk then
			clbk(enabled)
		end
	end
end

function CellUserManager:unregister_user(peer_id)
	self:debug_print("Unregisterd user with the peer_id "..tostring(peer_id))
	if self._users[peer_id] then
		self._users[peer_id]:destroy()
	end
	self._users[peer_id] = nil	
	self:on_peer_left(peer_id)
	self:determine_cell_host()
end

function CellUserManager:get_priority_user(check_beginner)
	local priority_user_id, priority_user
	for i, user in pairs(self._users) do
		if user then
			if not priority_user or priority_user_id > user:peer_id() then
				local is_beginner = user:has_started_from_beginning()
				if not check_beginner or is_beginner then
					priority_user = user
					priority_user_id = user:peer_id()
					has_beginner = check_beginner and is_beginner
				end					
			end
		end		
	end
	
	return priority_user
end

function CellUserManager:determine_cell_host()
	self._cell_host = nil

	local priority_user = self:get_priority_user(true)	
	if not priority_user then
		priority_user = self:get_priority_user(false)
	end
	
	if not priority_user then
		self:debug_print("No priority user found to be cell host!")
		return
	end
	
	self._cell_host = priority_user	
	
	local is_cell_host_local = self._cell_host:is_local_user()
	
	self:on_cell_host(is_cell_host_local)	
	
	if is_cell_host_local then
		if self._cell_host:has_started_from_beginning() then
			self:debug_print("Local user is now Cell Host, that has started from the beginning")
		else
			self:debug_print("Local user is now Cell Host")
		end
		
	else
		if self._cell_host:has_started_from_beginning() then
			self:debug_print("Husk user by the name of "..self._cell_host:name().. " is now the Cell Host, that has started from the beginning")
		else
			self:debug_print("Husk user by the name of "..self._cell_host:name().. " is now the Cell Host")
		end
		
	end
end

function CellUserManager:is_cell_host()
	return self._cell_host and self._cell_host:is_local_user() and true or false
end

function CellUserManager:has_cell_host()
	return self._cell_host and true or false
end


function CellUserManager:is_another_user_host_and_master()
	if self:is_cell_host() then
		return false
	end
	
	if self:cell_host_peer_id() ~= 1 then
		return false
	end
	
	return true
end

function CellUserManager:cell_host_peer_id()
	return self._cell_host:peer_id()
end

function CellUserManager:has_local_peer()
	return self._has_local_peer
end