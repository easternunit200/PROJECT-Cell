CellSoundManager = CellSoundManager or blt_class(CellManagerBase)

function CellSoundManager:setup()
	self:_setup_cell_sound_builder()
end

function CellSoundManager:on_session_destroyed()
end

function CellSoundManager:destroy_all_players()
end

function CellSoundManager:stop_all_players()
end

function CellSoundManager:_setup_cell_sound_builder()
end

function CellSoundManager:set_editor_enabled()
end

function CellSoundManager:set_editor_disabled()
end

function CellSoundManager:save_all_data()
end