CellNetworkManager = CellNetworkManager or blt_class(CellManagerBase)
CellNetworkManager.DEBUG_ENABLED = true

function CellNetworkManager:setup()
	self._network_id = "ProjCell"	
	self._action_validations = {}
end

function CellNetworkManager:post_setup()
	self._network_version = managers.cell_mod:mod_version()
end

function CellNetworkManager:version()
	return self._network_version
end

function CellNetworkManager:network_id()
	return self._network_id
end


function CellNetworkManager:network_receive_data(sender_peer_id, message_id, data)
	if message_id == self._network_id then
		self:execute_packet_action(sender_peer_id, data)	
	end	
end


function CellNetworkManager:test_network_received_self(message_id, data)
	local str = JsonUtils:safe_encode(data)
	self:network_receive_data(managers.cell_user:local_peer_id(), message_id, str)
end

function CellNetworkManager:unregister_action_validation(validation)
	local packet_id = validation:packet_id()
	if not self._action_validations[packet_id] then	
		self:debug_print("ERROR : packet_id already unregistered : " .. tostring(packet_id))
		return
	end
	
	self:debug_print("Unregistering a packet validator : " ..packet_id)
	
	self._action_validations[packet_id] = nil
	validation:set_active(false)
end


function CellNetworkManager:register_action_validation(validation)
	local packet_id = validation:packet_id()
	if self._action_validations[packet_id] then	
		self:debug_print("ERROR : packet_id already registered : " .. tostring(packet_id))
		return
	end
	
	self:debug_print("Registering a packet validator : " ..packet_id)
	
	self._action_validations[packet_id] = validation
	
	validation:set_active(true)
end

function CellNetworkManager:execute_packet_action(sender_peer_id, str)
	local data = JsonUtils:safe_decode(str)
	
	if not data then
		return
	end
	
	if data[1] == nil or type(data[1]) ~= "string" then
		self:debug_print("No packet id specified from peer id : " .. tostring(sender_peer_id))
		return
	end
	
	if data[2] == nil then
		self:debug_print("packet has returned nil from peer id : " .. tostring(sender_peer_id))
		return
	end	
	
	local validation = self._action_validations[data[1]]
	if validation then
		validation:sync_execute(data[2], sender_peer_id)
	end
end