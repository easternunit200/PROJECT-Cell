CellGlobalManager = CellGlobalManager or blt_class(CellManagerBase)
function CellGlobalManager:is_enabled(category, name)
	return false
end