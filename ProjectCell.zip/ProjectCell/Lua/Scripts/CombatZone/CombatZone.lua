CombatZone = CombatZone or blt_class()
CombatZone.MEDIUM = "medium"
CombatZone.HIGH = "high"


function CombatZone:init(pos, t)
	self._position = pos
	self._range = 1500	
	self._created_time = t
end


function CombatZone:is_in_combatZone(pos)
	local distance = mvector3.distance_sq(self._pos, pos)
	
	if distance * distance < self._range  then
		return true	
	end	
	
	return false
end


function CombatZone:is_sighted(to)
	return managers.cell_world:in_sight(self._position, to)
end

