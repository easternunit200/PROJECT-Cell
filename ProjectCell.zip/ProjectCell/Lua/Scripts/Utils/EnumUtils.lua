EnumUtils = EnumUtils or blt_class()

function EnumUtils:init()
	self._values = {}
end

function EnumUtils:register_enum(name)
	if self._values[name] then
		error("Enum value " .. tostring(name) .. " is already registered!")
	end
	self._values[name] = EnumGroup:new()
	return self._values[name]
end  


EnumGroup = EnumGroup or blt_class()

function EnumGroup:init()
	self._values = {}
	self._last_enum_id = -1
end

function EnumGroup:add_value(name, index)
	if index ~= nil then
		self._last_enum_id = math.max(index, self._last_enum_id)
		self._values[name] = index	
	else
		self._last_enum_id = self._last_enum_id + 1
		self._values[name] = self._last_enum_id	
	end	
end

function EnumGroup:get_value(name)
	return self._values[name]
end

EnumList = EnumList or blt_class()

function EnumList:init(t)
	self._items = {}
	self:create_items(t)
end

function EnumList:create_items(t)		
	for i, name in pairs(t) do		
		self._items[i - 1] = name
	end
end

function EnumList:get_drop_down_list()
	local dropDownList = {}
	for i = 1, #self._items + 1 do
		dropDownList[i] = (i - 1) .. " : " .. self._items[i - 1]
	end
	
	return dropDownList
end

function EnumList:get_value(index)
	return self._items[index]
end