CellManagerBase = CellManagerBase or blt_class()

function CellManagerBase:init()
	self._t = 0
	self._dt = 0
	self._class_name = "CellManagerBase"
	self._manager_name = "unknown"
	self._in_menu = false
end

function CellManagerBase:setup()	
end


function CellManagerBase:post_setup()
end

function CellManagerBase:update(t,dt)
end

function CellManagerBase:class_name()
	return self._class_name
end

function CellManagerBase:manager_name()
	return self._manager_name
end

function CellManagerBase:set_in_menu(in_menu)
	self._in_menu = in_menu
end

function CellManagerBase:in_menu()
	return self._in_menu
end

function CellManagerBase:debug_print(txt)
	CellGlobal:log(self._class_name .. " - " .. txt)
end

function CellManagerBase:on_session_destroyed()
end

function CellManagerBase:update_clock(t,dt)
	self._t = t
	self._dt = dt
end