WeightHandler = WeightHandler or blt_class()

function WeightHandler:init()
	self._weighted_values = {}
end

function WeightHandler:add_value(value, weight)	
	table.insert(self._weighted_values, ValueWeight:new(value, weight))
end

function WeightHandler:count()
	return #self._weighted_values
end

function WeightHandler:has_any()
	return next(self._weighted_values)
end

function WeightHandler:get_best_value()
	if not self:has_any() then
		return nil
	end
	
	local list = self._weighted_values
	
	if #list == 1 then
		return list[1]
	end
	
	local total_weight = 0
	for _, option in pairs(list) do
		total_weight = total_weight + option.weight
	end
	
	local rng_weight = math.random() * total_weight
	
	local _max = #list + 1
	
	while _max > 1 and total_weight >= rng_weight do
		_max = _max - 1
		total_weight = total_weight - list[_max].weight
	end
	return list[_max]
end