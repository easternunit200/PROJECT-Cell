StringBuilder = StringBuilder or blt_class()

function StringBuilder:init()
	self._lines = ""
	self._first = false
end


function StringBuilder:AppentEmptyLine()
	self._lines = self._lines .. "\n"
end


function StringBuilder:AppendLine(txt)
	self._lines = self._lines..txt .. "\n"
end

function StringBuilder:Append(txt)
	self._lines = self._lines..txt
end

function StringBuilder:Clear()
	self._lines = ""
end

function StringBuilder:String_to_Vector(pos)
	if type(pos) == "string" then
		pos = self:String_to(pos, "Vector3")
	end
	return pos
end

function StringBuilder:String_to_Rotation(rot)
	if type(rot) == "string" then
		rot = self:String_to(rot, "Rotation")
	end
	return rot
end

function StringBuilder:String_to(value, type)
	local text = tostring(value)
	local _table = {}
	local test = ""
	local first
	for i = 1, #text do
		local go = text:sub(i,i)
		if go == "(" then
			local go = text:sub(i + 1,i + 1)
			test = ""
			first = true
		elseif go == "," then
			table.insert(_table, tonumber(test))
			test = ""
			local go = text:sub(i + 1,i + 1)
			test = test..go
		elseif go == ")" then
			table.insert(_table, tonumber(test))
			if _table[1] and _table[2] and _table[2] then
				if type == "Vector3" then
					return Vector3(_table[1],_table[2],_table[3])
				elseif type == "Rotation" then
					return Rotation(_table[1],_table[2],_table[3])
				end
			else
				if type == "Vector3" then
					CellGlobal:log("ERROR : No Vector3")
				elseif type == "Rotation" then
					CellGlobal:log("ERROR : No Rotation")
				end
				return nil
			end
		elseif first and go ~= "," or go ~= ")" or go ~= "(" then
			test = test..go
		end
	end
end

function StringBuilder:_string_to(key, str)
	local data = {}
	if str:sub(1,#key) == key then
		local str_num = ""
		local word = str:gsub(key,"")
		for i=2, #word do
			local character = word:sub(i,i)

			if character == "," or character == ")" then
				if not data.x then
					data.x = tonumber(str_num)
					str_num = ""
				elseif not data.y then
					data.y = tonumber(str_num)
					str_num = ""
				elseif not data.z then
					data.z = tonumber(str_num)
					str_num = ""
				end
			else
				str_num = str_num .. tostring(character)
			end

		end
	end
	return data
end

function StringBuilder:_string_to_vector3(str)
	local pos = self:_string_to("Vector3", str)
	return Vector3(pos.x,pos.y,pos.z)
end

function StringBuilder:_string_to_rotation(str)
	local rot = self:_string_to("Rotation", str)
	return Rotation(rot.x,rot.y,rot.z)
end

function StringBuilder:IsEmpty()
	return self._lines == ""
end

function StringBuilder:Results()
	return self._lines
end

StringUtils = StringUtils or blt_class()

function StringUtils:isNotNilorEmpty(value)
	return value ~= nil or value ~= ""
end

function StringUtils:wrap_quotes(field)
	return "\""..field.."\""
end


function StringUtils:create_field(field, value)
	return "\""..field.."\" : "..value
end


function StringUtils:formatValue(field, value, additionals)
	if additionals == nil then
		additionals = ""
	end


	local output = "\""..field.."\" : "
	if value == nil then
		return output .. "null"
	end
	if type(value) == "string" then
		return output .. "\""..value.."\""..additionals
	elseif type(value) == "number" then
		return output .. value..additionals
	elseif type(value) == "boolean" then
		return output .. tostring(value)..additionals
	end

end

function StringUtils:replace_char(pos, str, r)
    return str:sub(1, pos-1) .. r .. str:sub(pos+1)
end