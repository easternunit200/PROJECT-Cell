ByteTools = ByteTools or {}
function ByteTools:GetString(bytes)
	local str = ""
	for i,v in pairs(bytes) do
		str = str .. utf8.char(v)
	end
	return str
end


function ByteTools:GetBytes(t)
	local bytes = {}
	for i = 1, #t  do
		bytes[i - 1] = utf8.byte(t:sub(i,i))
	end
	return bytes
end


function ByteTools:GetStringArray(str)
	local array = {}
	
	for i = 1, #str do
		array[1 - 1] = str:sub(i,i)
	end
	
	return array
end

