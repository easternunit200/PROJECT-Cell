--- Make Sure to Exclude this from public build

DebugGlobal = DebugGlobal or {}

function DebugGlobal:Setup()
	log("<<DebugGlobal now active!>>")
	log("<Make sure to delete this file upon release!>")
	CellDataBlockManager.IS_RESOURCE_FILE = false
	CellDataBlockManager.SAVE_ON_STARTUP = false
	CellDataBlockManager.SAVE_BINARY = false
	CellDataBlockManager.GENERATE_HEADERS = true
	CellDataBlockManager.LOAD_BINARY = false
	CellDataBlockManager.m_binaryEncoder = nil
	CellDataBlockManager.DEBUG_ENABLED = true	
	
		
end

