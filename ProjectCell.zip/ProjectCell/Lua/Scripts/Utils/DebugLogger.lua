DebugLogger = DebugLogger or blt_class()

function DebugLogger:init(name, enabled)
	self._enabled = enabled;
	self._name = name
end

function DebugLogger:debug_print(txt)
	CellGlobal:log(self._name .. " - " .. txt)
end