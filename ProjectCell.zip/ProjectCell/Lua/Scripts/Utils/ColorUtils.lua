ColorUtils = ColorUtils or blt_class()

function ColorUtils:color(r,g,b)
	return Color(r / 255, g / 255, b / 255)
end

function ColorUtils:black()
	return ColorUtils:color(0,0,0)
end

function ColorUtils:white()
	return ColorUtils:color(255, 255, 255)
end