MenuHelperPlusExample = MenuHelperPlusExample or blt_class()

function MenuHelperPlusExample:new_menu()

	CellGlobal:log("Created a new menu!")
end