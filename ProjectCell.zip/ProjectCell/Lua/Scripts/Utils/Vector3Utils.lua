Vector3Utils = Vector3Utils or blt_class()

function Vector3Utils:distance(from,to)
	local dis = mvector3.distance_sq(from, to)
	return math.sqrt(dis / 100) * 0.1
end