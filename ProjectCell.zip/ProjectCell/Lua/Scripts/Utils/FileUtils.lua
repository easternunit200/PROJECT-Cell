FileUtils = FileUtils or {}
FileUtils.FilesLoaded = {}
FileUtils.PrintAlreadyFiles = false
FileUtils.DEBUG_ENABLED = false
FileUtils.PATH = ModPath

function FileUtils:WriteAllText(filePath, fileContents, ignore_mod_path)
	local out
	if ignore_mod_path then
		out = io.open(filePath, "wb")
	else
		out = io.open(FileUtils.PATH .. filePath, "wb")
	end
	out:write(fileContents)
	out:close()
end

function FileUtils:IO_Open(filePath)
	return io.open(FileUtils.PATH .. filePath, "wb");
end

function FileUtils:ReadAllText(file_path, ignore_mod_path)
	local path = FileUtils.PATH .. file_path
	
	if ignore_mod_path then
		path = file_path
	end
	
	if not io.file_is_readable( path ) then
		FileUtils:DebugPrint("[FileUtils:ReadAllText] ERROR : " .. path .. " does not exist!!")
		return		
	end	
	
	local file = io.open( path, "r" )
	if file then
		local file_content = file:read("*all")
		file:close()		
		return file_content
	end
end

function FileUtils:GetPath(path)
	return FileUtils.PATH .. path
end

function FileUtils:GetDirectories(directory_path)
	return file.GetDirectories( FileUtils.PATH .. directory_path )
end

function FileUtils:GetFiles(directory_path, ignore_mod_path)
	if ignore_mod_path then
		return file.GetFiles( directory_path )
	end
	return file.GetFiles( FileUtils.PATH .. directory_path )
end

function FileUtils:DebugPrint(...)
	if FileUtils.DEBUG_ENABLED then
		CellGlobal:log(...)
	end	
end

function FileUtils:LoadFileIgnoringModPath(file_path, force)
	FileUtils:LoadFile(file_path, force, true)
end

function FileUtils:LoadFile(file_path, force, ignore_mod_path)
	local path = FileUtils.PATH .. file_path
	
	if ignore_mod_path then
		path = file_path
	end
	
	
	if io.file_is_readable( path ) then		
		if force or not FileUtils.FilesLoaded[path] then
			FileUtils.FilesLoaded[path] = true
			dofile(path)		
		else
			if FileUtils.PrintAlreadyFiles then
				FileUtils:DebugPrint("[FileUtils:LoadFile] FilePath "..path.." was already loaded!")	
			end			
		end
				
		return true
	end	
	
	FileUtils:DebugPrint("[FileUtils:LoadFile] ERROR : " .. path .. " does not exist!!")	
	return false
end

function FileUtils:ExecuteFile(path, commands)
	os.execute("\""..FileUtils.PATH .. path.."\" "..commands);
end

function FileUtils:ReadAllBytes(file_path)
	local contents = FileUtils:ReadAllText(file_path)
	return utf8.characters(contents)
end

function FileUtils:DirectoryExists(file_path)
	return file.DirectoryExists(FileUtils.PATH .. file_path)
end

function FileUtils:PathExists(file_path, ignore_mod_path)
	if ignore_mod_path then
		return io.file_is_readable(file_path)
	end
	return io.file_is_readable(FileUtils.PATH .. file_path)
end

function FileUtils:save_hash_file_text()
	local hash = tostring(file.DirectoryHash(FileUtils.PATH))
	local file = io.open("DeadLocke_hash.txt", "w+")
	file:write(hash)
	file:close()
end

function FileUtils:sounds_directory(...)
	local params = {...}
	local amount = select("#",...)
	
	local path = self._path.."assets/sounds/"
	
	for i,v in pairs(params) do
		path = path..v..(amount == i and "" or "/")		
	end
	
	return path..".ogg"
end

function FileUtils:CreateDirectory(file_path)
	local path = FileUtils.PATH .. file_path
	os.execute( path )
end

function FileUtils:CombinePath(...)
	local params = {...}
	local amount = select("#",...)
	
	local path = FileUtils.PATH
	
	for i,v in pairs(params) do
		path = path..v..(amount == i and "" or "/")		
	end	
	
	
	local possible_directory = path.."/"
	if file.DirectoryExists(possible_directory) then
		return possible_directory
	end
	
	return path
end

function FileUtils:CreateGroupData(directory, groupName)
	return {
		name = groupName,
		directory = directory,
		audio_paths = {},
		childGroups = {}	
	}
end

function FileUtils:GetSoundFiles()
	FileUtils.tempAudioFilesResults = {}
	FileUtils.tempAudioFilesResults.CurrentDirectory = "assets/CellSounds/"
	FileUtils.tempAudioFilesResults.RootGroupData = FileUtils:CreateGroupData(FileUtils.tempAudioFilesResults.CurrentDirectory, "CellSounds")
	FileUtils:GetSoundFilesFromDirectory(FileUtils.tempAudioFilesResults.RootGroupData)	
	return deep_clone(FileUtils.tempAudioFilesResults.RootGroupData)
end

function FileUtils:GetAllFilesFromDirectory(directory_path, include_sub_directories, file_filter, extension_filter)

	local file_paths = {}
	local files = FileUtils:GetFiles(directory_path)
	
	for index, fileName in pairs(files) do		
		if not extension_filter or FileUtils:GetFileName(fileName) == extension_filter then
			if not file_filter or fileName:find(file_filter) then
				table.insert(file_paths, directory_path .. fileName)
			end			
		end		
	end
	
	
	
	
	if include_sub_directories then	
	
		local sub_directories = FileUtils:GetDirectories(directory_path)
		if sub_directories and next(sub_directories) then
			for _, sub_directory in pairs(sub_directories) do						
				local sub_file_paths = FileUtils:GetAllFilesFromDirectory(directory_path .. sub_directory .. "/", true, extension_filter)				
				table.list_append(file_paths, sub_file_paths)
			end
		end	
		
	end
	

	return file_paths
end

function FileUtils:GetAllAudioFilePaths(file_filter)
	return FileUtils:GetAllFilesFromDirectory("assets/CellSounds/", true, file_filter, ".ogg")
end

function FileUtils:GetFileName(fileName)
  return fileName:match("^.+/(.+)$")
end

function FileUtils:GetFileExtension(fileName)
  return fileName:match("^.+(%..+)$")
end


function FileUtils:GetSoundFilesFromDirectory(currentGroupData)
	local files = FileUtils:GetFiles(currentGroupData.directory)
	
	for index, fileName in pairs(files) do		
		if fileName:find(".ogg") then
			local file_path = {
				fileName = fileName:gsub(".ogg",""),
				filePath = FileUtils.tempAudioFilesResults.CurrentDirectory .. fileName:gsub(".ogg","")
			}
			table.insert(currentGroupData.audio_paths, file_path)
		else
			CellGlobal:log("fileName is not an ogg file : " .. tostring(fileName))
		end		
		
	end
	
	local directories = FileUtils:GetDirectories(currentGroupData.directory)
	
	if directories and next(directories) then
		for _, directory in pairs(directories) do			
			local newChildGroupData = FileUtils:CreateGroupData(currentGroupData.directory .. directory .. "/", directory)			
			FileUtils:GetSoundFilesFromDirectory(newChildGroupData)
			table.insert(currentGroupData.childGroups, newChildGroupData)
		end
	end

end