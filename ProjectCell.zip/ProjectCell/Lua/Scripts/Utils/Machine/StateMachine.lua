StateMachine = StateMachine or blt_class()
StateMachine.active_machines = {}

StateMachine.States = {}

function StateMachine:init(...)
	self._current_state_name = nil
	self._current_state_id = nil
	self._last_state_name = nil
	self._last_state_id = nil
	self._state_data = {}
	self._current_state = nil
	self._last_state = nil
	self._states = {}	
	
	self._state_by_name = {}
	self._state_by_id = {}	
	self._state_id_by_name = {}	
	self._state_name_by_id = {}	
	self._start_state = nil
	self._debug_enabled = false
	self._queued_states = {}
	self._t = 0
	self._state_id_index = -1
	self:register()
end


function StateMachine.StateID(name)
	return StateMachine.States[name]
end

function StateMachine._register_machine(machine)
	table.insert(StateMachine.active_machines, machine)
end

function StateMachine._unregister_machine(machine)	
	table.delete(StateMachine.active_machines, machine)
end

function StateMachine:register()
	self._active = true
	StateMachine._register_machine(self)
end

function StateMachine:unregister()
	self._active = false
	StateMachine._unregister_machine(self)
end

function StateMachine:set_enabled(enabled)
	if self._active == enabled then
		return
	end
	
	if enabled then
		self:register()
	else
		self:unregister()
	end
	
	self._active = enabled	
end

function StateMachine:active()
	return self._active
end

function StateMachine.update_machines(t,dt)
end


function StateMachine:is_locally_owned()
	return true
end

function StateMachine:is_debug_enabledd()
	return self._debug_enabled
end

function StateMachine:update_machine(t,dt)
	self:update_time(t,dt)
	self:update(t,dt)
end


function StateMachine:update(t,dt)
	self:update_state(t,dt)
end

function StateMachine:update_time(t)
	self._t = t
end

function StateMachine:override_state(from, to)
	state_instance = self._states[from]
	
	self._states[to] = state
end

function StateMachine:highest_state_id()
	return self._state_id_index
end


function StateMachine:add_state(name, state_instance)
	self._state_id_index = self._state_id_index + 1
		
	state_instance.DEBUG_ENABLED = self._debug_enabled
	state_instance._machine = self	
	self:set_state(name, self._state_id_index, state_instance)
	state_instance:setup()
	return state_instance
end

function StateMachine:set_state(name, stateID, state_instance)
	state_instance.STATE_NAME = name
	state_instance.STATE_ID = stateID	
	table.insert(self._states, state_instance)
	self._state_by_name[name] = state_instance
	self._state_by_id[stateID] = state_instance
	self._state_id_by_name[name] = stateID
	self._state_name_by_id[stateID] = name
end


function StateMachine:enable_debug(enable)
	self._debug_enabled = enable
	for index, state in pairs(self._states) do
		if state then
			state:enable_debug(enable)
		end		
	end
end

function StateMachine:state_enter_t()
	return self._state_enter_t
end

function StateMachine:current_state()
	return self._current_state
end

function StateMachine:current_state_name()
	return self._current_state_name
end

function StateMachine:current_state_id()
	return self._current_state_id
end

function StateMachine:last_state()
	return self._last_state
end

function StateMachine:last_state_name()
	return self._last_state_name
end

function StateMachine:last_state_id()
	return self._last_state_id
end

function StateMachine:reset()
	if self._start_state ~= nil then
		self:_change_state(self._start_state)
	end	
end

function StateMachine:set_start_state(state)	
	if type(state) == "string" then
		state = self:get_state_by_name(state)
	elseif type(state) == "number" then
		state = self:get_state_by_id(state)
	end
	
	self._start_state = state
	self:_change_state(self._start_state)
end



function StateMachine:states()
	return self._states
end

function StateMachine:get_state(id_or_name)
	if type(id_or_name) == "string" then
		return self:get_state_by_name(id_or_name)
	elseif type(id_or_name) == "number" then
		return self:get_state_by_id(id_or_name)
	end
	
	return nil
end

function StateMachine:get_state_by_name(name)
	return self._state_by_name[name]
end

function StateMachine:get_state_by_id(state_id)
	return self._state_by_id[state_id]
end

function StateMachine:get_state_id_by_name(name)
	return self._state_id_by_name[name]
end

function StateMachine:get_state_name_by_id(state_id)
	return self._state_name_by_id[state_id]
end


function StateMachine:_change_state(new_state)	
	table.insert(self._queued_states, 1, new_state)	
	if #self._queued_states == 1 then
		self:_change_state_from_queue()
	end	
end


function StateMachine:_change_state_from_queue()
	
	while #self._queued_states > 0 do
		local new_state = table.remove(self._queued_states, 1)
	
		self._last_state = self._current_state	
		
		self._state_enter_t = self._t
		self._current_state = new_state
		self._current_state._state_change_t = self._state_enter_t
		
		self._current_state_name = new_state.STATE_NAME
		self._current_state_id = new_state.STATE_ID
		
		local is_locally_owned = self:is_locally_owned()
		
		local exit_data = nil	
		
		if self._last_state then	
			self._last_state_name = self._last_state.STATE_NAME
			self._last_state_id = self._last_state.STATE_ID
			if is_locally_owned then
				exit_data = self._last_state:exit()
			else
				exit_data = self._last_state:sync_exit()
			end	
		end	
		
		
		if is_locally_owned then		
			new_state:enter(exit_data)
		else
			new_state:sync_enter(exit_data)
		end		
	end
	
	
end

function StateMachine:had_last_state()
	return self._last_state ~= nil
end

function StateMachine:change_state(id)
	local new_state
	
	if id then
		if type(id) == "string" then
			new_state = self:get_state_by_name(id)	
		elseif type(id) == "number" then
			new_state = self:get_state_by_id(id)	
		end
	end	
	
	if not new_state then
		CellGlobal:log("[StateMachine:change_state] state : " .. tostring(id).. " is invalid!")
		return
	end
	
	self:_change_state(new_state)
end


function StateMachine:update_state(t,dt)
	if self._current_state == nil then
		return
	end
	
	self._current_state._t = t
	
	if self:is_locally_owned() then
		self._current_state:update(t,dt)
		return
	end
	
	self._current_state:sync_update(t,dt)
end

function StateMachine:is_in_state(state_names)
	if type(state_names) == "string" then
		state_names = {state_names}
	end
	
	local current_state_name = self:current_state_name()
	
	if current_state_name then
		for _, state_name in pairs(state_names) do
			if current_state_name == state_name then
				return true
			end
		end	
	end
	
	return false	
end

