MachineState = MachineState or blt_class()

function MachineState:init(...)
	self._t = 0
	self._machine = nil
	self.DEBUG_ENABLED = false
	self.STATE_NAME = nil
	self.STATE_ID = nil
end

function MachineState:setup(...)
end

function MachineState:enter(...)
end

function MachineState:exit(...)
end

function MachineState:sync_enter(...)
end

function MachineState:sync_exit(...)
end


function MachineState:update(t,dt)
end

function MachineState:sync_update(t,dt)
end

function MachineState:debug_prefix()
	return ""
end

function MachineState:get_extra_debug()
	return ""
end

function MachineState:debug_print(text)
	if self.DEBUG_ENABLED then
		CellGlobal:log(self:debug_prefix() .. " - " .. text)
	end
end

function MachineState:enable_debug(enable)
	self.DEBUG_ENABLED = enable
end
