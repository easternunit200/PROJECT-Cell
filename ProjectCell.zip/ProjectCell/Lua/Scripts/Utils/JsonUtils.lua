
JsonUtils = JsonUtils or {}

function JsonUtils:safe_decode(data)
	local result
	pcall(function()
		result = json.decode(data)
	end)
	return result
end

function JsonUtils:safe_encode(data)
	local result
	pcall(function()
		result = json.encode(data)
	end)
	return result
end

function copy_values_to_object(to_object, from_object)
	if from_object and next(from_object) then
		for i, v in pairs(from_object)  do
			to_object[i] = v	
		end
	end	
end


function convert_to_class(o, field_name, class_name)
	if o and o[field_name] then
		o[field_name] = rawget(_G, class_name):load(o[field_name])
	end
end





JsonWriter = JsonWriter or blt_class()

function JsonWriter:init(obj, indent, ignore_first_indent)
	self._stringBuilder = StringBuilder:new();
	self._obj = obj
	self._indent = indent or ""
	self._intial_indent = self._indent
	if ignore_first_indent then
		self._stringBuilder:Append("{")
	else
		self._stringBuilder:AppendLine(self._intial_indent .. "{")
	end
	self._indent = self._indent .. "  "
end


function JsonWriter:Results()
	return self._stringBuilder:Results()
end

function JsonWriter:Close(more)
	self._stringBuilder:AppendLine(self._intial_indent .. (more and "}," or "}"))
end

function JsonWriter:WriteFinal(field_name, value_type)
	self:Write(field_name, value_type, true)
	self:Close(false)
end

function JsonWriter:Write(field_name, value_type, final)
	local s = self._stringBuilder
	local value = self._obj[field_name]
	if value_type == "string" then
		if not value or type(value) ~= "string" then
			value = ""
		end
		s:AppendLine(self._indent .. "\""..field_name.."\" : \""..tostring(value or "").."\"" .. (final and "" or ","))
	elseif value_type == "number" then
		if not value or type(value) ~= "number" then
			value = 0
		end
		s:AppendLine(self._indent .. "\""..field_name.."\" : "..tostring(value or  0).. (final and "" or ","))
	elseif value_type == "boolean" then
		if not value or type(value) ~= "boolean" then
			value = false
		end
		s:AppendLine(self._indent .. "\""..field_name.."\" : "..tostring(value or false).. (final and "" or ","))
	elseif value_type == "object" then
		if value and value.Serialize then
			s:AppendLine(self._indent .. "\""..field_name.."\" :")
			s:Append(value:Serialize(self._indent, false) .. (#value == i and "" or ","))
		end
	elseif value_type == "array" or value_type == "string_array" or value_type == "number_array" then
		s:AppendLine(self._indent .. "\""..field_name.."\" : [")
		local ignore_new_line = true
		if value and next(value) then
			for i,v in pairs(value) do
				if v then
					if type(v) == "table" and v.Serialize then
						ignore_new_line = false
						s:AppendLine(v:Serialize(self._indent .. "  ") .. (#value == i and "" or ","))
					elseif type(v) == "string" then
						ignore_new_line = false
						s:AppendLine(self._indent .. "  \"" .. v .."\"" .. (#value == i and "" or ","))
					elseif  type(v) == "number" then
						ignore_new_line = false
						s:AppendLine(self._indent .. "  " .. v  .. (#value == i and "" or ","))
					end
				end
			end
		end

		local text = (final and "]" or "],")
		if ignore_new_line then
			s:Append(text)
		else
			s:AppendLine(self._indent .. text)
		end
	end
end