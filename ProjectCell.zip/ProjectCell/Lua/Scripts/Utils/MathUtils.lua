MathUtils = MathUtils or class()
function MathUtils:get_fixed_value(value)
	return tonumber(string.format("%.2f", value))
end

function MathUtils:add_multiplier(value, percentage)
	return value + (value * percentage)
end