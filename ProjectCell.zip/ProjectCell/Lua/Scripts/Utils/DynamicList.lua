DynamicList = DynamicList or blt_class()

function DynamicList:init(arr)
	self._name_by_index = {}
	self._index_by_name = {}
	
	for index, name in pairs(arr) do
		self._name_by_index[name] = index
		self._index_by_name[index] = name
	end
end


function DynamicList:get_name_value(index)
	return self._name_by_index[index]
end

function DynamicList:get_index_value(name)
	return self._index_by_name[name]
end

function DynamicList:is_index_valid(index)
	return self._index_by_name[index] and true or false
end

function DynamicList:is_name_valid(name)
	return self._name_by_index[name] and true or false
end