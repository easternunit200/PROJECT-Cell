BeardLibMenu_Example = BeardLibMenu_Example or blt_class()
BeardLibMenu_Example.Current = nil

BeardLibMenu_Example.groupItems = {}

function BeardLibMenu_Example:current()
	if not BeardLibMenu_Example.Current then
		BeardLibMenu_Example.Current = BeardLibMenu_Example:new()
	end
	
	return BeardLibMenu_Example.Current
end

function BeardLibMenu_Example:removeItem(i)
	BeardLibMenu_Example.groupItems[i]:Destroy()
end

function BeardLibMenu_Example:initialize()
	if MenuUI == nil then
		C_Global:log("[BeardLibMenu_Example:create_menu] ERROR : MenuUI class doesn't exist!")
		return
	end
	
	if self._currentMenuUI then
		C_Global:log("[BeardLibMenu_Example:create_menu] re-creating menu")
		self._currentMenuUI:Disable()
	else
		C_Global:log("[BeardLibMenu_Example:create_menu] creating a new MenuUI")
	end
	
	self._currentMenuUI = MenuUI:new({
		name = "BeardLibMenu_Example",
		scrollbar = true,	
	})
	
	self._exampleMenu1 = self._currentMenuUI:Menu({
		name = "Example Menu 1"
	})
	
	
	self._exampleGroup1 = self._exampleMenu1:Group({
		name = "example_group_menu_01",
		text = "Example Group 1 : None",
		closed = true,
		scrollbar = true,
		scroll_width = 10,
		max_height = 200,
		max_width = 400,
		help = "Tool Tip for Example Group 1"
		
	})
	
	for i = 1, 20 do
		local newItem = self._exampleGroup1:Button({
			name = "example02_item_" .. tostring(i),
			text = "Example01 Item " .. tostring(i),
			on_callback = function(item)
				log("Example01 Item " .. tostring(i) .. " was pressed!")
				self._exampleGroup1:SetText("Example Group 1 : " .. tostring(i))
			end
		})
		
		BeardLibMenu_Example.groupItems[i] = newItem
	end	
	
	self._exampleTextbox = self._exampleGroup1:TextBox({
		name = "ExampleTextBox",
		text = "Name",
		max_height = 200,
		max_width = 400,
		value = "Example",
		on_callback = function(item)
			log("Value changed!", tostring(item:Value()))
		end
	})
	
	
	local drop_down = managers.cell_data:wrapper("SoundAudioDataBlock"):GetDropDownInfo()
	
	self._exampleTextbox = self._exampleGroup1:ComboBox({
		name = "SoundAudioDataList",
		text = "SoundAudioID",
		items = drop_down:get_all_items(),
		value = 1,
		free_typing = false,
		on_callback = function(item)
			
			local index = tonumber(item:Value())
			log("Index", tostring(index))
			
			log("Selected PersisentID", tostring(drop_down:get_id_from_index(index)))
		end
	})
	
	
	self._exampleMenu1:Button({
		name = "CloseButton",
		text = "Close",
		position = {1000, 15},
		max_height = 200,
		max_width = 200,
		on_callback = function(item)
			log("Closing Menu")
			self._currentMenuUI:Disable()
		end
	})


	self._currentMenuUI:Enable()

end