CellHasher = CellHasher or blt_class()
CellHasher.prime = 746;
CellHasher.offset = 2166136261;


function CellHasher.HashString(name)
	local input = utf8.characters(string.lower(name))
	local offset = #input * CellHasher.offset;

	local hash = offset;


	for i=1, #input do
		local num = utf8.byte(input[i])
		hash = hash + (num * CellHasher.prime)
	end

	return hash;
end
