ValueWeight = ValueWeight or blt_class()
function ValueWeight:init(value, weight)
	self.weight = weight
	self.value = value
end