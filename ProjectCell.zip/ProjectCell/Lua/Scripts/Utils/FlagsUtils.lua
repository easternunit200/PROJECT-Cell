FlagsBuilder = FlagsBuilder or blt_class()
function FlagsBuilder:init(t)
	self._flags = {}	
	local value = 1
	for _,name in pairs(t) do
		table.insert(self._flags,{name = name,  value = value})
		value = value * 2		
	end
end

function FlagsBuilder:get_value(name)
	for i,v in pairs(self._flags) do
		if v.name == name then
			return v.value
		end
	end
	return 0
end

function FlagsBuilder:get_values(t)
	local value = 0
	for i,v in pairs(self._flags) do
		if table.contains(t, v.name) then
			value = value + v.value
		end
	end
	return value
end

function FlagsBuilder:create_results(value)
	local flagsResults = FlagsResult:new()
	
	local builder = StringBuilder:new()
	for i = #self._flags, 1, -1 do
		if value >= self._flags[i].value then
			flagsResults:add(self._flags[i].name)
			builder:AppendLine("\t" .. self._flags[i].name .. " -> "..self._flags[i].value)
			value = value - self._flags[i].value			
		end
	end
	
	--log("Results\n"..builder:Results())
end


FlagsResult = FlagsResult or blt_class()

function FlagsResult:init()
	self._results = {}
end

function FlagsResult:add(name)
	self._results[name] = true
end

function FlagsResult:has_result(name)
	return self._results[name] and true or false
end

function FlagsResult:get_result_from_key_word(key_word)
	local copied = deep_clone(self)
	for i,v in pairs(copied._results) do
		if not i:find(key_word) then
			copied[i] = false	
		end
	end
	return copied
end